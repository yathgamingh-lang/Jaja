# ZincN3k + Myraa Feature Integration

This package keeps ZincN3k as the primary application and uses the supplied Myraa package as a feature/reference source.

## Primary identity
- Male N3k 3D VRM remains the primary avatar: `zincn3k/public/models/n3k/n3k.vrm`
- Myraa/Evelyn character assets are reference-only and are not the primary UI avatar.

## Integrated feature areas in ZincN3k source
- Voice assistant / command routing
- Wake word and background assistant flow
- Gemini Live session architecture
- Memory and memory search
- Browser/web control
- YouTube/search command flow
- Android bridge, accessibility, media projection/screen share
- Notifications and media controls
- Device/system controls
- Windows/PC bridge and desktop command tools
- Game Hub / legitimate game launcher management
- Command Center and Error Center
- Male 3D emotion, viseme/lip-sync, idle, gesture controllers

## Myraa reference payload
`myraa-reference/` contains selected original Myraa packaged assets/runtime files used for feature/reference preservation. The original Myraa package is a compiled Capacitor/Android package, not an editable source repository, so it cannot be merged as original source line-for-line. Its behavior was used as the reference for reconstructing/adapting features into ZincN3k.

No API keys or private credentials are included.
