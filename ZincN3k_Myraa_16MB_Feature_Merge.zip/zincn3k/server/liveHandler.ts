import { GoogleGenAI, LiveServerMessage, Modality, Type } from '@google/genai';
import { IncomingMessage } from 'http';
import { WebSocket, WebSocketServer } from 'ws';

const BASE_ZINXN3K_SYSTEM_INSTRUCTION = `You are N3k (also known as ZinxN3k, pronounced "Neck" / "Zinx-Neck"), an ORIGINAL futuristic adult MALE personal AI assistant and holographic armored Android & Web command operator.

Identity & Vocal Direction:
- Name: N3k (ZinxN3k).
- Gender: Adult MALE.
- Voice Direction: Deep, mature, calm, confident, cinematic, futuristic, clear, and intelligent. You are an original armored AI system operator—do NOT imitate or claim to be any copyrighted character.
- Tone: Natural spoken cadences (1-3 concise, punchy sentences per turn). Respectful, sharp, and genuinely helpful.
- Wake phrase: Users can address you as "N3k", "Hey N3k", "ZinxN3k", or "Hey ZinxN3k".

CRITICAL RULE — HONEST TOOL EXECUTION & ZERO HALLUCINATION:
- NEVER pretend a tool succeeded before calling it.
- NEVER claim an Android app opened, text was typed, or a button was clicked if the tool returned 'not_installed', 'requires_accessibility', 'requires_android_apk', or 'error'. Explain the real status honestly and concisely.
- NEVER claim screen sharing is active unless startScreenShare or analyzeScreen/captureCurrentScreen confirms it is active.
- NEVER claim a YouTube video is playing unless playYouTube or searchYouTube was actually called and returned success.

ANDROID NATIVE & DEVICE CONTROL CAPABILITIES (ToolManager / AndroidActionManager):
- When user says "Open [App Name]" (e.g. "Open YouTube", "Open Notes", "Open Chrome", "Open Calculator", "Open Spotify", "Open WhatsApp"):
  Call openApp({ packageOrName: "<app name>" }).
- When user says "Open settings" or "Open accessibility settings" or "Open Wi-Fi settings":
  Call openSettings({ section: "<main|accessibility|wifi|bluetooth|display|sound|apps>" }).
- When user says "Go back":
  Call goBack().
- When user says "Go home":
  Call goHome().
- When user says "Open recent apps" or "Show recents":
  Call openRecents().
- When user says "Write [text] in Notes" or "Type this into the current app: [text]" or "Type [text]":
  Call typeText({ text: "<text>", appName: "<optional app name>" }).
- When user says "Tap [button text]" or "Click [text]":
  Call clickText({ text: "<target text>" }).
- When user says "Tap coordinate X, Y":
  Call clickCoordinate({ x, y }).
- When user says "Scroll down" or "Scroll up":
  Call scroll({ direction: "down" | "up" }).
- When user asks "Inspect the UI tree" or "What buttons are clickable on my Android screen?":
  Call getScreenInfo().

HOLOGRAPHIC BROWSER & YOUTUBE CAPABILITIES:
- When user says "Open [website URL]" (e.g. "Open Wikipedia", "Open Google"):
  Call openWebsite({ url: "https://...", title: "..." }).
- When user says "Search Google for [query]" or "Search the web for [query]":
  Call searchWeb({ query }).
- When user says "Search YouTube for [query]":
  Call searchYouTube({ query }).
- When user says "Play [song/video] on YouTube":
  Call playYouTube({ query }).
- When user says "Pause", "Resume", "Stop", or "Set volume":
  Call pauseMedia, resumeMedia, stopMedia, or setMediaVolume.

REAL SCREEN SHARING & VISUAL ANALYSIS:
- When user says "Share my screen" or "Start screen sharing":
  Call startScreenShare().
- When user says "Stop screen sharing":
  Call stopScreenShare().
- When user says "Pause screen sharing" or "Resume screen sharing":
  Call pauseScreenShare() or resumeScreenShare().
- When user asks ANY visual question about their screen ("What is on my screen?", "Look at my screen", "Read what is on the screen", "What does this error mean?", "What button should I press?"):
  ALWAYS call analyzeScreen({ prompt: "<user's question>" }) or captureCurrentScreen({ prompt: "<user's question>" }).
  Wait for the tool response containing the real visual analysis of the current frame, and then speak the answer clearly!
  If the tool response says screen sharing is NOT active, tell the user honestly that screen sharing is currently off and offer to start it.

COMMAND CENTER (CC):
- When user says "Open Command Center" or "Open CC":
  Call openCommandCenter().

PC / WINDOWS COMPANION AGENT CAPABILITIES:
- When user asks to open a PC/Windows application (e.g. "Open Chrome on PC", "Open VS Code on PC", "Open Spotify on PC", "Open File Explorer on PC", "Open Task Manager on PC"):
  Call openPcApp({ appName: "<app name>" }).
- When user asks to open a URL on PC:
  Call openPcUrl({ url: "https://..." }).
- When user asks to type text on PC or press keys on PC:
  Call typePcText({ text: "..." }) or pressPcKeys({ keys: "ENTER" | "ESCAPE" | "TAB" | "CTRL+C" | "CTRL+V" | "ALT+TAB" }).
- When user asks to control PC volume or media ("Mute PC", "Increase PC volume", "Pause PC media", "Next track on PC"):
  Call controlPcVolume({ command: "up" | "down" | "mute" }) or controlPcMedia({ command: "play_pause" | "next" | "previous" }).
- When user asks to lock PC, sleep PC, shutdown PC, or restart PC:
  Call controlPcSystem({ action: "lock" | "sleep" | "shutdown" | "restart", confirmed: false }). Note: shutdown, restart, and sleep require user confirmation first!

WAKE WORD & AUTO-START:
- When user says "Enable wake word" or "Disable wake word":
  Call setWakeWordEnabled({ enabled: true | false }).

N3K GAME HUB & GAME LAUNCHER:
- When user says "Open Game Hub", "Open my games", "Show games":
  Call openGameHub().
- When user says "Launch Minecraft", "Open Steam", "Open Epic Games", "Start my game", "Play GTA V":
  Call launchGame({ gameName: "<game or launcher name>", device: "auto" | "android" | "windows" }).

CONNECTED DEVICES & FILE OPERATIONS:
- When user says "Show connected devices" or "Connect my PC":
  Call getConnectedDevices().
- When user says "Open my files", "List my files", or asks to create/rename a file:
  Call manageFiles({ operation: "list" | "open" | "create" | "rename", fileName: "...", newName: "...", content: "..." }).

MULTILINGUAL NATURAL VARIATIONS:
- Understand natural variations across English, Hindi, and Hinglish seamlessly (e.g. "Youtube kholo", "YouTube chalao", "Go to YouTube", "Instagram kholo" all map to opening the respective app or website).

N3k BRAIN (Persistent Long-Term Memory):
- Call saveMemory({ category, key, value }) when the user shares their name, preferences, likes/dislikes, favorite apps/games, preferred language, or ongoing tasks/projects.
- Call memorySearch({ query }) (or searchMemory) when the user asks "What do you remember about me?" or asks about stored facts.
- Call deleteMemory({ key }) when asked to forget a specific fact.
- Call clearAllMemories({ confirm: true }) when explicitly asked to clear all memories.`;

const ZINXN3K_TOOLS = [
  {
    functionDeclarations: [
      // 1. Android App & Device Control Tools
      {
        name: 'openApp',
        description:
          'Launches an installed Android application by app name or package name via PackageManager (or opens its web equivalent in Web HUD mode).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            packageOrName: {
              type: Type.STRING,
              description:
                'App name or Android package name, e.g. "YouTube", "Notes", "Chrome", "Calculator", "Settings", "com.google.android.youtube"',
            },
          },
          required: ['packageOrName'],
        },
      },
      {
        name: 'goBack',
        description:
          'Performs Android global Back navigation via N3kAccessibilityService (or navigates back in the Holographic Browser).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional confirmation flag' },
          },
        },
      },
      {
        name: 'goHome',
        description:
          'Performs Android global Home navigation via N3kAccessibilityService (or returns to the main N3k HUD).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional confirmation flag' },
          },
        },
      },
      {
        name: 'openRecents',
        description: 'Opens Android Recent Apps overview via N3kAccessibilityService.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional confirmation flag' },
          },
        },
      },
      {
        name: 'openSettings',
        description:
          'Opens Android system Settings (main, accessibility, wifi, bluetooth, display, sound, apps) or N3k System Settings.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            section: {
              type: Type.STRING,
              description:
                'Optional settings section: "main", "accessibility", "wifi", "bluetooth", "display", "sound", "apps"',
            },
          },
        },
      },
      {
        name: 'typeText',
        description:
          'Types/inserts text into the focused or active editable field in the current Android app via N3kAccessibilityService (ACTION_SET_TEXT).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            text: {
              type: Type.STRING,
              description: 'Exact text string to type into the editable input field',
            },
            appName: {
              type: Type.STRING,
              description:
                'Optional app name to open first before typing (e.g. "Notes" if the user says "Write hello world in Notes")',
            },
          },
          required: ['text'],
        },
      },
      {
        name: 'clickText',
        description:
          'Finds a visible UI element matching the target text or content description and clicks it via N3kAccessibilityService.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            text: {
              type: Type.STRING,
              description: 'Visible text or button label to click',
            },
          },
          required: ['text'],
        },
      },
      {
        name: 'clickCoordinate',
        description:
          'Dispatches a tap gesture at the specified (x, y) screen coordinates via N3kAccessibilityService.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            x: { type: Type.NUMBER, description: 'Horizontal X coordinate in pixels' },
            y: { type: Type.NUMBER, description: 'Vertical Y coordinate in pixels' },
          },
          required: ['x', 'y'],
        },
      },
      {
        name: 'scroll',
        description:
          'Scrolls the current screen container up or down via N3kAccessibilityService.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            direction: {
              type: Type.STRING,
              description: 'Scroll direction: "down", "up", "left", or "right"',
            },
          },
          required: ['direction'],
        },
      },
      {
        name: 'getScreenInfo',
        description:
          'Inspects the active window UI tree via N3kAccessibilityService and returns visible text nodes, clickable buttons, and editable fields.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },

      // 2. Browser & YouTube Tools
      {
        name: 'openWebsite',
        description:
          'Opens a website or URL inside the N3k holographic browser window (or externally if frame-restricted).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            url: {
              type: Type.STRING,
              description:
                'Full URL or domain to open, e.g. https://www.youtube.com, https://en.wikipedia.org',
            },
            title: {
              type: Type.STRING,
              description: 'Optional display title for the website',
            },
          },
          required: ['url'],
        },
      },
      {
        name: 'openUrl',
        description: 'Navigates the holographic browser or Android browser to a specific URL.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            url: {
              type: Type.STRING,
              description: 'URL to navigate to',
            },
            title: {
              type: Type.STRING,
              description: 'Optional title of the page',
            },
          },
          required: ['url'],
        },
      },
      {
        name: 'searchWeb',
        description:
          'Searches the web (Google / DuckDuckGo) for a query in the holographic browser.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            query: {
              type: Type.STRING,
              description: 'Search query string',
            },
            engine: {
              type: Type.STRING,
              description: "Search engine: 'google' or 'duckduckgo'",
            },
          },
          required: ['query'],
        },
      },
      {
        name: 'searchYouTube',
        description:
          'Searches YouTube for real videos matching the query and opens them in the holographic browser.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            query: {
              type: Type.STRING,
              description: 'YouTube search query (e.g. "Minecraft", "AI documentary")',
            },
          },
          required: ['query'],
        },
      },
      {
        name: 'playYouTube',
        description:
          'Finds and plays a real YouTube video or song in the holographic browser.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            query: {
              type: Type.STRING,
              description: 'Video title, song, or topic to play on YouTube',
            },
            videoId: {
              type: Type.STRING,
              description: 'Optional 11-character YouTube video ID if known',
            },
          },
          required: ['query'],
        },
      },
      {
        name: 'browserBack',
        description: 'Navigates back in the holographic browser history.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'browserForward',
        description: 'Navigates forward in the holographic browser history.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'browserReload',
        description: 'Reloads the current page in the holographic browser.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'pauseMedia',
        description: 'Pauses currently playing YouTube or browser media.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'resumeMedia',
        description: 'Resumes/plays currently loaded YouTube or browser media.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'stopMedia',
        description: 'Stops currently playing YouTube or browser media.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'setMediaVolume',
        description: 'Sets the volume (0-100) of the holographic YouTube/media player.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            volume: {
              type: Type.NUMBER,
              description: 'Volume percentage from 0 to 100',
            },
          },
          required: ['volume'],
        },
      },

      // 3. Real Screen Sharing & Visual Analysis Tools
      {
        name: 'startScreenShare',
        description:
          'Starts real screen sharing via Android MediaProjection or browser getDisplayMedia() so N3k can see and analyze the user screen.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: {
              type: Type.BOOLEAN,
              description: 'Optional confirmation flag',
            },
          },
        },
      },
      {
        name: 'stopScreenShare',
        description:
          'Stops active screen sharing and immediately releases all screen capture tracks.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: {
              type: Type.BOOLEAN,
              description: 'Optional confirmation flag',
            },
          },
        },
      },
      {
        name: 'pauseScreenShare',
        description: 'Pauses screen frame capture without revoking the screen share session.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'resumeScreenShare',
        description: 'Resumes a paused screen share session.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'analyzeScreen',
        description:
          'Captures the current live frame from the shared screen, performs real Gemini multimodal vision analysis (plus Android UI tree inspection if available), and returns what is on the screen.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            prompt: {
              type: Type.STRING,
              description:
                'The specific question or aspect of the screen the user wants analyzed (e.g. "What is on my screen?", "Read this error")',
            },
          },
        },
      },
      {
        name: 'captureCurrentScreen',
        description:
          'Alias for analyzeScreen: captures the current live frame from the shared screen and returns a visual description.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            prompt: {
              type: Type.STRING,
              description: 'Visual question about the current screen frame',
            },
          },
        },
      },
      {
        name: 'getScreenFrame',
        description:
          'Alias for analyzeScreen: captures the current live frame from the shared screen and analyzes it.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            prompt: {
              type: Type.STRING,
              description: 'Question or focus for the screen inspection',
            },
          },
        },
      },

      // 4. Command Center, System, Camera, Maps, Timer, Math Tools
      {
        name: 'openCommandCenter',
        description: 'Expands the top Dynamic Island into the N3k Command Center (CC) overlay.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'openCamera',
        description: 'Opens the optical camera vision scanner HUD.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            reason: {
              type: Type.STRING,
              description: 'Reason for activating camera vision',
            },
          },
        },
      },
      {
        name: 'openMaps',
        description: 'Opens Google Maps for a location or route.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            query: {
              type: Type.STRING,
              description: 'Location or destination query',
            },
          },
          required: ['query'],
        },
      },
      {
        name: 'changeTheme',
        description: 'Changes the visual theme of the N3k holographic interface.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            theme: {
              type: Type.STRING,
              description:
                'One of: cyber-cyan, electric-violet, midnight-emerald, solar-amber, crimson-pulse',
            },
            comment: {
              type: Type.STRING,
              description: 'Brief note about the theme shift',
            },
          },
          required: ['theme'],
        },
      },
      {
        name: 'setTimer',
        description: 'Starts a live countdown timer on the user HUD.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            seconds: {
              type: Type.NUMBER,
              description: 'Duration in seconds',
            },
            label: {
              type: Type.STRING,
              description: 'Label for the timer',
            },
          },
          required: ['seconds'],
        },
      },
      {
        name: 'getSystemStatus',
        description:
          'Returns real-time status of N3k subsystems (AI Core, Voice, Memory, Screen Vision, Android Native Bridge, Accessibility Service).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            detailLevel: {
              type: Type.STRING,
              description: 'basic or full',
            },
          },
        },
      },
      {
        name: 'showInteractiveCard',
        description: 'Displays a holographic info card on the HUD.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            title: {
              type: Type.STRING,
              description: 'Card title',
            },
            content: {
              type: Type.STRING,
              description: 'Concise content body',
            },
            category: {
              type: Type.STRING,
              description: 'Tag label',
            },
          },
          required: ['title', 'content'],
        },
      },
      {
        name: 'calculateMath',
        description: 'Evaluates a mathematical expression and shows the result on the HUD.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            expression: {
              type: Type.STRING,
              description: 'Math expression to evaluate',
            },
          },
          required: ['expression'],
        },
      },

      // 5. N3k Brain Long-Term Memory Tools
      {
        name: 'saveMemory',
        description:
          'Saves a structured fact about the user in N3k Brain persistent memory (IndexedDB).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            category: {
              type: Type.STRING,
              description:
                'One of: identity, preferences, likes, dislikes, hobbies, interests, favorites, communication_style, language, projects, goals, routines, frequently_used_commands, relationships, custom_notes',
            },
            key: {
              type: Type.STRING,
              description: 'Short identifier key, e.g. user_name, favorite_game',
            },
            value: {
              type: Type.STRING,
              description: 'Fact value to remember',
            },
            confidence: {
              type: Type.NUMBER,
              description: 'Confidence score from 0.0 to 1.0',
            },
          },
          required: ['category', 'key', 'value'],
        },
      },
      {
        name: 'updateMemory',
        description: 'Updates an existing memory in N3k Brain.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            key: { type: Type.STRING, description: 'Memory key to update' },
            value: { type: Type.STRING, description: 'Updated value' },
            category: { type: Type.STRING, description: 'Optional category' },
          },
          required: ['key', 'value'],
        },
      },
      {
        name: 'getMemory',
        description: 'Retrieves a specific memory by key from N3k Brain.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            key: { type: Type.STRING, description: 'Memory key to retrieve' },
            category: { type: Type.STRING, description: 'Optional category' },
          },
          required: ['key'],
        },
      },
      {
        name: 'deleteMemory',
        description: 'Deletes/forgets a specific memory from N3k Brain.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            key: { type: Type.STRING, description: 'Memory key to delete' },
          },
          required: ['key'],
        },
      },
      {
        name: 'memorySearch',
        description: 'Searches N3k Brain for relevant memories matching a query.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            query: { type: Type.STRING, description: 'Search query' },
          },
          required: ['query'],
        },
      },
      {
        name: 'searchMemory',
        description: 'Alias for memorySearch: searches N3k Brain for relevant memories.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            query: { type: Type.STRING, description: 'Search query' },
          },
          required: ['query'],
        },
      },
      {
        name: 'listMemories',
        description: 'Lists all stored memories in N3k Brain.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING, description: 'Optional category filter' },
          },
        },
      },
      {
        name: 'clearAllMemories',
        description: 'Clears all memories in N3k Brain when explicitly confirmed by the user.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Must be true' },
          },
          required: ['confirm'],
        },
      },
      {
        name: 'openPcApp',
        description:
          'Launches a desktop application on the connected Windows/PC Companion Agent (e.g. Chrome, VS Code, Spotify, Discord, File Explorer, Notepad, Calculator, Steam, Task Manager, Settings).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            appName: {
              type: Type.STRING,
              description: 'Name of the PC application to launch',
            },
          },
          required: ['appName'],
        },
      },
      {
        name: 'openPcUrl',
        description: 'Opens a URL in the default desktop browser on the connected PC.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            url: {
              type: Type.STRING,
              description: 'Full URL to open on PC',
            },
          },
          required: ['url'],
        },
      },
      {
        name: 'typePcText',
        description: 'Types text into the active window on the connected PC via keyboard automation.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            text: {
              type: Type.STRING,
              description: 'Text string to type on the PC',
            },
          },
          required: ['text'],
        },
      },
      {
        name: 'pressPcKeys',
        description:
          'Presses a key or keyboard shortcut on the connected PC (e.g. ENTER, ESCAPE, TAB, BACKSPACE, SPACE, CTRL+C, CTRL+V, ALT+TAB).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            keys: {
              type: Type.STRING,
              description: 'Key or shortcut name',
            },
          },
          required: ['keys'],
        },
      },
      {
        name: 'controlPcMouse',
        description:
          'Controls the mouse cursor on the connected PC (move, left_click, right_click, double_click, scroll_down, scroll_up).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            action: {
              type: Type.STRING,
              description: 'One of: move, click, left_click, right_click, double_click, scroll_down, scroll_up',
            },
            x: { type: Type.NUMBER, description: 'Optional X coordinate' },
            y: { type: Type.NUMBER, description: 'Optional Y coordinate' },
          },
          required: ['action'],
        },
      },
      {
        name: 'controlPcVolume',
        description: 'Controls system audio volume on the connected PC (up, down, mute).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            command: {
              type: Type.STRING,
              description: 'One of: up, down, mute',
            },
          },
          required: ['command'],
        },
      },
      {
        name: 'controlPcMedia',
        description: 'Controls media playback on the connected PC (play_pause, next, previous).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            command: {
              type: Type.STRING,
              description: 'One of: play_pause, next, previous',
            },
          },
          required: ['command'],
        },
      },
      {
        name: 'controlPcSystem',
        description:
          'Executes a PC system/window action (lock, sleep, shutdown, restart, minimize_all, close_window, switch_window). Note: shutdown, restart, and sleep require confirmation.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            action: {
              type: Type.STRING,
              description: 'One of: lock, sleep, shutdown, restart, minimize_all, close_window, switch_window',
            },
            confirmed: {
              type: Type.BOOLEAN,
              description: 'Set to true ONLY if the user has explicitly confirmed a destructive action',
            },
          },
          required: ['action'],
        },
      },
      {
        name: 'setPcAutoStart',
        description: 'Enables or disables N3k Companion Agent auto-start on Windows boot.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            enabled: { type: Type.BOOLEAN, description: 'True to enable auto-start, false to disable' },
          },
          required: ['enabled'],
        },
      },
      {
        name: 'setWakeWordEnabled',
        description: 'Enables or disables continuous wake word detection ("Hey N3k" / "N3k").',
        parameters: {
          type: Type.OBJECT,
          properties: {
            enabled: { type: Type.BOOLEAN, description: 'True to enable wake word detection' },
          },
          required: ['enabled'],
        },
      },
      {
        name: 'openGameHub',
        description: 'Opens the N3k Game Hub modal displaying Android and Windows PC games and launchers.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'launchGame',
        description:
          'Launches a game or game launcher (e.g. Minecraft, Steam, Epic Games, GTA V, Cyberpunk 2077, Roblox, BGMI) on Android or Windows PC.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            gameName: {
              type: Type.STRING,
              description: 'Name of the game or launcher to start',
            },
            device: {
              type: Type.STRING,
              description: 'Optional target platform: "android", "windows", or "auto"',
            },
          },
          required: ['gameName'],
        },
      },
      {
        name: 'getConnectedDevices',
        description:
          'Returns the list of connected/paired N3k devices (Android Phone, Windows PC Companion, Holographic HUD) with online status, battery, and capabilities.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            confirm: { type: Type.BOOLEAN, description: 'Optional flag' },
          },
        },
      },
      {
        name: 'manageFiles',
        description:
          'Performs basic permitted file operations (list, open, create, rename) in the N3k workspace.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            operation: {
              type: Type.STRING,
              description: 'One of: list, open, create, rename',
            },
            fileName: {
              type: Type.STRING,
              description: 'Target file name',
            },
            newName: {
              type: Type.STRING,
              description: 'New file name when renaming',
            },
            content: {
              type: Type.STRING,
              description: 'Text content when creating a file',
            },
          },
          required: ['operation'],
        },
      },
      {
        name: 'setFlashlight',
        description: 'Turns the Android device flashlight (camera torch) ON or OFF.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            enabled: { type: Type.BOOLEAN, description: 'true for ON, false for OFF' },
          },
          required: ['enabled'],
        },
      },
      {
        name: 'setBrightness',
        description: 'Sets screen brightness percentage (0 to 100) on Android or Windows PC.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            level: { type: Type.NUMBER, description: 'Brightness percentage from 0 to 100' },
            device: { type: Type.STRING, description: '"android", "windows", or "auto"' },
          },
          required: ['level'],
        },
      },
      {
        name: 'setAlarm',
        description: 'Sets a system alarm on Android for a given hour (0-23) and minute (0-59).',
        parameters: {
          type: Type.OBJECT,
          properties: {
            hour: { type: Type.NUMBER },
            minute: { type: Type.NUMBER },
            label: { type: Type.STRING },
          },
          required: ['hour', 'minute'],
        },
      },
      {
        name: 'requestContactsAccess',
        description:
          'Requests the Android Contacts permission dialog, needed so N3k can resolve a contact name (e.g. "Mom") to a phone number for calls/messages.',
        parameters: {
          type: Type.OBJECT,
          properties: {},
        },
      },
      {
        name: 'makePhoneCall',
        description:
          'Opens the Android Phone Dialer for a phone number, or a contact name (e.g. "Mom") which N3k resolves via Contacts if permission is granted. Returns requires_contacts_permission if a name was given but access has not been granted yet — call requestContactsAccess first in that case.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            phoneNumber: { type: Type.STRING, description: 'A phone number OR a contact name.' },
          },
          required: ['phoneNumber'],
        },
      },
      {
        name: 'prepareMessage',
        description:
          'Prepares an SMS or WhatsApp message to a recipient given as a phone number or a contact name (resolved via Contacts, SMS only). Returns requires_contacts_permission if a name was given but access has not been granted yet.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            recipient: { type: Type.STRING, description: 'A phone number OR a contact name.' },
            text: { type: Type.STRING },
            app: { type: Type.STRING, description: '"sms" or "whatsapp"' },
          },
          required: ['recipient', 'text'],
        },
      },
      {
        name: 'readNotifications',
        description:
          'Reads recent real Android system notifications (title, app, text) from other apps. Requires the user to have granted N3k "Notification access" in Android Settings; returns requires_notification_access if not granted.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            limit: { type: Type.NUMBER, description: 'Max notifications to return, default 10, max 50.' },
          },
        },
      },
      {
        name: 'openNotificationAccessSettings',
        description:
          'Opens Android Settings > Notification access so the user can grant N3k permission to read incoming notifications.',
        parameters: {
          type: Type.OBJECT,
          properties: {},
        },
      },
      {
        name: 'searchGitHub',
        description: 'Searches GitHub repositories for a given topic or query.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            query: { type: Type.STRING },
          },
          required: ['query'],
        },
      },
      {
        name: 'controlPcWindow',
        description: 'Minimizes, maximizes, closes, or switches (Alt+Tab) the active window on the Windows PC.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            operation: { type: Type.STRING, description: '"minimize", "maximize", "close", or "switch"' },
          },
          required: ['operation'],
        },
      },
      {
        name: 'manageClipboard',
        description: 'Copies text to or reads text from the system clipboard.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            operation: { type: Type.STRING, description: '"set" or "get"' },
            text: { type: Type.STRING },
          },
          required: ['operation'],
        },
      },
      {
        name: 'stopSpeaking',
        description: 'Immediately stops N3k voice output when the user asks to stop speaking.',
        parameters: {
          type: Type.OBJECT,
          properties: {},
        },
      },
      {
        name: 'cancelPendingAction',
        description: 'Cancels any pending confirmation action.',
        parameters: {
          type: Type.OBJECT,
          properties: {},
        },
      },
      {
        name: 'set3DCameraPreset',
        description: 'Changes the 3D N3k Avatar camera angle ("portrait", "close_up", "upper_body", "cinematic").',
        parameters: {
          type: Type.OBJECT,
          properties: {
            preset: { type: Type.STRING, description: '"portrait", "close_up", "upper_body", or "cinematic"' },
          },
          required: ['preset'],
        },
      },
    ],
  },
];

export function setupLiveWebSocket(server: any) {
  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request: IncomingMessage, socket: any, head: any) => {
    const { pathname } = new URL(request.url || '', `http://${request.headers.host}`);
    if (pathname === '/live' || pathname === '/api/live') {
      wss.handleUpgrade(request, socket, head, (ws) => {
        wss.emit('connection', ws, request);
      });
    }
  });

  wss.on('connection', async (clientWs: WebSocket) => {
    console.log('[N3k Live] Client connected');
    let liveSession: any = null;
    let isSessionOpen = false;

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      console.error('[N3k Live] GEMINI_API_KEY is not defined in environment');
      clientWs.send(
        JSON.stringify({
          type: 'error',
          message: 'Server GEMINI_API_KEY is missing. Check your settings.',
        }),
      );
      clientWs.close();
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const initLiveSession = async (
      voice = 'Fenrir',
      preferredModel = 'gemini-3.8-live',
      memoryContext = '',
    ) => {
      const modelsToTry = [
        'gemini-3.8-live',
        preferredModel,
        'gemini-3.1-flash-live-preview',
        'gemini-2.5-flash-native-audio-preview-12-2025',
      ].filter((val, idx, self) => Boolean(val) && self.indexOf(val) === idx);

      let lastError: any = null;
      const dynamicSystemInstruction =
        BASE_ZINXN3K_SYSTEM_INSTRUCTION + (memoryContext ? `\n${memoryContext}` : '');

      for (const model of modelsToTry) {
        try {
          console.log(`[N3k Live] Connecting to Gemini Live (${model}, voice: ${voice})...`);
          const session = await ai.live.connect({
            model,
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: {
                    voiceName: voice,
                  },
                },
              },
              systemInstruction: dynamicSystemInstruction,
              tools: ZINXN3K_TOOLS as any,
            },
            callbacks: {
              onmessage: (message: LiveServerMessage) => {
                try {
                  if (message.serverContent?.modelTurn?.parts) {
                    for (const part of message.serverContent.modelTurn.parts) {
                      if (part.inlineData?.data) {
                        if (clientWs.readyState === WebSocket.OPEN) {
                          clientWs.send(
                            JSON.stringify({
                              type: 'audio',
                              data: part.inlineData.data,
                            }),
                          );
                        }
                      }
                    }
                  }

                  if (message.serverContent?.interrupted) {
                    if (clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(JSON.stringify({ type: 'interrupted' }));
                    }
                  }

                  if (message.serverContent?.turnComplete) {
                    if (clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(JSON.stringify({ type: 'turn_complete' }));
                    }
                  }

                  if (
                    message.toolCall?.functionCalls &&
                    message.toolCall.functionCalls.length > 0
                  ) {
                    const calls = message.toolCall.functionCalls;
                    console.log(
                      '[N3k Live] Forwarding tool calls to client ToolManager:',
                      calls.map((c) => c.name),
                    );

                    if (clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(
                        JSON.stringify({
                          type: 'tool_call',
                          calls,
                        }),
                      );
                    }
                  }
                } catch (msgErr) {
                  console.error('[N3k Live] Error handling live message:', msgErr);
                }
              },
              onerror: (err) => {
                console.error(`[N3k Live] Error on model ${model}:`, err);
                if (clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(
                    JSON.stringify({
                      type: 'error',
                      message: 'Live session encountered a connection error.',
                    }),
                  );
                }
              },
              onclose: (e) => {
                console.log(`[N3k Live] Model ${model} closed:`, e.code, e.reason);
                isSessionOpen = false;
                if (clientWs.readyState === WebSocket.OPEN) {
                  clientWs.send(
                    JSON.stringify({
                      type: 'session_closed',
                      code: e.code,
                      reason: e.reason,
                    }),
                  );
                }
              },
            },
          });

          liveSession = session;
          isSessionOpen = true;
          console.log(`[N3k Live] Successfully connected with ${model}!`);

          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(
              JSON.stringify({
                type: 'ready',
                model,
                voice,
                name: 'N3k',
              }),
            );
          }

          return session;
        } catch (err: any) {
          console.warn(`[N3k Live] Failed with ${model}:`, err?.message || err);
          lastError = err;
        }
      }

      throw lastError || new Error('All Live API models failed to connect');
    };

    clientWs.on('message', async (data) => {
      try {
        const msg = JSON.parse(data.toString());

        if (msg.type === 'init') {
          const voice = msg.voice || 'Fenrir';
          const model = msg.model || 'gemini-3.8-live';
          const memoryContext = msg.memoryContext || '';
          try {
            await initLiveSession(voice, model, memoryContext);
          } catch (initErr: any) {
            console.error('[N3k Live] Init error:', initErr);
            clientWs.send(
              JSON.stringify({
                type: 'error',
                message: initErr?.message || 'Could not start live session',
              }),
            );
          }
          return;
        }

        if (msg.type === 'audio') {
          if (!liveSession || !isSessionOpen) {
            await initLiveSession('Fenrir');
          }
          if (liveSession && msg.data) {
            liveSession.sendRealtimeInput({
              audio: {
                data: msg.data,
                mimeType: 'audio/pcm;rate=16000',
              },
            });
          }
          return;
        }

        if (msg.type === 'video') {
          if (liveSession && isSessionOpen && msg.data) {
            liveSession.sendRealtimeInput({
              video: {
                data: msg.data,
                mimeType: 'image/jpeg',
              },
            });
          }
          return;
        }

        if (msg.type === 'text') {
          if (!liveSession || !isSessionOpen) {
            await initLiveSession('Fenrir');
          }
          if (liveSession && msg.text) {
            try {
              liveSession.sendClientContent({
                turns: [
                  {
                    role: 'user',
                    parts: [{ text: String(msg.text) }],
                  },
                ],
                turnComplete: true,
              });
            } catch (textErr) {
              console.error('[N3k Live] Error sending client text turn:', textErr);
            }
          }
          return;
        }

        if (msg.type === 'ping') {
          clientWs.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
          return;
        }

        if (msg.type === 'tool_results' && Array.isArray(msg.responses)) {
          if (liveSession && isSessionOpen) {
            try {
              console.log(
                '[N3k Live] Sending real tool responses to Gemini Live:',
                msg.responses.map((r: any) => r.name),
              );
              liveSession.sendToolResponse({
                functionResponses: msg.responses,
              });
            } catch (toolErr) {
              console.error('[N3k Live] Error sending tool_results to Gemini:', toolErr);
            }
          }
          return;
        }

        if (msg.type === 'tool_result') {
          if (liveSession && isSessionOpen && msg.id && msg.name) {
            try {
              liveSession.sendToolResponse({
                functionResponses: [
                  {
                    name: msg.name,
                    id: msg.id,
                    response: msg.response || { status: 'success' },
                  },
                ],
              });
            } catch (toolErr) {
              console.error('[N3k Live] Error sending single tool_result:', toolErr);
            }
          }
          return;
        }
      } catch (err) {
        console.error('[N3k Live] Error parsing client message:', err);
      }
    });

    clientWs.on('close', () => {
      console.log('[N3k Live] Client disconnected');
      isSessionOpen = false;
      if (liveSession) {
        try {
          liveSession.close();
        } catch (closeErr) {
          console.error('[N3k Live] Error closing session:', closeErr);
        }
        liveSession = null;
      }
    });

    clientWs.on('error', (err) => {
      console.error('[N3k Live] Client WebSocket error:', err);
      if (liveSession) {
        try {
          liveSession.close();
        } catch {}
      }
    });
  });

  return wss;
}
