package ai.n3k.assistant

import android.app.Notification
import android.content.Context
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import androidx.core.app.NotificationManagerCompat
import org.json.JSONArray
import org.json.JSONObject

/**
 * Real Android NotificationListenerService for N3k.
 *
 * This ONLY receives notification content after the user explicitly grants
 * "Notification access" to N3k in Android Settings (Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).
 * There is no way to read notifications without that explicit, revocable OS-level grant, and the
 * system shows a persistent indicator while access is active. N3k never claims this is enabled
 * unless `isEnabled()` confirms Android has actually bound this service.
 */
class N3kNotificationListenerService : NotificationListenerService() {

    data class N3kSystemNotification(
        val packageName: String,
        val appLabel: String,
        val title: String,
        val text: String,
        val postTimeMs: Long,
    )

    companion object {
        @Volatile
        var instance: N3kNotificationListenerService? = null
            private set

        private const val MAX_BUFFER = 50
        private val recent = ArrayDeque<N3kSystemNotification>()

        @Synchronized
        private fun push(item: N3kSystemNotification) {
            recent.addFirst(item)
            while (recent.size > MAX_BUFFER) recent.removeLast()
        }

        @Synchronized
        fun getRecentJson(limit: Int): String {
            val arr = JSONArray()
            recent.asSequence().take(limit.coerceIn(1, MAX_BUFFER)).forEach { n ->
                arr.put(
                    JSONObject()
                        .put("packageName", n.packageName)
                        .put("appLabel", n.appLabel)
                        .put("title", n.title)
                        .put("text", n.text)
                        .put("postTimeMs", n.postTimeMs)
                )
            }
            return arr.toString()
        }

        /** True only when Android itself confirms N3k is a bound, active notification listener. */
        fun isEnabled(context: Context): Boolean {
            return NotificationManagerCompat.getEnabledListenerPackages(context)
                .contains(context.packageName)
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        if (instance === this) instance = null
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Ignore N3k's own notifications so it never "reads itself".
        if (sbn.packageName == packageName) return

        val extras = sbn.notification?.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isEmpty() && text.isEmpty()) return

        val appLabel = try {
            val pm = applicationContext.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
        } catch (e: Exception) {
            sbn.packageName
        }

        push(
            N3kSystemNotification(
                packageName = sbn.packageName,
                appLabel = appLabel,
                title = title,
                text = text,
                postTimeMs = sbn.postTime,
            )
        )
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        // No-op: N3k only surfaces what was posted, never fabricates removal-based state.
    }
}
