package ai.n3k.assistant

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var actionManager: AndroidActionManager

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, N3kMediaProjectionService::class.java).apply {
                action = N3kMediaProjectionService.ACTION_START
                putExtra(N3kMediaProjectionService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(N3kMediaProjectionService.EXTRA_RESULT_DATA, result.data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
        } else {
            notifyWebMediaProjectionState(false, "MediaProjection permission was declined.")
        }
    }

    private val runtimePermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        syncCapabilitiesToWeb()
    }

    // Contacts is sensitive, so it is never requested at startup — only lazily, the moment the
    // user actually asks N3k to call or message someone by name.
    private val contactsPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        syncCapabilitiesToWeb()
    }

    fun requestContactsPermission() {
        contactsPermissionLauncher.launch(Manifest.permission.READ_CONTACTS)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        actionManager = AndroidActionManager(this)
        webView = WebView(this)
        setContentView(webView)

        N3kMediaProjectionService.onStateChangedListener = { active ->
            runOnUiThread {
                notifyWebMediaProjectionState(active, null)
            }
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        }

        val bridge = N3kNativeBridge(this, actionManager)
        webView.addJavascriptInterface(bridge, "N3kAndroidBridge")
        webView.addJavascriptInterface(bridge, "ZinxN3kAndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                syncCapabilitiesToWeb()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                request?.grant(request.resources)
            }
        }

        requestInitialRuntimePermissions()
        webView.loadUrl(BuildConfig.N3K_BACKEND_URL)
    }

    override fun onResume() {
        super.onResume()
        syncCapabilitiesToWeb()
    }

    private fun requestInitialRuntimePermissions() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.RECORD_AUDIO)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (needed.isNotEmpty()) {
            runtimePermissionLauncher.launch(needed.toTypedArray())
        }
    }

    fun requestMediaProjectionPermission() {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    fun stopMediaProjectionService() {
        val serviceIntent = Intent(this, N3kMediaProjectionService::class.java).apply {
            action = N3kMediaProjectionService.ACTION_STOP
        }
        startService(serviceIntent)
    }

    private fun notifyWebMediaProjectionState(active: Boolean, error: String?) {
        val errArg = if (error != null) "'${error.replace("'", "\\'")}'" else "null"
        webView.evaluateJavascript(
            "window.dispatchEvent(new CustomEvent('n3k:mediaprojection:state', { detail: { active: $active, error: $errArg } }));",
            null
        )
    }

    private fun syncCapabilitiesToWeb() {
        webView.evaluateJavascript(
            "window.dispatchEvent(new CustomEvent('n3k:android:sync'));",
            null
        )
    }
}
