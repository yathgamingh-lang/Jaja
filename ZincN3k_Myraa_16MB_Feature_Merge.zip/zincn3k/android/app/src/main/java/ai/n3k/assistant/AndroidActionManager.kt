package ai.n3k.assistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat
import org.json.JSONObject

class AndroidActionManager(private val context: Context) {

    private val commonAliases = mapOf(
        "youtube" to listOf("com.google.android.youtube", "com.google.android.youtube.tv"),
        "chrome" to listOf("com.android.chrome", "com.chrome.beta"),
        "notes" to listOf(
            "com.google.android.keep",
            "com.samsung.android.app.notes",
            "com.miui.notes",
            "com.OnePlus.note"
        ),
        "keep" to listOf("com.google.android.keep"),
        "calculator" to listOf(
            "com.google.android.calculator",
            "com.sec.android.app.popupcalculator",
            "com.android.calculator2"
        ),
        "settings" to listOf("com.android.settings"),
        "maps" to listOf("com.google.android.apps.maps"),
        "gmail" to listOf("com.google.android.gm"),
        "spotify" to listOf("com.spotify.music"),
        "whatsapp" to listOf("com.whatsapp")
    )

    /**
     * Resolves an app name or package name via Android PackageManager and launches its real Intent.
     */
    fun openApp(packageOrName: String): JSONObject {
        val clean = packageOrName.trim()
        if (clean.isEmpty()) {
            return JSONObject()
                .put("status", "error")
                .put("message", "App name or package name is required.")
        }

        val pm = context.packageManager
        val candidates = mutableListOf<String>()

        if (clean.contains(".")) {
            candidates.add(clean)
        }

        val lower = clean.lowercase()
        commonAliases[lower]?.let { candidates.addAll(it) }

        // Search installed launcher apps by label if not matched yet
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        for (info in resolveInfos) {
            val label = info.loadLabel(pm).toString().lowercase()
            val pkg = info.activityInfo.packageName
            if (label == lower || label.contains(lower)) {
                candidates.add(pkg)
            }
        }

        for (pkg in candidates.distinct()) {
            val launchIntent = pm.getLaunchIntentForPackage(pkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return try {
                    context.startActivity(launchIntent)
                    JSONObject()
                        .put("status", "success")
                        .put("packageName", pkg)
                        .put("appName", clean)
                        .put("message", "Launched $clean ($pkg) via Android PackageManager.")
                } catch (e: Exception) {
                    JSONObject()
                        .put("status", "error")
                        .put("packageName", pkg)
                        .put("message", "Failed to start $clean: ${e.message}")
                }
            }
        }

        return JSONObject()
            .put("status", "not_installed")
            .put("appName", clean)
            .put("message", "$clean is not installed on this Android device.")
    }

    fun openUrl(url: String): JSONObject {
        return try {
            val normalized = if (url.startsWith("http://") || url.startsWith("https://")) {
                url
            } else {
                "https://$url"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(normalized)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            JSONObject()
                .put("status", "success")
                .put("url", normalized)
                .put("message", "Opened $normalized in Android browser.")
        } catch (e: Exception) {
            JSONObject()
                .put("status", "error")
                .put("message", e.message ?: "Failed to open URL")
        }
    }

    fun searchYouTubeNative(query: String): JSONObject {
        val pm = context.packageManager
        val ytPkg = "com.google.android.youtube"
        val isYtInstalled = try {
            pm.getPackageInfo(ytPkg, 0)
            true
        } catch (_: PackageManager.NameNotFoundException) {
            false
        }

        return try {
            if (isYtInstalled) {
                val intent = Intent(Intent.ACTION_SEARCH).apply {
                    setPackage(ytPkg)
                    putExtra("query", query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                JSONObject()
                    .put("status", "success")
                    .put("packageName", ytPkg)
                    .put("query", query)
                    .put("message", "Launched YouTube app search for '$query'.")
            } else {
                openUrl("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
            }
        } catch (e: Exception) {
            openUrl("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        }
    }

    fun openSettings(section: String?): JSONObject {
        val action = when (section?.lowercase()?.trim()) {
            "accessibility" -> Settings.ACTION_ACCESSIBILITY_SETTINGS
            "wifi", "wireless", "wi-fi" -> Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
            "battery", "power" -> Intent.ACTION_POWER_USAGE_SUMMARY
            "display", "brightness" -> Settings.ACTION_DISPLAY_SETTINGS
            "storage" -> Settings.ACTION_INTERNAL_STORAGE_SETTINGS
            "hotspot", "tethering" -> Settings.ACTION_WIRELESS_SETTINGS
            "notifications", "notification" -> Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS
            "dnd", "do_not_disturb", "do not disturb" -> Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS
            "sound", "audio" -> Settings.ACTION_SOUND_SETTINGS
            "apps", "applications" -> Settings.ACTION_APPLICATION_SETTINGS
            else -> Settings.ACTION_SETTINGS
        }

        return try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            JSONObject()
                .put("status", "success")
                .put("section", section ?: "main")
                .put("message", "Opened Android Settings ($action).")
        } catch (e: Exception) {
            JSONObject()
                .put("status", "error")
                .put("message", "Could not open Android Settings: ${e.message}")
        }
    }

    fun setFlashlight(enabled: Boolean): JSONObject {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull()
                ?: return JSONObject().put("status", "error").put("message", "No camera flash hardware found.")
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                cameraManager.setTorchMode(cameraId, enabled)
                JSONObject()
                    .put("status", "success")
                    .put("enabled", enabled)
                    .put("message", if (enabled) "Flashlight turned ON." else "Flashlight turned OFF.")
            } else {
                JSONObject().put("status", "error").put("message", "Torch API requires Android M+.")
            }
        } catch (e: Exception) {
            JSONObject().put("status", "error").put("message", "Flashlight control failed: ${e.message}")
        }
    }

    fun setBrightness(levelPercent: Int): JSONObject {
        val clamped = levelPercent.coerceIn(0, 100)
        return try {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M && !Settings.System.canWrite(context)) {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return JSONObject()
                    .put("status", "requires_permission")
                    .put("level", clamped)
                    .put("message", "Grant Modify System Settings permission to allow direct brightness changes.")
            }
            val sysVal = ((clamped / 100.0) * 255).toInt().coerceIn(1, 255)
            Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, sysVal)
            JSONObject()
                .put("status", "success")
                .put("level", clamped)
                .put("message", "Set screen brightness to $clamped%.")
        } catch (e: Exception) {
            openSettings("display")
        }
    }

    fun setAlarm(hour: Int, minute: Int, message: String): JSONObject {
        return try {
            val intent = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
                putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, message)
                putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            JSONObject()
                .put("status", "success")
                .put("hour", hour)
                .put("minute", minute)
                .put("message", "Prepared Android system alarm for %02d:%02d (%s).".format(hour, minute, message))
        } catch (e: Exception) {
            JSONObject().put("status", "error").put("message", "Could not set alarm: ${e.message}")
        }
    }

    private fun hasContactsPermission(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) ==
            PackageManager.PERMISSION_GRANTED
    }

    private fun looksLikePhoneNumber(s: String): Boolean {
        return s.count { it.isDigit() } >= 5 && s.none { it.isLetter() }
    }

    /**
     * Resolves a contact display name to a real phone number via ContactsContract.
     * Returns null if contacts permission isn't granted or no match is found — never fabricates a number.
     */
    private fun resolveContactNumber(name: String): String? {
        if (!hasContactsPermission()) return null
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER)
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$name%")
        resolver.query(uri, projection, selection, args, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                if (idx >= 0) return cursor.getString(idx)
            }
        }
        return null
    }

    fun dialPhone(recipient: String): JSONObject {
        var phoneNumber = recipient
        if (!looksLikePhoneNumber(recipient)) {
            if (!hasContactsPermission()) {
                return JSONObject()
                    .put("status", "requires_contacts_permission")
                    .put("recipient", recipient)
                    .put(
                        "message",
                        "Enable Contacts access so N3k can look up \"$recipient\" by name. Grant it, then try again."
                    )
            }
            val resolved = resolveContactNumber(recipient)
                ?: return JSONObject()
                    .put("status", "not_found")
                    .put("recipient", recipient)
                    .put("message", "No contact matching \"$recipient\" was found.")
            phoneNumber = resolved
        }
        return try {
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phoneNumber)}")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            JSONObject()
                .put("status", "success")
                .put("phoneNumber", phoneNumber)
                .put("message", "Opened Android Phone Dialer for $phoneNumber.")
        } catch (e: Exception) {
            JSONObject().put("status", "error").put("message", "Could not open dialer: ${e.message}")
        }
    }

    fun prepareMessage(recipient: String, text: String, app: String): JSONObject {
        var target = recipient
        if (!looksLikePhoneNumber(recipient) && !app.lowercase().contains("whatsapp")) {
            if (!hasContactsPermission()) {
                return JSONObject()
                    .put("status", "requires_contacts_permission")
                    .put("recipient", recipient)
                    .put(
                        "message",
                        "Enable Contacts access so N3k can look up \"$recipient\" by name. Grant it, then try again."
                    )
            }
            val resolved = resolveContactNumber(recipient)
                ?: return JSONObject()
                    .put("status", "not_found")
                    .put("recipient", recipient)
                    .put("message", "No contact matching \"$recipient\" was found.")
            target = resolved
        }
        return try {
            if (app.lowercase().contains("whatsapp")) {
                val url = "https://api.whatsapp.com/send?phone=${Uri.encode(target)}&text=${Uri.encode(text)}"
                return openUrl(url)
            }
            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(target)}")).apply {
                putExtra("sms_body", text)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            JSONObject()
                .put("status", "success")
                .put("recipient", target)
                .put("message", "Prepared SMS to $target.")
        } catch (e: Exception) {
            JSONObject().put("status", "error").put("message", "Could not prepare message: ${e.message}")
        }
    }

    fun getInstalledGames(): JSONObject {
        val pm = context.packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(mainIntent, 0)
        val gamesArray = org.json.JSONArray()

        for (info in resolveInfos) {
            val appInfo = info.activityInfo.applicationInfo
            val pkg = info.activityInfo.packageName
            val label = info.loadLabel(pm).toString()
            val isGameCategory = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                appInfo.category == android.content.pm.ApplicationInfo.CATEGORY_GAME
            } else {
                (appInfo.flags and android.content.pm.ApplicationInfo.FLAG_IS_GAME) != 0
            }

            if (isGameCategory || pkg.contains("game", ignoreCase = true) || pkg.contains("minecraft", ignoreCase = true) || pkg.contains("roblox", ignoreCase = true)) {
                gamesArray.put(
                    JSONObject()
                        .put("packageName", pkg)
                        .put("appName", label)
                )
            }
        }

        return JSONObject()
            .put("status", "success")
            .put("games", gamesArray)
            .put("count", gamesArray.length())
    }
}
