package ai.n3k.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * BootReceiver
 * Listens for Intent.ACTION_BOOT_COMPLETED and starts N3kWakeWordService
 * if the user has enabled Auto-Start on Boot in N3k Settings.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (
            intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON"
        ) {
            val prefs = context.getSharedPreferences("n3k_assistant_prefs", Context.MODE_PRIVATE)
            val autoStartEnabled = prefs.getBoolean("autostart_on_boot", false)
            if (autoStartEnabled) {
                val serviceIntent = Intent(context, N3kWakeWordService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            }
        }
    }
}
