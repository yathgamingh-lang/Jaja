package ai.n3k.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

class N3kAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: N3kAccessibilityService? = null
            private set

        @Volatile
        var currentForegroundPackage: String = "ai.n3k.assistant"
            private set

        fun isServiceEnabled(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.packageName != null) {
            currentForegroundPackage = event.packageName.toString()
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
    }

    fun performBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun performHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun performRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    /**
     * Inspects the active window's AccessibilityNodeInfo tree and returns visible text & clickable nodes.
     */
    fun getScreenInfoJson(): String {
        val root = rootInActiveWindow ?: return JSONObject()
            .put("status", "error")
            .put("message", "No active accessibility window available.")
            .toString()

        val texts = JSONArray()
        val clickables = JSONArray()
        val editables = JSONArray()

        fun traverse(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 18) return
            val nodeText = node.text?.toString()?.trim() ?: ""
            val contentDesc = node.contentDescription?.toString()?.trim() ?: ""
            val label = if (nodeText.isNotEmpty()) nodeText else contentDesc

            val bounds = Rect()
            node.getBoundsInScreen(bounds)

            if (label.isNotEmpty()) {
                texts.put(label)
            }
            if (node.isClickable && label.isNotEmpty()) {
                clickables.put(
                    JSONObject()
                        .put("label", label)
                        .put("className", node.className?.toString() ?: "")
                        .put("centerX", bounds.centerX())
                        .put("centerY", bounds.centerY())
                )
            }
            if (node.isEditable) {
                editables.put(
                    JSONObject()
                        .put("hint", node.hintText?.toString() ?: label)
                        .put("focused", node.isFocused)
                        .put("centerX", bounds.centerX())
                        .put("centerY", bounds.centerY())
                )
            }

            for (i in 0 until node.childCount) {
                traverse(node.getChild(i), depth + 1)
            }
        }

        traverse(root, 0)

        return JSONObject()
            .put("status", "success")
            .put("packageName", root.packageName?.toString() ?: currentForegroundPackage)
            .put("visibleTexts", texts)
            .put("clickableElements", clickables)
            .put("editableFields", editables)
            .toString()
    }

    /**
     * Finds a node matching the target text and clicks it or its clickable parent.
     */
    fun clickNodeByText(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matchedNodes = root.findAccessibilityNodeInfosByText(targetText)
        if (matchedNodes.isNullOrEmpty()) return false

        for (node in matchedNodes) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable) {
                    return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                current = current.parent
            }
        }
        return false
    }

    /**
     * Dispatches a tap gesture at the given screen coordinates.
     */
    fun clickAtCoordinate(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 80)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        return dispatchGesture(gesture, null, null)
    }

    /**
     * Finds an editable field (focused first, or first available editable node) and inserts text via ACTION_SET_TEXT.
     */
    fun insertTextIntoEditable(text: String): JSONObject {
        val root = rootInActiveWindow ?: return JSONObject()
            .put("status", "error")
            .put("message", "No active window found to type text into.")

        var targetNode: AccessibilityNodeInfo? = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (targetNode == null || !targetNode.isEditable) {
            targetNode = findFirstEditableNode(root)
        }

        if (targetNode == null) {
            return JSONObject()
                .put("status", "error")
                .put("message", "Android did not expose a compatible editable text field in the current screen.")
        }

        targetNode.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        targetNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        val ok = targetNode.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        return if (ok) {
            JSONObject()
                .put("status", "success")
                .put("packageName", root.packageName?.toString() ?: "")
                .put("typedText", text)
                .put("message", "Successfully inserted text into the active editable field.")
        } else {
            JSONObject()
                .put("status", "error")
                .put("message", "Target field rejected ACTION_SET_TEXT.")
        }
    }

    private fun findFirstEditableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstEditableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }

    /**
     * Scrolls the first scrollable container in the requested direction ('up', 'down', 'left', 'right').
     */
    fun scrollScreen(direction: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val scrollable = findFirstScrollableNode(root) ?: return false
        val action = when (direction.lowercase()) {
            "down", "forward" -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            "up", "backward" -> AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
            else -> AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
        }
        return scrollable.performAction(action)
    }

    private fun findFirstScrollableNode(node: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (node == null) return null
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val found = findFirstScrollableNode(node.getChild(i))
            if (found != null) return found
        }
        return null
    }
}
