package ai.n3k.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.webkit.JavascriptInterface
import androidx.core.content.ContextCompat
import org.json.JSONObject

class N3kNativeBridge(
    private val activity: MainActivity,
    private val actionManager: AndroidActionManager
) {

    @JavascriptInterface
    fun getPlatformCapabilities(): String {
        val micGranted = ContextCompat.checkSelfPermission(
            activity,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        val camGranted = ContextCompat.checkSelfPermission(
            activity,
            Manifest.permission.CAMERA
        ) == PackageManager.PERMISSION_GRANTED

        val notifGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                activity,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        val contactsGranted = ContextCompat.checkSelfPermission(
            activity,
            Manifest.permission.READ_CONTACTS
        ) == PackageManager.PERMISSION_GRANTED

        return JSONObject()
            .put("isAndroidNative", true)
            .put("accessibilityEnabled", N3kAccessibilityService.isServiceEnabled())
            .put("mediaProjectionActive", N3kMediaProjectionService.isProjectionActive)
            .put("mediaProjectionPaused", N3kMediaProjectionService.isPaused)
            .put("foregroundPackage", N3kAccessibilityService.currentForegroundPackage)
            .put("micGranted", micGranted)
            .put("cameraGranted", camGranted)
            .put("notificationsGranted", notifGranted)
            .put("notificationListenerEnabled", N3kNotificationListenerService.isEnabled(activity))
            .put("contactsGranted", contactsGranted)
            .toString()
    }

    @JavascriptInterface
    fun requestContactsPermission(): String {
        activity.requestContactsPermission()
        return JSONObject()
            .put("status", "requesting")
            .put("message", "Requested Android Contacts permission dialog.")
            .toString()
    }

    @JavascriptInterface
    fun openApp(packageOrName: String): String {
        return actionManager.openApp(packageOrName).toString()
    }

    @JavascriptInterface
    fun openUrl(url: String): String {
        return actionManager.openUrl(url).toString()
    }

    @JavascriptInterface
    fun searchYouTube(query: String): String {
        return actionManager.searchYouTubeNative(query).toString()
    }

    @JavascriptInterface
    fun openSettings(section: String?): String {
        return actionManager.openSettings(section).toString()
    }

    @JavascriptInterface
    fun openAccessibilitySettings(): String {
        return actionManager.openSettings("accessibility").toString()
    }

    @JavascriptInterface
    fun goBack(): String {
        val service = N3kAccessibilityService.instance
            ?: return JSONObject()
                .put("status", "requires_accessibility")
                .put("message", "Enable the N3k Accessibility Service in Android Settings to perform global Back.")
                .toString()

        val ok = service.performBack()
        return JSONObject()
            .put("status", if (ok) "success" else "error")
            .put("message", if (ok) "Performed Android global Back action." else "Global Back failed.")
            .toString()
    }

    @JavascriptInterface
    fun goHome(): String {
        val service = N3kAccessibilityService.instance
            ?: return JSONObject()
                .put("status", "requires_accessibility")
                .put("message", "Enable the N3k Accessibility Service in Android Settings to perform global Home.")
                .toString()

        val ok = service.performHome()
        return JSONObject()
            .put("status", if (ok) "success" else "error")
            .put("message", if (ok) "Performed Android global Home action." else "Global Home failed.")
            .toString()
    }

    @JavascriptInterface
    fun openRecents(): String {
        val service = N3kAccessibilityService.instance
            ?: return JSONObject()
                .put("status", "requires_accessibility")
                .put("message", "Enable the N3k Accessibility Service in Android Settings to open Recents.")
                .toString()

        val ok = service.performRecents()
        return JSONObject()
            .put("status", if (ok) "success" else "error")
            .put("message", if (ok) "Opened Android Recent Apps." else "Open Recents failed.")
            .toString()
    }

    @JavascriptInterface
    fun typeText(text: String): String {
        val service = N3kAccessibilityService.instance
            ?: return JSONObject()
                .put("status", "requires_accessibility")
                .put("message", "Enable the N3k Accessibility Service in Android Settings to type text into apps.")
                .toString()

        return service.insertTextIntoEditable(text).toString()
    }

    @JavascriptInterface
    fun clickText(text: String): String {
        val service = N3kAccessibilityService.instance
            ?: return JSONObject()
                .put("status", "requires_accessibility")
                .put("message", "Enable the N3k Accessibility Service in Android Settings to click screen elements.")
                .toString()

        val ok = service.clickNodeByText(text)
        return JSONObject()
            .put("status", if (ok) "success" else "not_found")
            .put(
                "message",
                if (ok) "Clicked element matching '$text'." else "No clickable element matching '$text' was found."
            )
            .toString()
    }

    @JavascriptInterface
    fun clickCoordinate(x: Float, y: Float): String {
        val service = N3kAccessibilityService.instance
            ?: return JSONObject()
                .put("status", "requires_accessibility")
                .put("message", "Enable the N3k Accessibility Service in Android Settings to perform tap gestures.")
                .toString()

        val ok = service.clickAtCoordinate(x, y)
        return JSONObject()
            .put("status", if (ok) "success" else "error")
            .put("message", if (ok) "Tapped coordinate ($x, $y)." else "Coordinate tap failed.")
            .toString()
    }

    @JavascriptInterface
    fun scroll(direction: String): String {
        val service = N3kAccessibilityService.instance
            ?: return JSONObject()
                .put("status", "requires_accessibility")
                .put("message", "Enable the N3k Accessibility Service in Android Settings to scroll.")
                .toString()

        val ok = service.scrollScreen(direction)
        return JSONObject()
            .put("status", if (ok) "success" else "error")
            .put("message", if (ok) "Scrolled $direction." else "No scrollable view found.")
            .toString()
    }

    @JavascriptInterface
    fun getScreenInfo(): String {
        val service = N3kAccessibilityService.instance
            ?: return JSONObject()
                .put("status", "requires_accessibility")
                .put("message", "Enable the N3k Accessibility Service in Android Settings to inspect the UI tree.")
                .toString()

        return service.getScreenInfoJson()
    }

    @JavascriptInterface
    fun startScreenShare(): String {
        activity.requestMediaProjectionPermission()
        return JSONObject()
            .put("status", "requesting")
            .put("message", "Requested Android MediaProjection system dialog.")
            .toString()
    }

    @JavascriptInterface
    fun stopScreenShare(): String {
        activity.stopMediaProjectionService()
        return JSONObject()
            .put("status", "stopped")
            .put("message", "Stopped Android MediaProjection service.")
            .toString()
    }

    @JavascriptInterface
    fun setScreenVisionPaused(paused: Boolean): String {
        N3kMediaProjectionService.isPaused = paused
        return JSONObject()
            .put("status", "success")
            .put("paused", paused)
            .toString()
    }

    @JavascriptInterface
    fun captureCurrentScreen(): String {
        if (!N3kMediaProjectionService.isProjectionActive) {
            return JSONObject()
                .put("status", "not_active")
                .put("message", "MediaProjection is not active. Start Screen Vision first.")
                .toString()
        }
        val frameBase64 = N3kMediaProjectionService.captureCurrentFrameBase64()
            ?: return JSONObject()
                .put("status", "error")
                .put("message", "Could not acquire frame from MediaProjection ImageReader.")
                .toString()

        return JSONObject()
            .put("status", "success")
            .put("imageBase64", frameBase64)
            .toString()
    }

    @JavascriptInterface
    fun getInstalledGames(): String {
        return actionManager.getInstalledGames().toString()
    }

    @JavascriptInterface
    fun setWakeWordServiceEnabled(enabled: Boolean): String {
        val intent = android.content.Intent(activity, N3kWakeWordService::class.java)
        if (enabled) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                activity.startForegroundService(intent)
            } else {
                activity.startService(intent)
            }
        } else {
            activity.stopService(intent)
        }
        return JSONObject()
            .put("status", "success")
            .put("enabled", enabled)
            .put("message", if (enabled) "Android N3kWakeWordService started." else "Android N3kWakeWordService stopped.")
            .toString()
    }

    @JavascriptInterface
    fun setAutoStartOnBoot(enabled: Boolean): String {
        val prefs = activity.getSharedPreferences("n3k_assistant_prefs", android.content.Context.MODE_PRIVATE)
        prefs.edit().putBoolean("autostart_on_boot", enabled).apply()
        return JSONObject()
            .put("status", "success")
            .put("enabled", enabled)
            .put("message", "Saved Android RECEIVE_BOOT_COMPLETED preference ($enabled).")
            .toString()
    }

    @JavascriptInterface
    fun setFlashlight(enabled: Boolean): String {
        return actionManager.setFlashlight(enabled).toString()
    }

    @JavascriptInterface
    fun setBrightness(levelPercent: Int): String {
        return actionManager.setBrightness(levelPercent).toString()
    }

    @JavascriptInterface
    fun setAlarm(hour: Int, minute: Int, message: String): String {
        return actionManager.setAlarm(hour, minute, message).toString()
    }

    @JavascriptInterface
    fun dialPhone(phoneNumber: String): String {
        return actionManager.dialPhone(phoneNumber).toString()
    }

    @JavascriptInterface
    fun prepareMessage(recipient: String, text: String, app: String): String {
        return actionManager.prepareMessage(recipient, text, app).toString()
    }

    @JavascriptInterface
    fun getRecentNotifications(limit: Int): String {
        if (!N3kNotificationListenerService.isEnabled(activity)) {
            return JSONObject()
                .put("status", "requires_notification_access")
                .put(
                    "message",
                    "Enable N3k under Settings > Notification access to let it read incoming notifications."
                )
                .toString()
        }
        return JSONObject()
            .put("status", "success")
            .put("notifications", org.json.JSONArray(N3kNotificationListenerService.getRecentJson(limit)))
            .toString()
    }

    @JavascriptInterface
    fun openNotificationAccessSettings(): String {
        return actionManager.openSettings("notifications").toString()
    }
}
