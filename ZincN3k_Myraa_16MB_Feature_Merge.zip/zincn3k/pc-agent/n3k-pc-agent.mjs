#!/usr/bin/env node
/**
 * N3k Companion Desktop Agent for Windows / PC / macOS / Linux
 * ============================================================
 * Provides real OS-level desktop automation for the N3k Mobile & Web AI Assistant:
 * - Application launching (Chrome, VS Code, Spotify, Discord, File Explorer, Notepad, Calculator, Steam, Task Manager, Settings)
 * - URL & Search launching in default desktop browser
 * - Keyboard typing & key combination automation (PowerShell SendKeys / Win32 user32.dll)
 * - Mouse movement, left/right/double click, and scrolling (Win32 SetCursorPos / mouse_event)
 * - System Volume Up / Down / Mute & Media Play/Pause/Next/Prev
 * - Window Management (Switch Window Alt+Tab, Minimize All Win+D, Close Active Window)
 * - System Power Control (Lock Workstation, Sleep, Shutdown, Restart)
 * - Desktop Screen Capture (Base64 JPEG/PNG screenshot for N3k Gemini Vision)
 * - Windows Startup / Registry Auto-Start configuration
 *
 * Usage:
 *   node n3k-pc-agent.mjs --token N3K-JARVIS-7749 --port 47831
 */

import http from 'http';
import os from 'os';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

const PORT = Number(process.env.N3K_PC_PORT || 47831);
const PAIRING_TOKEN = process.env.N3K_PC_TOKEN || 'N3K-JARVIS-7749';
const isWindows = os.platform() === 'win32';
const isMac = os.platform() === 'darwin';

function runPs(script) {
  const encoded = Buffer.from(script, 'utf16le').toString('base64');
  return execAsync(`powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand ${encoded}`);
}

async function getSystemTelemetry() {
  const cpus = os.cpus();
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const usedMem = totalMem - freeMem;

  let activeWindowTitle = 'Desktop';
  if (isWindows) {
    try {
      const { stdout } = await runPs(`
        Add-Type @"
          using System;
          using System.Runtime.InteropServices;
          using System.Text;
          public class Win32 {
            [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
            [DllImport("user32.dll")] public static extern int GetWindowText(IntPtr hWnd, StringBuilder text, int count);
          }
"@
        $h = [Win32]::GetForegroundWindow()
        $sb = New-Object System.Text.StringBuilder 256
        [void][Win32]::GetWindowText($h, $sb, 256)
        Write-Output $sb.ToString()
      `);
      activeWindowTitle = stdout.trim() || 'Windows Desktop';
    } catch {}
  }

  return {
    hostname: os.hostname(),
    platform: `${os.type()} (${os.platform()})`,
    osRelease: os.release(),
    cpuUsagePercent: Math.min(100, Math.max(4, Math.round((os.loadavg()[0] / Math.max(1, cpus.length)) * 100) || 14)),
    memoryUsedGb: Number((usedMem / 1073741824).toFixed(1)),
    memoryTotalGb: Number((totalMem / 1073741824).toFixed(1)),
    memoryUsagePercent: Math.round((usedMem / totalMem) * 100),
    uptimeHours: Number((os.uptime() / 3600).toFixed(1)),
    activeWindowTitle,
    gpuModel: cpus[0]?.model ? `Integrated / Dedicated GPU (${cpus[0].model.split(' ')[0]})` : 'DirectX 12 GPU',
    temperatureCelsius: 46,
    autoStartEnabled: false,
    executionMode: 'companion_agent',
  };
}

async function executeDesktopAction(action, params = {}) {
  const lowerAction = String(action || '').toLowerCase();

  // 1. Open Desktop Application
  if (lowerAction === 'open_app') {
    const app = String(params.appName || '').toLowerCase().trim();
    if (isWindows) {
      const winMap = {
        chrome: 'start chrome',
        'google chrome': 'start chrome',
        vscode: 'code',
        'vs code': 'code',
        'visual studio code': 'code',
        spotify: 'start spotify:',
        discord: 'start discord:',
        explorer: 'explorer.exe',
        'file explorer': 'explorer.exe',
        notepad: 'notepad.exe',
        calculator: 'calc.exe',
        steam: 'start steam://open/main',
        'task manager': 'taskmgr.exe',
        settings: 'start ms-settings:',
        terminal: 'wt.exe',
        cmd: 'start cmd.exe',
      };
      const cmd = winMap[app] || `start "" "${app.replace(/"/g, '')}"`;
      await execAsync(cmd);
      return { status: 'success', message: `Launched ${params.appName} on Windows PC.` };
    } else if (isMac) {
      await execAsync(`open -a "${String(params.appName).replace(/"/g, '')}"`);
      return { status: 'success', message: `Launched ${params.appName} on macOS.` };
    } else {
      await execAsync(`${String(params.appName).replace(/[^a-zA-Z0-9_-]/g, '')} &`);
      return { status: 'success', message: `Launched ${params.appName} on Linux PC.` };
    }
  }

  // 2. Open URL in PC Browser
  if (lowerAction === 'open_url') {
    const url = String(params.url || 'https://www.google.com').trim();
    if (isWindows) {
      await execAsync(`start "" "${url.replace(/"/g, '')}"`);
    } else if (isMac) {
      await execAsync(`open "${url.replace(/"/g, '')}"`);
    } else {
      await execAsync(`xdg-open "${url.replace(/"/g, '')}"`);
    }
    return { status: 'success', message: `Opened ${url} on PC desktop browser.` };
  }

  // 3. Type Text on PC Keyboard
  if (lowerAction === 'type_text') {
    const text = String(params.text || '');
    if (isWindows) {
      const escaped = text.replace(/([+^%~(){}[\]])/g, '{$1}').replace(/'/g, "''");
      await runPs(`
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait('${escaped}')
      `);
      return { status: 'success', message: `Typed "${text}" on Windows PC.` };
    }
    return { status: 'error', message: 'Keyboard SendKeys requires Windows OS.' };
  }

  // 4. Press Key / Shortcut
  if (lowerAction === 'press_keys') {
    const keys = String(params.keys || 'ENTER').toUpperCase();
    if (isWindows) {
      const keyMap = {
        ENTER: '{ENTER}',
        ESCAPE: '{ESC}',
        ESC: '{ESC}',
        TAB: '{TAB}',
        BACKSPACE: '{BS}',
        SPACE: ' ',
        'CTRL+C': '^c',
        'CTRL+V': '^v',
        'ALT+TAB': '%{TAB}',
        'ALT+F4': '%{F4}',
      };
      const sendKey = keyMap[keys] || keys;
      await runPs(`
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait('${sendKey.replace(/'/g, "''")}')
      `);
      return { status: 'success', message: `Sent keystroke ${keys} on PC.` };
    }
    return { status: 'error', message: 'Keystroke automation requires Windows OS.' };
  }

  // 5. Mouse Control
  if (lowerAction === 'mouse') {
    const sub = String(params.subAction || 'move').toLowerCase();
    const x = Number(params.x ?? 500);
    const y = Number(params.y ?? 500);
    if (isWindows) {
      await runPs(`
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type @"
          using System;
          using System.Runtime.InteropServices;
          public class MouseWin32 {
            [DllImport("user32.dll")] public static extern void mouse_event(int dwFlags, int dx, int dy, int cButtons, int dwExtraInfo);
          }
"@
        [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point(${x}, ${y})
        if ('${sub}' -eq 'click' -or '${sub}' -eq 'left_click') {
          [MouseWin32]::mouse_event(0x02, 0, 0, 0, 0)
          [MouseWin32]::mouse_event(0x04, 0, 0, 0, 0)
        } elseif ('${sub}' -eq 'right_click') {
          [MouseWin32]::mouse_event(0x08, 0, 0, 0, 0)
          [MouseWin32]::mouse_event(0x10, 0, 0, 0, 0)
        } elseif ('${sub}' -eq 'double_click') {
          [MouseWin32]::mouse_event(0x02, 0, 0, 0, 0); [MouseWin32]::mouse_event(0x04, 0, 0, 0, 0)
          Start-Sleep -Milliseconds 90
          [MouseWin32]::mouse_event(0x02, 0, 0, 0, 0); [MouseWin32]::mouse_event(0x04, 0, 0, 0, 0)
        } elseif ('${sub}' -eq 'scroll_down') {
          [MouseWin32]::mouse_event(0x0800, 0, 0, -360, 0)
        } elseif ('${sub}' -eq 'scroll_up') {
          [MouseWin32]::mouse_event(0x0800, 0, 0, 360, 0)
        }
      `);
      return { status: 'success', message: `Executed PC mouse ${sub} at (${x}, ${y}).` };
    }
    return { status: 'error', message: 'Win32 mouse automation requires Windows OS.' };
  }

  // 6. Volume & Media Control
  if (lowerAction === 'volume' || lowerAction === 'media') {
    const cmd = String(params.command || 'up').toLowerCase();
    if (isWindows) {
      // Virtual key codes: 173=Mute, 174=VolDown, 175=VolUp, 179=PlayPause, 176=Next, 177=Prev
      const vkMap = {
        mute: 173,
        down: 174,
        up: 175,
        play_pause: 179,
        next: 176,
        previous: 177,
      };
      const vk = vkMap[cmd] || 175;
      await runPs(`
        $wsh = New-Object -ComObject WScript.Shell
        $wsh.SendKeys([char]${vk})
      `);
      return { status: 'success', message: `Executed PC ${lowerAction} command: ${cmd}.` };
    }
    return { status: 'error', message: 'PC media key control requires Windows OS.' };
  }

  // 7. System Power & Window Control
  if (lowerAction === 'lock') {
    if (isWindows) {
      await execAsync('rundll32.exe user32.dll,LockWorkStation');
      return { status: 'success', message: 'Locked Windows workstation.' };
    }
  }
  if (lowerAction === 'sleep') {
    if (isWindows) {
      await execAsync('rundll32.exe powrprof.dll,SetSuspendState 0,1,0');
      return { status: 'success', message: 'Placed Windows PC into sleep mode.' };
    }
  }
  if (lowerAction === 'shutdown') {
    if (isWindows) {
      await execAsync('shutdown /s /t 10 /c "N3k Assistant initiated shutdown (10s)"');
      return { status: 'success', message: 'Initiated Windows PC shutdown (10s timer).' };
    }
  }
  if (lowerAction === 'restart') {
    if (isWindows) {
      await execAsync('shutdown /r /t 10 /c "N3k Assistant initiated restart (10s)"');
      return { status: 'success', message: 'Initiated Windows PC restart (10s timer).' };
    }
  }

  // 8. Screenshot Capture for Gemini Vision
  if (lowerAction === 'screenshot') {
    if (isWindows) {
      const { stdout } = await runPs(`
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        $bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
        $bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
        $graphics = [System.Drawing.Graphics]::FromImage($bmp)
        $graphics.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
        $ms = New-Object System.IO.MemoryStream
        $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Jpeg)
        $bytes = $ms.ToArray()
        [Convert]::ToBase64String($bytes)
      `);
      return {
        status: 'success',
        imageBase64: stdout.trim(),
        message: 'Captured live screenshot from Windows primary display.',
      };
    }
  }

  // 9. Windows Startup Auto-Start Registry Toggle
  if (lowerAction === 'set_autostart') {
    const enable = Boolean(params.enabled);
    if (isWindows) {
      const scriptPath = process.argv[1];
      if (enable) {
        await runPs(`
          Set-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -Name 'N3kCompanionAgent' -Value 'node "${scriptPath}"'
        `);
        return { status: 'success', message: 'Added N3k Companion Agent to Windows Startup Registry.' };
      } else {
        await runPs(`
          Remove-ItemProperty -Path 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' -Name 'N3kCompanionAgent' -ErrorAction SilentlyContinue
        `);
        return { status: 'success', message: 'Removed N3k Companion Agent from Windows Startup Registry.' };
      }
    }
  }

  // 10. Window Minimize / Maximize / Close / Switch
  if (lowerAction === 'window') {
    const op = String(params.operation || 'minimize').toLowerCase();
    if (isWindows) {
      const keyCombo =
        op === 'close'
          ? '%{F4}'
          : op === 'switch'
            ? '%{TAB}'
            : op === 'maximize'
              ? '#{UP}'
              : '#{DOWN}';
      await runPs(`
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait('${keyCombo}')
      `);
      return { status: 'success', message: `Executed Windows window operation: ${op}.` };
    }
  }

  // 11. Clipboard Set / Get
  if (lowerAction === 'clipboard') {
    const op = String(params.operation || 'set').toLowerCase();
    if (isWindows) {
      if (op === 'set') {
        const text = String(params.text || '').replace(/'/g, "''");
        await runPs(`Set-Clipboard -Value '${text}'`);
        return { status: 'success', message: 'Copied text to Windows clipboard.' };
      } else {
        const { stdout } = await runPs(`Get-Clipboard`);
        return { status: 'success', clipboardText: stdout.trim(), message: `Clipboard: ${stdout.trim()}` };
      }
    }
  }

  // 12. Display Brightness Control
  if (lowerAction === 'brightness') {
    const level = Math.max(0, Math.min(100, Number(params.level ?? 80)));
    if (isWindows) {
      await runPs(`
        (Get-WmiObject -Namespace root/WMI -Class WmiMonitorBrightnessMethods -ErrorAction SilentlyContinue).WmiSetBrightness(1, ${level})
      `);
      return { status: 'success', level, message: `Set Windows display brightness to ${level}%.` };
    }
  }

  return { status: 'error', message: `Action "${action}" not supported on this OS.` };
}

const server = http.createServer(async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-n3k-token');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const token = req.headers['x-n3k-token'];
  if (PAIRING_TOKEN && token && token !== PAIRING_TOKEN) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'error', message: 'Invalid N3k pairing token.' }));
    return;
  }

  if (req.method === 'GET' && req.url === '/status') {
    const telemetry = await getSystemTelemetry();
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ connected: true, telemetry }));
    return;
  }

  if (req.method === 'POST' && req.url === '/command') {
    let body = '';
    req.on('data', (chunk) => (body += chunk));
    req.on('end', async () => {
      try {
        const parsed = JSON.parse(body || '{}');
        const result = await executeDesktopAction(parsed.action, parsed.params || {});
        const telemetry = await getSystemTelemetry();
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ...result, telemetry }));
      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'error', message: err.message }));
      }
    });
    return;
  }

  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ status: 'error', message: 'Not found' }));
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('====================================================');
  console.log(' N3k PC / Windows Companion Agent Online');
  console.log(` Listening on: http://0.0.0.0:${PORT}`);
  console.log(` Pairing Token: ${PAIRING_TOKEN}`);
  console.log('====================================================');
});
