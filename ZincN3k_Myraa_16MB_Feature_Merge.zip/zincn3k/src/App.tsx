/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useCallback } from 'react';
import { AmbientBackground } from './components/AmbientBackground.tsx';
import { ControlBar } from './components/ControlBar.tsx';
import { DynamicIslandStatus } from './components/DynamicIslandStatus.tsx';
import { ToolHUD } from './components/ToolHUD.tsx';
import { HolographicAvatar } from './components/HolographicAvatar.tsx';
import { WaveformVisualizer } from './components/WaveformVisualizer.tsx';
import { BrainPanel } from './components/BrainPanel.tsx';
import { SystemHUDPanel } from './components/SystemHUDPanel.tsx';
import { TacticalOperatorHUD } from './components/TacticalOperatorHUD.tsx';
import { QuickActionWheelHUD } from './components/QuickActionWheelHUD.tsx';
import { LanguagesMatrixHUD } from './components/LanguagesMatrixHUD.tsx';
import { IntegratedBrowser } from './components/IntegratedBrowser.tsx';
import { ScreenShareHUD } from './components/ScreenShareHUD.tsx';
import { CameraVisionHUD } from './components/CameraVisionHUD.tsx';
import { PermissionOnboardingModal } from './components/PermissionOnboardingModal.tsx';
import { GameHubModal } from './components/GameHubModal.tsx';
import { globalLiveSession } from './modules/LiveSession.ts';
import { globalStateManager } from './modules/StateManager.ts';
import { globalMemoryManager } from './memory/MemoryManager.ts';
import { globalScreenCaptureManager } from './modules/ScreenShareManager.ts';
import { globalWakeWordManager } from './modules/WakeWordManager.ts';
import { CommandRouter } from './modules/CommandRouter.ts';
import { AssistantTheme, SupportedLanguage, VoicePersona } from './types/assistant.ts';
import { AlertCircle, RefreshCw, Cpu, ShieldCheck } from 'lucide-react';

export default function App() {
  const [appState, setAppState] = useState(globalStateManager.getState());
  const [isBrainOpen, setIsBrainOpen] = useState(false);
  const [isLeftPanelMobileOpen, setIsLeftPanelMobileOpen] = useState(false);
  const [isRightPanelMobileOpen, setIsRightPanelMobileOpen] = useState(false);

  useEffect(() => {
    const unsubState = globalStateManager.subscribe((state) => {
      setAppState({ ...state });
      globalWakeWordManager.setLiveSessionActive(state.assistantState !== 'disconnected');
    });

    const unsubMemory = globalMemoryManager.subscribe((memories) => {
      globalStateManager.setMemoryCount(memories.length);
    });

    const handleStopSpeech = () => {
      globalLiveSession.getAudioPlayer().stop();
    };
    window.addEventListener('n3k:speech:stop', handleStopSpeech);

    return () => {
      unsubState();
      unsubMemory();
      window.removeEventListener('n3k:speech:stop', handleStopSpeech);
    };
  }, []);

  const triggerHaptic = useCallback(() => {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(15);
      } catch {}
    }
  }, []);

  const handleToggleConnect = useCallback(() => {
    triggerHaptic();
    if (appState.assistantState === 'disconnected') {
      globalLiveSession.connect();
    } else {
      globalLiveSession.disconnect();
    }
  }, [appState.assistantState, triggerHaptic]);

  const handleToggleMute = useCallback(() => {
    triggerHaptic();
    globalLiveSession.toggleMute();
  }, [triggerHaptic]);

  const handleSelectTheme = useCallback(
    (theme: AssistantTheme) => {
      triggerHaptic();
      globalStateManager.setTheme(theme);
    },
    [triggerHaptic],
  );

  const handleSelectVoice = useCallback(
    (voice: VoicePersona) => {
      triggerHaptic();
      globalLiveSession.setVoicePersona(voice);
    },
    [triggerHaptic],
  );

  const handleSelectLanguage = useCallback(
    (lang: SupportedLanguage) => {
      triggerHaptic();
      globalStateManager.setActiveLanguage(lang);
    },
    [triggerHaptic],
  );

  const handleSelectAudioInput = useCallback(
    (deviceId: string) => {
      triggerHaptic();
      globalStateManager.setSelectedAudioInputId(deviceId);
      if (appState.assistantState !== 'disconnected') {
        globalLiveSession.disconnect();
        setTimeout(() => {
          globalLiveSession.connect();
        }, 300);
      }
    },
    [appState.assistantState, triggerHaptic],
  );

  const handleDismissCard = useCallback((id: string) => {
    globalStateManager.removeActionCard(id);
  }, []);

  const handleDismissTimer = useCallback((id: string) => {
    globalStateManager.removeTimer(id);
  }, []);

  const handleToggleBrowser = useCallback(() => {
    triggerHaptic();
    globalStateManager.setBrowserOpen(!appState.browserState.isOpen);
  }, [appState.browserState.isOpen, triggerHaptic]);

  const handleToggleScreenShare = useCallback(async () => {
    triggerHaptic();
    if (globalScreenCaptureManager.isActive()) {
      globalScreenCaptureManager.stop();
    } else {
      await globalScreenCaptureManager.start();
    }
  }, [triggerHaptic]);

  const handleToggleCommandCenter = useCallback(() => {
    triggerHaptic();
    globalStateManager.setCommandCenterOpen(!appState.isCommandCenterOpen);
  }, [appState.isCommandCenterOpen, triggerHaptic]);

  // Executes a real tool action AND/OR sends the command to Gemini Live
  const handleExecuteCommand = useCallback(
    async (commandText: string) => {
      triggerHaptic();
      const lower = commandText.toLowerCase();
      const tm = globalLiveSession.getToolManager();

      if (lower === 'open youtube') {
        await tm.executeTool('openApp', { packageOrName: 'YouTube' }, 'ui_cmd');
      } else if (lower === 'open notes') {
        await tm.executeTool('openApp', { packageOrName: 'Notes' }, 'ui_cmd');
      } else if (lower === 'open chrome') {
        await tm.executeTool('openApp', { packageOrName: 'Chrome' }, 'ui_cmd');
      } else if (lower === 'open calculator') {
        await tm.executeTool('openApp', { packageOrName: 'Calculator' }, 'ui_cmd');
      } else if (lower === 'go home') {
        await tm.executeTool('goHome', {}, 'ui_cmd');
      } else if (lower === 'go back') {
        await tm.executeTool('goBack', {}, 'ui_cmd');
      } else if (lower === 'open settings') {
        await tm.executeTool('openSettings', { section: 'main' }, 'ui_cmd');
      } else if (lower.startsWith('write ') && lower.includes(' in notes')) {
        const textToType = commandText
          .replace(/^write /i, '')
          .replace(/ in notes$/i, '')
          .trim();
        await tm.executeTool('typeText', { text: textToType, appName: 'Notes' }, 'ui_cmd');
      } else if (lower.startsWith('search youtube for ')) {
        const q = commandText.replace(/^search youtube for /i, '').trim();
        await tm.executeTool('searchYouTube', { query: q }, 'ui_cmd');
      } else if (lower.startsWith('search google for ')) {
        const q = commandText.replace(/^search google for /i, '').trim();
        await tm.executeTool('searchWeb', { query: q, engine: 'google' }, 'ui_cmd');
      } else if (lower === 'open wikipedia') {
        await tm.executeTool(
          'openWebsite',
          { url: 'https://en.wikipedia.org', title: 'Wikipedia' },
          'ui_cmd',
        );
      } else if (lower.includes('what is on my screen') || lower.includes('look at my screen')) {
        await tm.executeTool(
          'analyzeScreen',
          { prompt: 'What is currently on my screen?' },
          'ui_cmd',
        );
      } else if (lower.includes('system status')) {
        await tm.executeTool('getSystemStatus', {}, 'ui_cmd');
      } else {
        const packet = CommandRouter.parseNaturalCommand(commandText);
        if (packet) {
          await CommandRouter.executePacket(packet, tm);
        }
      }

      if (appState.assistantState !== 'disconnected') {
        await globalLiveSession.sendTextMessage(commandText);
      }
    },
    [appState.assistantState, triggerHaptic],
  );

  useEffect(() => {
    globalWakeWordManager.setOnWakeDetected((commandAfterWakeWord) => {
      triggerHaptic();
      if (commandAfterWakeWord) {
        handleExecuteCommand(commandAfterWakeWord);
      }
      if (globalStateManager.getState().assistantState === 'disconnected') {
        globalLiveSession.connect();
      }
    });
  }, [handleExecuteCommand, triggerHaptic]);

  return (
    <div className="relative w-screen h-screen overflow-hidden flex flex-col justify-between font-sans select-none bg-[#05060b] text-slate-100">
      {/* Dynamic Futuristic Ambient Background */}
      <AmbientBackground state={appState.assistantState} theme={appState.currentTheme} />

      {/* FEATURE 1: Fixed Top-Center Dynamic Island (N3k — CC) & Command Center Overlay */}
      <DynamicIslandStatus
        state={appState.assistantState}
        theme={appState.currentTheme}
        userLevel={appState.audioStats.userLevel}
        assistantLevel={appState.audioStats.assistantLevel}
        isMuted={appState.audioStats.isMuted}
        memoryCount={appState.memoryCount}
        isBrowserOpen={appState.browserState.isOpen}
        isCameraVisionOpen={appState.isCameraVisionOpen}
        screenShareState={appState.screenShareState}
        androidCapabilities={appState.androidCapabilities}
        errorMessage={appState.errorMessage}
        isCommandCenterOpen={appState.isCommandCenterOpen}
        activeVoice={appState.sessionInfo.voice}
        onToggleCommandCenter={handleToggleCommandCenter}
        onCloseCommandCenter={() => globalStateManager.setCommandCenterOpen(false)}
        onToggleConnect={handleToggleConnect}
        onToggleMute={handleToggleMute}
        onOpenBrain={() => setIsBrainOpen(true)}
        onOpenGameHub={() => globalStateManager.setGameHubOpen(true)}
        onToggleBrowser={handleToggleBrowser}
        onToggleVision={() =>
          globalStateManager.setCameraVisionOpen(!appState.isCameraVisionOpen)
        }
        onToggleScreenShare={handleToggleScreenShare}
        onOpenPermissions={() => globalStateManager.setPermissionOnboardingOpen(true)}
        onExecuteQuickCommand={handleExecuteCommand}
      />

      {/* Mobile HUD Drawer Toggle Buttons (Visible on screens < lg) */}
      <div className="fixed top-16 inset-x-3 z-30 flex items-center justify-between lg:hidden pointer-events-none">
        <button
          onClick={() => {
            setIsLeftPanelMobileOpen(!isLeftPanelMobileOpen);
            setIsRightPanelMobileOpen(false);
          }}
          className={`pointer-events-auto flex items-center gap-1.5 px-3 py-1.5 rounded-xl border backdrop-blur-xl font-mono text-[10px] font-bold uppercase tracking-wider transition-all ${
            isLeftPanelMobileOpen
              ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-[0_0_15px_rgba(0,229,255,0.3)]'
              : 'bg-[#080c1a]/85 border-cyan-500/30 text-slate-300'
          }`}
        >
          <Cpu className="w-3.5 h-3.5 text-cyan-400" />
          <span>SYS HUD</span>
        </button>

        <button
          onClick={() => {
            setIsRightPanelMobileOpen(!isRightPanelMobileOpen);
            setIsLeftPanelMobileOpen(false);
          }}
          className={`pointer-events-auto flex items-center gap-1.5 px-3 py-1.5 rounded-xl border backdrop-blur-xl font-mono text-[10px] font-bold uppercase tracking-wider transition-all ${
            isRightPanelMobileOpen
              ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 shadow-[0_0_15px_rgba(0,229,255,0.3)]'
              : 'bg-[#080c1a]/85 border-cyan-500/30 text-slate-300'
          }`}
        >
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          <span>TACTICAL</span>
        </button>
      </div>

      {/* Error Toast Notification */}
      {appState.errorMessage && (
        <div className="fixed top-28 sm:top-20 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-4 py-2.5 rounded-2xl bg-rose-950/90 border border-rose-500/40 text-rose-200 text-xs sm:text-sm shadow-2xl backdrop-blur-xl max-w-[92vw] animate-in fade-in slide-in-from-top-3">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
          <span className="truncate">{appState.errorMessage}</span>
          <button
            onClick={() => {
              globalStateManager.setErrorMessage(null);
              globalLiveSession.connect();
            }}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 text-xs font-medium transition-colors shrink-0"
          >
            <RefreshCw className="w-3 h-3" />
            <span>Retry</span>
          </button>
        </div>
      )}

      {/* Main Command Center Spatial Stage */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-2 sm:px-6 pt-16 pb-2 overflow-hidden">
        {/* Left HUD Column (Desktop persistent / Mobile drawer) */}
        <div
          className={`fixed lg:left-5 top-28 lg:top-16 bottom-24 z-30 flex flex-col justify-between gap-2.5 transition-all duration-300 ${
            isLeftPanelMobileOpen
              ? 'left-3 opacity-100 pointer-events-auto'
              : '-left-80 opacity-0 pointer-events-none lg:left-5 lg:opacity-100 lg:pointer-events-auto'
          }`}
        >
          <div className="pointer-events-auto">
            <SystemHUDPanel
              state={appState.assistantState}
              theme={appState.currentTheme}
              latencyMs={appState.sessionInfo.latencyMs}
              memoryCount={appState.memoryCount}
              turnsCount={appState.sessionInfo.turnsCount}
              userLevel={appState.audioStats.userLevel}
              assistantLevel={appState.audioStats.assistantLevel}
              isBrowserOpen={appState.browserState.isOpen}
              isCameraVisionOpen={appState.isCameraVisionOpen}
              isOpen={true}
              onOpenBrain={() => setIsBrainOpen(true)}
              onToggleConnect={handleToggleConnect}
              onToggleMute={handleToggleMute}
              onToggleBrowser={handleToggleBrowser}
              onToggleVision={() =>
                globalStateManager.setCameraVisionOpen(!appState.isCameraVisionOpen)
              }
              onOpenCommandCenter={handleToggleCommandCenter}
            />
          </div>

          <div className="pointer-events-auto">
            <LanguagesMatrixHUD
              activeLanguage={appState.activeLanguage}
              theme={appState.currentTheme}
              onSelectLanguage={handleSelectLanguage}
            />
          </div>
        </div>

        {/* Right HUD Column (Desktop persistent / Mobile drawer) */}
        <div
          className={`fixed lg:right-5 top-28 lg:top-16 bottom-24 z-30 flex flex-col justify-between items-end gap-2.5 transition-all duration-300 ${
            isRightPanelMobileOpen
              ? 'right-3 opacity-100 pointer-events-auto'
              : '-right-80 opacity-0 pointer-events-none lg:right-5 lg:opacity-100 lg:pointer-events-auto'
          }`}
        >
          <div className="pointer-events-auto">
            <TacticalOperatorHUD
              state={appState.assistantState}
              theme={appState.currentTheme}
              latencyMs={appState.sessionInfo.latencyMs}
              memoryCount={appState.memoryCount}
              isBrowserOpen={appState.browserState.isOpen}
              isCameraVisionOpen={appState.isCameraVisionOpen}
              screenShareState={appState.screenShareState}
            />
          </div>

          <div className="pointer-events-auto">
            <QuickActionWheelHUD
              state={appState.assistantState}
              theme={appState.currentTheme}
              isScreenSharing={appState.screenShareState.isSharing}
              onOpenYouTube={() => handleExecuteCommand('Open YouTube')}
              onSearchWeb={() => handleExecuteCommand('Search Google for AI')}
              onOpenBrain={() => setIsBrainOpen(true)}
              onOpenBrowser={handleToggleBrowser}
              onToggleScreenShare={handleToggleScreenShare}
              onOpenCommandCenter={handleToggleCommandCenter}
            />
          </div>
        </div>

        {/* Floating Tool Action Cards & Active Timers */}
        <ToolHUD
          cards={appState.actionCards}
          timers={appState.activeTimers}
          theme={appState.currentTheme}
          onDismissCard={handleDismissCard}
          onDismissTimer={handleDismissTimer}
        />

        {/* Central Armored Male Hologram AI Operator (N3k / ZinxN3k) */}
        <div className="flex flex-col items-center justify-center my-auto w-full max-w-2xl">
          <HolographicAvatar
            state={appState.assistantState}
            theme={appState.currentTheme}
            userLevel={appState.audioStats.userLevel}
            assistantLevel={appState.audioStats.assistantLevel}
            isMuted={appState.audioStats.isMuted}
            audioPlayer={globalLiveSession.getAudioPlayer()}
            onToggleConnect={handleToggleConnect}
          />
        </div>

        {/* Bottom Audio Frequency Spectrum Visualizer */}
        <div className="w-full flex justify-center mt-auto">
          <WaveformVisualizer
            state={appState.assistantState}
            theme={appState.currentTheme}
            userLevel={appState.audioStats.userLevel}
            assistantLevel={appState.audioStats.assistantLevel}
            audioPlayer={globalLiveSession.getAudioPlayer()}
          />
        </div>
      </main>

      {/* Live Screen Sharing Preview & Status Pill (Only visible when genuinely active) */}
      <ScreenShareHUD
        screenShareState={appState.screenShareState}
        theme={appState.currentTheme}
      />

      {/* Real Optical Camera Vision Scanner HUD */}
      <CameraVisionHUD
        isOpen={appState.isCameraVisionOpen}
        theme={appState.currentTheme}
        onClose={() => globalStateManager.setCameraVisionOpen(false)}
      />

      {/* Integrated Holographic Web & YouTube Browser Overlay */}
      <IntegratedBrowser
        browserState={appState.browserState}
        theme={appState.currentTheme}
        onClose={() => globalStateManager.setBrowserOpen(false)}
      />

      {/* N3k Brain Long-Term Memory Panel Modal */}
      <BrainPanel
        isOpen={isBrainOpen}
        theme={appState.currentTheme}
        onClose={() => setIsBrainOpen(false)}
      />

      {/* N3k Game Hub Modal (Android & Windows Games + Launchers) */}
      <GameHubModal
        isOpen={appState.isGameHubOpen}
        theme={appState.currentTheme}
        onClose={() => globalStateManager.setGameHubOpen(false)}
      />

      {/* First-Launch / On-Demand Permission Onboarding Modal */}
      <PermissionOnboardingModal
        isOpen={appState.isPermissionOnboardingOpen}
        theme={appState.currentTheme}
        permissions={appState.systemPermissions}
        androidCapabilities={appState.androidCapabilities}
        onClose={() => globalStateManager.setPermissionOnboardingOpen(false)}
      />

      {/* Bottom Floating Control Bar */}
      <ControlBar
        state={appState.assistantState}
        theme={appState.currentTheme}
        sessionInfo={appState.sessionInfo}
        isMuted={appState.audioStats.isMuted}
        selectedAudioInputId={appState.selectedAudioInputId}
        memoryCount={appState.memoryCount}
        isBrowserOpen={appState.browserState.isOpen}
        isScreenSharing={appState.screenShareState.isSharing}
        onToggleConnect={handleToggleConnect}
        onToggleMute={handleToggleMute}
        onSelectTheme={handleSelectTheme}
        onSelectVoice={handleSelectVoice}
        onSelectAudioInput={handleSelectAudioInput}
        onOpenBrain={() => setIsBrainOpen(true)}
        onToggleBrowser={handleToggleBrowser}
        onToggleScreenShare={handleToggleScreenShare}
      />
    </div>
  );
}
