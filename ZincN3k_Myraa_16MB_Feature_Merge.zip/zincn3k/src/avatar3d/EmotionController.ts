export type N3kExpression =
  | 'NEUTRAL'
  | 'HAPPY'
  | 'SMILE'
  | 'LAUGH'
  | 'SAD'
  | 'CRYING'
  | 'ANGRY'
  | 'ANNOYED'
  | 'BORED'
  | 'TIRED'
  | 'CONFUSED'
  | 'SURPRISED'
  | 'SHOCKED'
  | 'CURIOUS'
  | 'THINKING'
  | 'FOCUSED'
  | 'SERIOUS'
  | 'EXCITED'
  | 'NERVOUS'
  | 'WORRIED'
  | 'RELIEVED'
  | 'PROUD'
  | 'PLAYFUL'
  | 'SUSPICIOUS'
  | 'LISTENING'
  | 'SPEAKING'
  | 'ERROR';

export const ALL_N3K_EXPRESSIONS: N3kExpression[] = [
  'NEUTRAL',
  'HAPPY',
  'SMILE',
  'LAUGH',
  'SAD',
  'CRYING',
  'ANGRY',
  'ANNOYED',
  'BORED',
  'TIRED',
  'CONFUSED',
  'SURPRISED',
  'SHOCKED',
  'CURIOUS',
  'THINKING',
  'FOCUSED',
  'SERIOUS',
  'EXCITED',
  'NERVOUS',
  'WORRIED',
  'RELIEVED',
  'PROUD',
  'PLAYFUL',
  'SUSPICIOUS',
  'LISTENING',
  'SPEAKING',
  'ERROR',
];

export interface ExpressionMorphTargetWeights {
  browInnerUp: number; // -1 (furrowed) to +1 (raised inner brow)
  browOuterUpL: number; // -1 to +1
  browOuterUpR: number; // -1 to +1
  eyeSquint: number; // 0 to 1 (happy/suspicious squint)
  eyeWide: number; // 0 to 1 (surprised/shocked wide eyes)
  eyelidDroop: number; // 0 to 1 (tired/bored/relaxed)
  mouthSmile: number; // -1 (frown) to +1 (smile)
  mouthOpenBase: number; // 0 to 1 (expression mouth open)
  mouthPucker: number; // 0 to 1 (curious/playful)
  headTiltZ: number; // radians
  headPitchX: number; // radians
  eyeGlowBoost: number; // 0.5 to 2.0
  tearDrop: number; // 0 to 1 (for CRYING)
}

const EXPRESSION_PRESETS: Record<N3kExpression, ExpressionMorphTargetWeights> = {
  NEUTRAL: {
    browInnerUp: 0,
    browOuterUpL: 0,
    browOuterUpR: 0,
    eyeSquint: 0.05,
    eyeWide: 0,
    eyelidDroop: 0.05,
    mouthSmile: 0.08,
    mouthOpenBase: 0,
    mouthPucker: 0,
    headTiltZ: 0,
    headPitchX: 0,
    eyeGlowBoost: 1.0,
    tearDrop: 0,
  },
  HAPPY: {
    browInnerUp: 0.35,
    browOuterUpL: 0.25,
    browOuterUpR: 0.25,
    eyeSquint: 0.45,
    eyeWide: 0,
    eyelidDroop: 0,
    mouthSmile: 0.75,
    mouthOpenBase: 0.15,
    mouthPucker: 0,
    headTiltZ: 0.04,
    headPitchX: -0.03,
    eyeGlowBoost: 1.35,
    tearDrop: 0,
  },
  SMILE: {
    browInnerUp: 0.2,
    browOuterUpL: 0.15,
    browOuterUpR: 0.15,
    eyeSquint: 0.25,
    eyeWide: 0,
    eyelidDroop: 0,
    mouthSmile: 0.55,
    mouthOpenBase: 0.04,
    mouthPucker: 0,
    headTiltZ: 0.03,
    headPitchX: -0.02,
    eyeGlowBoost: 1.2,
    tearDrop: 0,
  },
  LAUGH: {
    browInnerUp: 0.45,
    browOuterUpL: 0.3,
    browOuterUpR: 0.3,
    eyeSquint: 0.7,
    eyeWide: 0,
    eyelidDroop: 0,
    mouthSmile: 0.95,
    mouthOpenBase: 0.45,
    mouthPucker: 0,
    headTiltZ: 0.06,
    headPitchX: -0.07,
    eyeGlowBoost: 1.45,
    tearDrop: 0,
  },
  SAD: {
    browInnerUp: 0.65,
    browOuterUpL: -0.35,
    browOuterUpR: -0.35,
    eyeSquint: 0.1,
    eyeWide: 0,
    eyelidDroop: 0.45,
    mouthSmile: -0.5,
    mouthOpenBase: 0.02,
    mouthPucker: 0.1,
    headTiltZ: -0.05,
    headPitchX: 0.1,
    eyeGlowBoost: 0.7,
    tearDrop: 0,
  },
  CRYING: {
    browInnerUp: 0.85,
    browOuterUpL: -0.45,
    browOuterUpR: -0.45,
    eyeSquint: 0.35,
    eyeWide: 0,
    eyelidDroop: 0.55,
    mouthSmile: -0.75,
    mouthOpenBase: 0.18,
    mouthPucker: 0.15,
    headTiltZ: -0.06,
    headPitchX: 0.14,
    eyeGlowBoost: 0.65,
    tearDrop: 1.0,
  },
  ANGRY: {
    browInnerUp: -0.85,
    browOuterUpL: 0.3,
    browOuterUpR: 0.3,
    eyeSquint: 0.5,
    eyeWide: 0.1,
    eyelidDroop: 0,
    mouthSmile: -0.65,
    mouthOpenBase: 0.12,
    mouthPucker: 0,
    headTiltZ: 0,
    headPitchX: 0.06,
    eyeGlowBoost: 1.65,
    tearDrop: 0,
  },
  ANNOYED: {
    browInnerUp: -0.45,
    browOuterUpL: -0.1,
    browOuterUpR: 0.25,
    eyeSquint: 0.35,
    eyeWide: 0,
    eyelidDroop: 0.35,
    mouthSmile: -0.3,
    mouthOpenBase: 0,
    mouthPucker: 0.15,
    headTiltZ: -0.04,
    headPitchX: 0.02,
    eyeGlowBoost: 0.9,
    tearDrop: 0,
  },
  BORED: {
    browInnerUp: -0.1,
    browOuterUpL: -0.1,
    browOuterUpR: -0.1,
    eyeSquint: 0,
    eyeWide: 0,
    eyelidDroop: 0.6,
    mouthSmile: -0.15,
    mouthOpenBase: 0.04,
    mouthPucker: 0,
    headTiltZ: 0.05,
    headPitchX: 0.05,
    eyeGlowBoost: 0.65,
    tearDrop: 0,
  },
  TIRED: {
    browInnerUp: 0.15,
    browOuterUpL: -0.2,
    browOuterUpR: -0.2,
    eyeSquint: 0.15,
    eyeWide: 0,
    eyelidDroop: 0.72,
    mouthSmile: -0.1,
    mouthOpenBase: 0.08,
    mouthPucker: 0,
    headTiltZ: -0.04,
    headPitchX: 0.09,
    eyeGlowBoost: 0.55,
    tearDrop: 0,
  },
  CONFUSED: {
    browInnerUp: 0.3,
    browOuterUpL: 0.65,
    browOuterUpR: -0.35,
    eyeSquint: 0.2,
    eyeWide: 0.15,
    eyelidDroop: 0.1,
    mouthSmile: -0.2,
    mouthOpenBase: 0.08,
    mouthPucker: 0.25,
    headTiltZ: 0.12,
    headPitchX: 0.01,
    eyeGlowBoost: 1.05,
    tearDrop: 0,
  },
  SURPRISED: {
    browInnerUp: 0.75,
    browOuterUpL: 0.65,
    browOuterUpR: 0.65,
    eyeSquint: 0,
    eyeWide: 0.75,
    eyelidDroop: 0,
    mouthSmile: 0.05,
    mouthOpenBase: 0.38,
    mouthPucker: 0.35,
    headTiltZ: 0,
    headPitchX: -0.05,
    eyeGlowBoost: 1.5,
    tearDrop: 0,
  },
  SHOCKED: {
    browInnerUp: 0.95,
    browOuterUpL: 0.85,
    browOuterUpR: 0.85,
    eyeSquint: 0,
    eyeWide: 0.98,
    eyelidDroop: 0,
    mouthSmile: -0.1,
    mouthOpenBase: 0.62,
    mouthPucker: 0.25,
    headTiltZ: -0.02,
    headPitchX: -0.08,
    eyeGlowBoost: 1.8,
    tearDrop: 0,
  },
  CURIOUS: {
    browInnerUp: 0.4,
    browOuterUpL: 0.5,
    browOuterUpR: 0.1,
    eyeSquint: 0.1,
    eyeWide: 0.3,
    eyelidDroop: 0,
    mouthSmile: 0.2,
    mouthOpenBase: 0.05,
    mouthPucker: 0.15,
    headTiltZ: 0.1,
    headPitchX: -0.03,
    eyeGlowBoost: 1.3,
    tearDrop: 0,
  },
  THINKING: {
    browInnerUp: -0.25,
    browOuterUpL: 0.35,
    browOuterUpR: -0.15,
    eyeSquint: 0.25,
    eyeWide: 0,
    eyelidDroop: 0.15,
    mouthSmile: 0,
    mouthOpenBase: 0,
    mouthPucker: 0.2,
    headTiltZ: 0.08,
    headPitchX: -0.04,
    eyeGlowBoost: 1.25,
    tearDrop: 0,
  },
  FOCUSED: {
    browInnerUp: -0.4,
    browOuterUpL: 0.1,
    browOuterUpR: 0.1,
    eyeSquint: 0.3,
    eyeWide: 0.1,
    eyelidDroop: 0,
    mouthSmile: 0.05,
    mouthOpenBase: 0,
    mouthPucker: 0,
    headTiltZ: 0,
    headPitchX: 0.03,
    eyeGlowBoost: 1.45,
    tearDrop: 0,
  },
  SERIOUS: {
    browInnerUp: -0.35,
    browOuterUpL: 0,
    browOuterUpR: 0,
    eyeSquint: 0.2,
    eyeWide: 0,
    eyelidDroop: 0.1,
    mouthSmile: -0.12,
    mouthOpenBase: 0,
    mouthPucker: 0,
    headTiltZ: 0,
    headPitchX: 0.02,
    eyeGlowBoost: 1.15,
    tearDrop: 0,
  },
  EXCITED: {
    browInnerUp: 0.55,
    browOuterUpL: 0.45,
    browOuterUpR: 0.45,
    eyeSquint: 0.25,
    eyeWide: 0.45,
    eyelidDroop: 0,
    mouthSmile: 0.85,
    mouthOpenBase: 0.32,
    mouthPucker: 0,
    headTiltZ: 0.04,
    headPitchX: -0.05,
    eyeGlowBoost: 1.65,
    tearDrop: 0,
  },
  NERVOUS: {
    browInnerUp: 0.55,
    browOuterUpL: -0.25,
    browOuterUpR: -0.25,
    eyeSquint: 0.2,
    eyeWide: 0.25,
    eyelidDroop: 0.1,
    mouthSmile: 0.15,
    mouthOpenBase: 0.05,
    mouthPucker: 0.1,
    headTiltZ: -0.04,
    headPitchX: 0.04,
    eyeGlowBoost: 0.95,
    tearDrop: 0,
  },
  WORRIED: {
    browInnerUp: 0.65,
    browOuterUpL: -0.3,
    browOuterUpR: -0.3,
    eyeSquint: 0.15,
    eyeWide: 0.15,
    eyelidDroop: 0.2,
    mouthSmile: -0.35,
    mouthOpenBase: 0.06,
    mouthPucker: 0.1,
    headTiltZ: -0.05,
    headPitchX: 0.05,
    eyeGlowBoost: 0.85,
    tearDrop: 0,
  },
  RELIEVED: {
    browInnerUp: 0.25,
    browOuterUpL: 0.1,
    browOuterUpR: 0.1,
    eyeSquint: 0.35,
    eyeWide: 0,
    eyelidDroop: 0.35,
    mouthSmile: 0.45,
    mouthOpenBase: 0.06,
    mouthPucker: 0,
    headTiltZ: 0.03,
    headPitchX: 0.02,
    eyeGlowBoost: 1.1,
    tearDrop: 0,
  },
  PROUD: {
    browInnerUp: 0.2,
    browOuterUpL: 0.25,
    browOuterUpR: 0.25,
    eyeSquint: 0.3,
    eyeWide: 0,
    eyelidDroop: 0.1,
    mouthSmile: 0.6,
    mouthOpenBase: 0.02,
    mouthPucker: 0,
    headTiltZ: 0.02,
    headPitchX: -0.06,
    eyeGlowBoost: 1.4,
    tearDrop: 0,
  },
  PLAYFUL: {
    browInnerUp: 0.25,
    browOuterUpL: 0.55,
    browOuterUpR: -0.1,
    eyeSquint: 0.35,
    eyeWide: 0.1,
    eyelidDroop: 0.05,
    mouthSmile: 0.68,
    mouthOpenBase: 0.12,
    mouthPucker: 0.15,
    headTiltZ: 0.09,
    headPitchX: -0.02,
    eyeGlowBoost: 1.35,
    tearDrop: 0,
  },
  SUSPICIOUS: {
    browInnerUp: -0.5,
    browOuterUpL: 0.4,
    browOuterUpR: -0.35,
    eyeSquint: 0.6,
    eyeWide: 0,
    eyelidDroop: 0.25,
    mouthSmile: -0.15,
    mouthOpenBase: 0,
    mouthPucker: 0.2,
    headTiltZ: -0.05,
    headPitchX: 0.03,
    eyeGlowBoost: 1.2,
    tearDrop: 0,
  },
  LISTENING: {
    browInnerUp: 0.25,
    browOuterUpL: 0.2,
    browOuterUpR: 0.2,
    eyeSquint: 0.05,
    eyeWide: 0.2,
    eyelidDroop: 0,
    mouthSmile: 0.18,
    mouthOpenBase: 0.02,
    mouthPucker: 0,
    headTiltZ: 0.04,
    headPitchX: -0.02,
    eyeGlowBoost: 1.35,
    tearDrop: 0,
  },
  SPEAKING: {
    browInnerUp: 0.2,
    browOuterUpL: 0.15,
    browOuterUpR: 0.15,
    eyeSquint: 0.12,
    eyeWide: 0.1,
    eyelidDroop: 0,
    mouthSmile: 0.22,
    mouthOpenBase: 0.1,
    mouthPucker: 0,
    headTiltZ: 0.02,
    headPitchX: 0,
    eyeGlowBoost: 1.45,
    tearDrop: 0,
  },
  ERROR: {
    browInnerUp: 0.5,
    browOuterUpL: -0.3,
    browOuterUpR: -0.3,
    eyeSquint: 0.25,
    eyeWide: 0.1,
    eyelidDroop: 0.15,
    mouthSmile: -0.4,
    mouthOpenBase: 0.05,
    mouthPucker: 0,
    headTiltZ: -0.04,
    headPitchX: 0.04,
    eyeGlowBoost: 0.75,
    tearDrop: 0,
  },
};

export class EmotionController {
  private currentExpression: N3kExpression = 'NEUTRAL';
  private manualOverrideExpression: N3kExpression | null = null;
  private manualOverrideExpiresAt = 0;

  private currentWeights: ExpressionMorphTargetWeights = {
    ...EXPRESSION_PRESETS.NEUTRAL,
  };

  private listeners: Set<(exp: N3kExpression) => void> = new Set();

  public getExpression(): N3kExpression {
    if (this.manualOverrideExpression && Date.now() < this.manualOverrideExpiresAt) {
      return this.manualOverrideExpression;
    }
    return this.currentExpression;
  }

  public setExpression(expression: N3kExpression, durationMs = 0) {
    if (durationMs > 0) {
      this.manualOverrideExpression = expression;
      this.manualOverrideExpiresAt = Date.now() + durationMs;
    } else {
      this.manualOverrideExpression = null;
      this.currentExpression = expression;
    }
    this.notify();
  }

  public subscribe(listener: (exp: N3kExpression) => void): () => void {
    this.listeners.add(listener);
    listener(this.getExpression());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const active = this.getExpression();
    this.listeners.forEach((l) => l(active));
  }

  /**
   * Contextually selects a visual expression from user or assistant speech/text
   */
  public inferExpressionFromContext(text: string): N3kExpression {
    const lower = text.toLowerCase();
    let detected: N3kExpression = 'NEUTRAL';

    if (
      lower.includes('finally finished') ||
      lower.includes('we did it') ||
      lower.includes('proud') ||
      lower.includes('accomplished')
    ) {
      detected = 'PROUD';
    } else if (
      lower.includes('funny') ||
      lower.includes('joke') ||
      lower.includes('haha') ||
      lower.includes('lol')
    ) {
      detected = 'PLAYFUL';
    } else if (
      lower.includes('awesome') ||
      lower.includes('amazing') ||
      lower.includes('excited') ||
      lower.includes('great news')
    ) {
      detected = 'EXCITED';
    } else if (
      lower.includes('thank') ||
      lower.includes('happy') ||
      lower.includes('glad') ||
      lower.includes('love')
    ) {
      detected = 'HAPPY';
    } else if (
      lower.includes("isn't working") ||
      lower.includes('not working') ||
      lower.includes('fix') ||
      lower.includes('debug') ||
      lower.includes('calculate')
    ) {
      detected = 'FOCUSED';
    } else if (
      lower.includes('annoying') ||
      lower.includes('frustrating') ||
      lower.includes('worried') ||
      lower.includes('problem')
    ) {
      detected = 'WORRIED';
    } else if (
      lower.includes('why') ||
      lower.includes('how does') ||
      lower.includes('what is') ||
      lower.includes('curious')
    ) {
      detected = 'CURIOUS';
    } else if (lower.includes('wow') || lower.includes('really?!') || lower.includes('no way')) {
      detected = 'SURPRISED';
    } else if (lower.includes('sad') || lower.includes('sorry to hear')) {
      detected = 'SAD';
    }

    if (detected !== 'NEUTRAL') {
      this.setExpression(detected, 8000);
    }
    return detected;
  }

  /**
   * Smoothly blends current morph weights toward the active target expression (call in requestAnimationFrame)
   */
  public updateBlendedWeights(deltaSeconds: number): ExpressionMorphTargetWeights {
    if (this.manualOverrideExpression && Date.now() >= this.manualOverrideExpiresAt) {
      this.manualOverrideExpression = null;
      this.notify();
    }

    const activeExp = this.getExpression();
    const target = EXPRESSION_PRESETS[activeExp] || EXPRESSION_PRESETS.NEUTRAL;
    const speed = Math.min(1, deltaSeconds * 6.5);

    (Object.keys(target) as Array<keyof ExpressionMorphTargetWeights>).forEach((key) => {
      this.currentWeights[key] =
        this.currentWeights[key] + (target[key] - this.currentWeights[key]) * speed;
    });

    return this.currentWeights;
  }
}

export const globalEmotionController = new EmotionController();
