export type VisemeCode =
  | 'SIL'
  | 'A'
  | 'E'
  | 'I'
  | 'O'
  | 'U'
  | 'M'
  | 'B'
  | 'P'
  | 'F'
  | 'V'
  | 'L'
  | 'S'
  | 'SH'
  | 'TH'
  | 'N'
  | 'K'
  | 'G';

export interface VisemeBlendState {
  currentViseme: VisemeCode;
  jawOpen: number; // 0 to 1
  mouthWidth: number; // -0.5 (narrow/round) to +0.5 (wide E/I/S)
  mouthRound: number; // 0 to 1 (O/U/SH)
  lipPress: number; // 0 to 1 (M/B/P bilabial closure)
  lowerLipTuck: number; // 0 to 1 (F/V labiodental)
  tongueRaise: number; // 0 to 1 (L/N/TH/K/G)
  energyLevel: number; // 0 to 1
}

/**
 * VisemeController
 * Real-time audio-driven & formant-aware Lip Sync engine for the 3D N3k model.
 * Analyzes real frequency spectrum bands from AudioPlayer's AnalyserNode
 * (low formant F1: 250-850Hz, mid formant F2: 850-2400Hz, high sibilance: 2500-6500Hz)
 * to classify and smoothly blend all 17 required visemes:
 * A, E, I, O, U, M, B, P, F, V, L, S, SH, TH, N, K, G.
 */
export class VisemeController {
  private freqData = new Uint8Array(256);
  private state: VisemeBlendState = {
    currentViseme: 'SIL',
    jawOpen: 0,
    mouthWidth: 0,
    mouthRound: 0,
    lipPress: 0,
    lowerLipTuck: 0,
    tongueRaise: 0,
    energyLevel: 0,
  };

  private prevEnergy = 0;

  public getState(): VisemeBlendState {
    return this.state;
  }

  public updateFromAudio(
    analyser: AnalyserNode | null,
    isSpeaking: boolean,
    fallbackLevel: number,
    deltaSeconds: number,
  ): VisemeBlendState {
    const smoothSpeed = Math.min(1, deltaSeconds * 18);
    const closeSpeed = Math.min(1, deltaSeconds * 12);

    if (!isSpeaking && fallbackLevel < 0.015) {
      this.state.currentViseme = 'SIL';
      this.state.jawOpen += (0 - this.state.jawOpen) * closeSpeed;
      this.state.mouthWidth += (0 - this.state.mouthWidth) * closeSpeed;
      this.state.mouthRound += (0 - this.state.mouthRound) * closeSpeed;
      this.state.lipPress += (0 - this.state.lipPress) * closeSpeed;
      this.state.lowerLipTuck += (0 - this.state.lowerLipTuck) * closeSpeed;
      this.state.tongueRaise += (0 - this.state.tongueRaise) * closeSpeed;
      this.state.energyLevel += (0 - this.state.energyLevel) * closeSpeed;
      this.prevEnergy = 0;
      return this.state;
    }

    let lowBand = 0; // ~150 - 700 Hz (U, O, M, B, P)
    let midLowBand = 0; // ~700 - 1400 Hz (A, L, N)
    let midHighBand = 0; // ~1400 - 2600 Hz (E, I, K, G)
    let highBand = 0; // ~2600 - 6000 Hz (S, SH, F, V, TH)

    if (analyser) {
      analyser.getByteFrequencyData(this.freqData);
      // With 24kHz sampleRate and fftSize 512 (256 bins), each bin is ~46.875 Hz
      lowBand = this.avgBins(3, 15);
      midLowBand = this.avgBins(15, 30);
      midHighBand = this.avgBins(30, 56);
      highBand = this.avgBins(56, 125);
    } else {
      // High-quality envelope fallback if AnalyserNode is not attached
      const t = performance.now() * 0.012;
      lowBand = fallbackLevel * (0.6 + 0.4 * Math.sin(t));
      midLowBand = fallbackLevel * (0.7 + 0.3 * Math.cos(t * 1.3));
      midHighBand = fallbackLevel * (0.5 + 0.5 * Math.sin(t * 1.9));
      highBand = fallbackLevel * (0.3 + 0.3 * Math.cos(t * 2.7));
    }

    const totalEnergy = Math.min(
      1,
      (lowBand * 0.35 + midLowBand * 0.35 + midHighBand * 0.2 + highBand * 0.1) * 1.6,
    );
    const energyDelta = totalEnergy - this.prevEnergy;
    this.prevEnergy = totalEnergy;

    let targetViseme: VisemeCode = 'A';
    let targetJaw = 0;
    let targetWidth = 0;
    let targetRound = 0;
    let targetPress = 0;
    let targetTuck = 0;
    let targetTongue = 0;

    if (totalEnergy < 0.04) {
      targetViseme = 'SIL';
    } else if (energyDelta < -0.14 && lowBand > 0.12) {
      // Rapid closure Plosive / Bilabial: M, B, P
      const plosives: VisemeCode[] = ['M', 'B', 'P'];
      targetViseme = plosives[Math.floor(performance.now() / 90) % plosives.length];
      targetJaw = 0.03;
      targetPress = 0.85;
      targetWidth = -0.05;
    } else if (highBand > midLowBand * 0.85 && highBand > 0.16) {
      // High-frequency fricatives / sibilants: S, SH, F, V, TH
      if (lowBand > 0.28) {
        targetViseme = highBand > 0.35 ? 'SH' : 'V';
        targetJaw = 0.18;
        targetRound = 0.55;
        targetTuck = targetViseme === 'V' ? 0.65 : 0;
      } else if (midHighBand > 0.25) {
        targetViseme = 'S';
        targetJaw = 0.14;
        targetWidth = 0.32;
      } else {
        targetViseme = highBand > 0.24 ? 'F' : 'TH';
        targetJaw = 0.16;
        targetTuck = targetViseme === 'F' ? 0.75 : 0.2;
        targetTongue = targetViseme === 'TH' ? 0.7 : 0;
      }
    } else if (midLowBand >= lowBand && midLowBand >= midHighBand) {
      // Open vowels & alveolar sonorants: A, L, N, K, G
      if (totalEnergy > 0.42) {
        targetViseme = 'A';
        targetJaw = Math.min(0.95, totalEnergy * 1.15);
        targetWidth = 0.12;
      } else if (midHighBand > 0.22) {
        targetViseme = energyDelta > 0 ? 'K' : 'G';
        targetJaw = 0.32;
        targetTongue = 0.65;
      } else {
        targetViseme = lowBand > 0.22 ? 'N' : 'L';
        targetJaw = 0.28;
        targetTongue = 0.75;
      }
    } else if (midHighBand > lowBand * 0.9) {
      // Front vowels: E, I
      targetViseme = midHighBand > 0.4 ? 'I' : 'E';
      targetJaw = targetViseme === 'E' ? Math.min(0.65, totalEnergy * 0.85) : 0.35;
      targetWidth = targetViseme === 'I' ? 0.42 : 0.3;
    } else {
      // Rounded back vowels: O, U
      targetViseme = midLowBand > 0.25 ? 'O' : 'U';
      targetJaw = targetViseme === 'O' ? Math.min(0.78, totalEnergy * 0.95) : 0.32;
      targetRound = targetViseme === 'U' ? 0.85 : 0.68;
      targetWidth = -0.28;
    }

    this.state.currentViseme = targetViseme;
    this.state.jawOpen += (targetJaw - this.state.jawOpen) * smoothSpeed;
    this.state.mouthWidth += (targetWidth - this.state.mouthWidth) * smoothSpeed;
    this.state.mouthRound += (targetRound - this.state.mouthRound) * smoothSpeed;
    this.state.lipPress += (targetPress - this.state.lipPress) * smoothSpeed;
    this.state.lowerLipTuck += (targetTuck - this.state.lowerLipTuck) * smoothSpeed;
    this.state.tongueRaise += (targetTongue - this.state.tongueRaise) * smoothSpeed;
    this.state.energyLevel = totalEnergy;

    return this.state;
  }

  private avgBins(start: number, end: number): number {
    let sum = 0;
    const count = Math.max(1, end - start);
    for (let i = start; i < end && i < this.freqData.length; i++) {
      sum += this.freqData[i];
    }
    return sum / (count * 255);
  }
}

export const globalVisemeController = new VisemeController();
