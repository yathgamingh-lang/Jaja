export type N3kGestureType =
  | 'none'
  | 'small_wave'
  | 'open_palm'
  | 'pointing'
  | 'thinking_pose'
  | 'head_nod'
  | 'head_shake'
  | 'command_gesture'
  | 'subtle_hand'
  | 'relaxed_hand';

export interface GesturePoseOffsets {
  activeGesture: N3kGestureType;
  rightShoulderPitch: number;
  rightShoulderRoll: number;
  rightElbowBend: number;
  rightWristWave: number;
  leftShoulderPitch: number;
  leftShoulderRoll: number;
  leftElbowBend: number;
  headNodOffset: number;
  headShakeOffset: number;
}

export class GestureController {
  private currentGesture: N3kGestureType = 'none';
  private gestureElapsed = 0;
  private gestureDuration = 2.2;

  private pose: GesturePoseOffsets = {
    activeGesture: 'none',
    rightShoulderPitch: 0,
    rightShoulderRoll: 0,
    rightElbowBend: 0,
    rightWristWave: 0,
    leftShoulderPitch: 0,
    leftShoulderRoll: 0,
    leftElbowBend: 0,
    headNodOffset: 0,
    headShakeOffset: 0,
  };

  public triggerGesture(gesture: N3kGestureType, durationSec = 2.4) {
    this.currentGesture = gesture;
    this.gestureElapsed = 0;
    this.gestureDuration = durationSec;
  }

  public getActiveGesture(): N3kGestureType {
    return this.currentGesture;
  }

  public update(deltaSeconds: number): GesturePoseOffsets {
    if (this.currentGesture !== 'none') {
      this.gestureElapsed += deltaSeconds;
      if (this.gestureElapsed >= this.gestureDuration) {
        this.currentGesture = 'none';
      }
    }

    const t = this.gestureElapsed;
    // Smooth bell envelope (0 -> 1 -> 0) over gesture duration
    const progress =
      this.currentGesture === 'none'
        ? 0
        : Math.sin(Math.min(1, t / this.gestureDuration) * Math.PI);

    let rPitch = 0;
    let rRoll = 0;
    let rElbow = 0;
    let rWave = 0;
    let lPitch = 0;
    let lRoll = 0;
    let lElbow = 0;
    let nod = 0;
    let shake = 0;

    switch (this.currentGesture) {
      case 'small_wave':
        rPitch = -0.85 * progress;
        rRoll = -0.35 * progress;
        rElbow = 0.9 * progress;
        rWave = Math.sin(t * 11) * 0.35 * progress;
        break;
      case 'open_palm':
        rPitch = -0.45 * progress;
        rRoll = -0.25 * progress;
        rElbow = 0.55 * progress;
        lPitch = -0.35 * progress;
        lElbow = 0.45 * progress;
        break;
      case 'pointing':
        rPitch = -0.75 * progress;
        rRoll = -0.1 * progress;
        rElbow = 0.3 * progress;
        break;
      case 'thinking_pose':
        rPitch = -0.65 * progress;
        rRoll = 0.25 * progress;
        rElbow = 1.15 * progress;
        nod = 0.06 * progress;
        break;
      case 'head_nod':
        nod = Math.sin(t * 9) * 0.16 * progress;
        break;
      case 'head_shake':
        shake = Math.sin(t * 10) * 0.2 * progress;
        break;
      case 'command_gesture':
        rPitch = -0.7 * progress;
        rRoll = -0.3 * progress;
        rElbow = 0.65 * progress;
        rWave = Math.cos(t * 6) * 0.15 * progress;
        break;
      case 'subtle_hand':
        rPitch = -0.28 * progress;
        rElbow = 0.4 * progress;
        break;
      default:
        break;
    }

    const lerpSpeed = Math.min(1, deltaSeconds * 8.0);
    this.pose.activeGesture = this.currentGesture;
    this.pose.rightShoulderPitch += (rPitch - this.pose.rightShoulderPitch) * lerpSpeed;
    this.pose.rightShoulderRoll += (rRoll - this.pose.rightShoulderRoll) * lerpSpeed;
    this.pose.rightElbowBend += (rElbow - this.pose.rightElbowBend) * lerpSpeed;
    this.pose.rightWristWave += (rWave - this.pose.rightWristWave) * lerpSpeed;
    this.pose.leftShoulderPitch += (lPitch - this.pose.leftShoulderPitch) * lerpSpeed;
    this.pose.leftShoulderRoll += (lRoll - this.pose.leftShoulderRoll) * lerpSpeed;
    this.pose.leftElbowBend += (lElbow - this.pose.leftElbowBend) * lerpSpeed;
    this.pose.headNodOffset += (nod - this.pose.headNodOffset) * lerpSpeed;
    this.pose.headShakeOffset += (shake - this.pose.headShakeOffset) * lerpSpeed;

    return this.pose;
  }
}

export const globalGestureController = new GestureController();
