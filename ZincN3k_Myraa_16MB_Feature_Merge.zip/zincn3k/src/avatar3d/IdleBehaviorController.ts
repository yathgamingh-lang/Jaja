export type IdleMicroBehaviorType =
  | 'blink'
  | 'double_blink'
  | 'look_left'
  | 'look_right'
  | 'look_up'
  | 'look_down'
  | 'head_tilt'
  | 'small_nod'
  | 'posture_shift'
  | 'shoulder_movement'
  | 'subtle_hand_movement'
  | 'look_toward_ui'
  | 'look_toward_camera'
  | 'thinking_gesture'
  | 'relaxed_stance'
  | 'small_facial_expression';

interface BehaviorDefinition {
  type: IdleMicroBehaviorType;
  weight: number;
  minDurationSec: number;
  maxDurationSec: number;
  cooldownSec: number;
  priority: number;
}

const IDLE_BEHAVIOR_POOL: BehaviorDefinition[] = [
  { type: 'look_toward_camera', weight: 24, minDurationSec: 2.0, maxDurationSec: 4.5, cooldownSec: 2.5, priority: 1 },
  { type: 'head_tilt', weight: 16, minDurationSec: 1.8, maxDurationSec: 3.6, cooldownSec: 4.0, priority: 2 },
  { type: 'small_nod', weight: 12, minDurationSec: 0.9, maxDurationSec: 1.6, cooldownSec: 5.5, priority: 2 },
  { type: 'look_left', weight: 10, minDurationSec: 1.4, maxDurationSec: 2.8, cooldownSec: 4.5, priority: 1 },
  { type: 'look_right', weight: 10, minDurationSec: 1.4, maxDurationSec: 2.8, cooldownSec: 4.5, priority: 1 },
  { type: 'look_up', weight: 7, minDurationSec: 1.2, maxDurationSec: 2.2, cooldownSec: 6.0, priority: 1 },
  { type: 'look_down', weight: 7, minDurationSec: 1.2, maxDurationSec: 2.4, cooldownSec: 6.0, priority: 1 },
  { type: 'look_toward_ui', weight: 14, minDurationSec: 1.6, maxDurationSec: 3.2, cooldownSec: 4.0, priority: 2 },
  { type: 'posture_shift', weight: 13, minDurationSec: 2.5, maxDurationSec: 4.8, cooldownSec: 6.5, priority: 1 },
  { type: 'shoulder_movement', weight: 11, minDurationSec: 1.5, maxDurationSec: 2.8, cooldownSec: 5.0, priority: 1 },
  { type: 'subtle_hand_movement', weight: 9, minDurationSec: 1.8, maxDurationSec: 3.2, cooldownSec: 7.0, priority: 2 },
  { type: 'thinking_gesture', weight: 6, minDurationSec: 2.2, maxDurationSec: 3.8, cooldownSec: 10.0, priority: 3 },
  { type: 'relaxed_stance', weight: 15, minDurationSec: 2.8, maxDurationSec: 5.5, cooldownSec: 5.0, priority: 1 },
  { type: 'small_facial_expression', weight: 10, minDurationSec: 1.8, maxDurationSec: 3.5, cooldownSec: 6.0, priority: 2 },
];

export interface IdleAnimationOutputs {
  blinkAmount: number; // 0 (open) to 1 (closed)
  breathPhase: number; // -1 to +1 continuous chest/shoulder breathing
  eyeOffsetX: number; // -1 to +1
  eyeOffsetY: number; // -1 to +1
  headYawY: number; // radians
  headPitchX: number; // radians
  headRollZ: number; // radians
  torsoSwayX: number;
  shoulderLift: number;
  rightArmRaise: number;
  activeBehavior: IdleMicroBehaviorType;
}

/**
 * IdleBehaviorController
 * Ensures N3k never looks frozen by running a continuous, non-repeating
 * weighted random behavior scheduler with randomized blink/double-blink timing,
 * micro eye saccades, breathing, and smooth posture transitions.
 */
export class IdleBehaviorController {
  private elapsedTime = 0;

  // Randomized natural blink scheduling
  private nextBlinkTime = 1.8;
  private blinkProgress = -1;
  private isDoubleBlink = false;
  private secondBlinkPending = false;

  // Weighted behavior state
  private activeBehavior: IdleMicroBehaviorType = 'look_toward_camera';
  private behaviorTimer = 0;
  private behaviorDuration = 3.0;
  private cooldowns: Map<IdleMicroBehaviorType, number> = new Map();

  // Target offsets and smoothed current offsets
  private targetEyeX = 0;
  private targetEyeY = 0;
  private targetHeadYaw = 0;
  private targetHeadPitch = 0;
  private targetHeadRoll = 0;
  private targetTorsoSway = 0;
  private targetShoulderLift = 0;
  private targetRightArm = 0;

  private outputs: IdleAnimationOutputs = {
    blinkAmount: 0,
    breathPhase: 0,
    eyeOffsetX: 0,
    eyeOffsetY: 0,
    headYawY: 0,
    headPitchX: 0,
    headRollZ: 0,
    torsoSwayX: 0,
    shoulderLift: 0,
    rightArmRaise: 0,
    activeBehavior: 'look_toward_camera',
  };

  public update(deltaSeconds: number): IdleAnimationOutputs {
    this.elapsedTime += deltaSeconds;

    // 1. Continuous organic breathing (blend of two slightly offset frequencies so it never feels mechanical)
    this.outputs.breathPhase =
      Math.sin(this.elapsedTime * 1.65) * 0.7 + Math.sin(this.elapsedTime * 0.92) * 0.3;

    // 2. Randomized natural blinking & double-blinking
    let blinkVal = 0;
    if (this.blinkProgress >= 0) {
      this.blinkProgress += deltaSeconds * 7.8; // ~130ms blink
      if (this.blinkProgress <= 1) {
        blinkVal = Math.sin(this.blinkProgress * Math.PI);
      } else {
        this.blinkProgress = -1;
        if (this.isDoubleBlink && this.secondBlinkPending) {
          this.secondBlinkPending = false;
          this.nextBlinkTime = this.elapsedTime + 0.09;
        } else {
          // Next natural blink between 1.8s and 5.6s
          this.nextBlinkTime = this.elapsedTime + 1.8 + Math.random() * 3.8;
        }
      }
    } else if (this.elapsedTime >= this.nextBlinkTime) {
      this.blinkProgress = 0;
      this.isDoubleBlink = Math.random() < 0.22; // 22% chance of realistic double-blink
      this.secondBlinkPending = this.isDoubleBlink;
    }
    this.outputs.blinkAmount = blinkVal;

    // 3. Weighted behavior selection with cooldowns
    this.behaviorTimer += deltaSeconds;
    if (this.behaviorTimer >= this.behaviorDuration) {
      this.pickNextWeightedBehavior();
    }

    // 4. Micro eye saccades (subtle jitter every ~0.8s)
    const microSaccadeX = Math.sin(this.elapsedTime * 3.7) * 0.03;
    const microSaccadeY = Math.cos(this.elapsedTime * 2.9) * 0.02;

    // 5. Smoothly interpolate outputs
    const eyeLerp = Math.min(1, deltaSeconds * 9.0);
    const bodyLerp = Math.min(1, deltaSeconds * 3.2);

    this.outputs.eyeOffsetX += (this.targetEyeX + microSaccadeX - this.outputs.eyeOffsetX) * eyeLerp;
    this.outputs.eyeOffsetY += (this.targetEyeY + microSaccadeY - this.outputs.eyeOffsetY) * eyeLerp;
    this.outputs.headYawY += (this.targetHeadYaw - this.outputs.headYawY) * bodyLerp;
    this.outputs.headPitchX += (this.targetHeadPitch - this.outputs.headPitchX) * bodyLerp;
    this.outputs.headRollZ += (this.targetHeadRoll - this.outputs.headRollZ) * bodyLerp;
    this.outputs.torsoSwayX += (this.targetTorsoSway - this.outputs.torsoSwayX) * bodyLerp;
    this.outputs.shoulderLift += (this.targetShoulderLift - this.outputs.shoulderLift) * bodyLerp;
    this.outputs.rightArmRaise += (this.targetRightArm - this.outputs.rightArmRaise) * bodyLerp;
    this.outputs.activeBehavior = this.activeBehavior;

    return this.outputs;
  }

  private pickNextWeightedBehavior() {
    const now = this.elapsedTime;
    const available = IDLE_BEHAVIOR_POOL.filter((b) => {
      const readyAt = this.cooldowns.get(b.type) || 0;
      return now >= readyAt;
    });

    const candidates = available.length > 0 ? available : IDLE_BEHAVIOR_POOL;
    const totalWeight = candidates.reduce((acc, b) => acc + b.weight, 0);
    let r = Math.random() * totalWeight;
    let chosen = candidates[0];

    for (const candidate of candidates) {
      r -= candidate.weight;
      if (r <= 0) {
        chosen = candidate;
        break;
      }
    }

    this.activeBehavior = chosen.type;
    this.behaviorTimer = 0;
    this.behaviorDuration =
      chosen.minDurationSec + Math.random() * (chosen.maxDurationSec - chosen.minDurationSec);
    this.cooldowns.set(chosen.type, now + this.behaviorDuration + chosen.cooldownSec);

    // Reset defaults
    this.targetEyeX = 0;
    this.targetEyeY = 0;
    this.targetHeadYaw = (Math.random() - 0.5) * 0.08;
    this.targetHeadPitch = (Math.random() - 0.5) * 0.05;
    this.targetHeadRoll = (Math.random() - 0.5) * 0.05;
    this.targetTorsoSway = (Math.random() - 0.5) * 0.04;
    this.targetShoulderLift = 0;
    this.targetRightArm = 0;

    switch (chosen.type) {
      case 'look_left':
        this.targetEyeX = -0.45;
        this.targetHeadYaw = -0.16;
        break;
      case 'look_right':
        this.targetEyeX = 0.45;
        this.targetHeadYaw = 0.16;
        break;
      case 'look_up':
        this.targetEyeY = 0.35;
        this.targetHeadPitch = -0.12;
        break;
      case 'look_down':
        this.targetEyeY = -0.35;
        this.targetHeadPitch = 0.12;
        break;
      case 'look_toward_ui':
        this.targetEyeX = Math.random() > 0.5 ? 0.35 : -0.35;
        this.targetEyeY = 0.2;
        this.targetHeadYaw = this.targetEyeX * 0.35;
        break;
      case 'head_tilt':
        this.targetHeadRoll = (Math.random() > 0.5 ? 1 : -1) * 0.11;
        break;
      case 'small_nod':
        this.targetHeadPitch = 0.11;
        break;
      case 'posture_shift':
        this.targetTorsoSway = (Math.random() > 0.5 ? 1 : -1) * 0.07;
        this.targetHeadRoll = -this.targetTorsoSway * 0.6;
        break;
      case 'shoulder_movement':
        this.targetShoulderLift = 0.04;
        break;
      case 'subtle_hand_movement':
        this.targetRightArm = 0.25;
        break;
      case 'thinking_gesture':
        this.targetRightArm = 0.65;
        this.targetHeadRoll = 0.08;
        this.targetEyeY = 0.22;
        break;
      default:
        break;
    }
  }
}

export const globalIdleBehaviorController = new IdleBehaviorController();
