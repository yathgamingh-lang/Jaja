import { Memory, MemoryCategory } from './MemoryTypes.ts';

export interface IMemoryStore {
  init(): Promise<void>;
  put(memory: Memory): Promise<void>;
  get(id: string): Promise<Memory | undefined>;
  getByKey(key: string, category?: MemoryCategory): Promise<Memory | undefined>;
  getAll(): Promise<Memory[]>;
  getByCategory(category: MemoryCategory): Promise<Memory[]>;
  delete(id: string): Promise<boolean>;
  deleteByKey(key: string, category?: MemoryCategory): Promise<boolean>;
  clear(): Promise<void>;
  count(): Promise<number>;
}

export class IndexedDBMemoryStore implements IMemoryStore {
  private dbName = 'ZinxN3kBrainDB';
  private dbVersion = 1;
  private storeName = 'memories';
  private db: IDBDatabase | null = null;
  private fallbackMemory: Map<string, Memory> = new Map();
  private isFallback = false;

  public async init(): Promise<void> {
    if (this.db) return;

    if (typeof window === 'undefined' || !window.indexedDB) {
      console.warn('[ZinxN3kBrain] IndexedDB not available, using fallback memory store');
      this.initFallback();
      return;
    }

    try {
      this.db = await new Promise<IDBDatabase>((resolve, reject) => {
        const request = window.indexedDB.open(this.dbName, this.dbVersion);

        request.onupgradeneeded = (event) => {
          const db = (event.target as IDBOpenDBRequest).result;
          if (!db.objectStoreNames.contains(this.storeName)) {
            const store = db.createObjectStore(this.storeName, { keyPath: 'id' });
            store.createIndex('category', 'category', { unique: false });
            store.createIndex('key', 'key', { unique: false });
            store.createIndex('updatedAt', 'updatedAt', { unique: false });
            store.createIndex('confidence', 'confidence', { unique: false });
          }
        };

        request.onsuccess = () => {
          resolve(request.result);
        };

        request.onerror = () => {
          reject(request.error);
        };
      });
      console.log('[ZinxN3kBrain] Persistent IndexedDB storage initialized');
      await this.migrateLegacyDataIfPresent();
    } catch (err) {
      console.warn('[ZinxN3kBrain] Failed to open IndexedDB, falling back to local storage:', err);
      this.initFallback();
    }
  }

  private async migrateLegacyDataIfPresent() {
    try {
      const legacyRaw = localStorage.getItem('myraa_brain_fallback');
      if (legacyRaw) {
        const legacyList: Memory[] = JSON.parse(legacyRaw);
        for (const m of legacyList) {
          await this.put(m);
        }
        localStorage.removeItem('myraa_brain_fallback');
      }
    } catch {}
  }

  private initFallback() {
    this.isFallback = true;
    try {
      const raw = localStorage.getItem('zinxn3k_brain_fallback') || localStorage.getItem('myraa_brain_fallback');
      if (raw) {
        const list: Memory[] = JSON.parse(raw);
        list.forEach((m) => this.fallbackMemory.set(m.id, m));
      }
    } catch {}
  }

  private saveFallback() {
    if (!this.isFallback) return;
    try {
      const list = Array.from(this.fallbackMemory.values());
      localStorage.setItem('zinxn3k_brain_fallback', JSON.stringify(list));
    } catch {}
  }

  public async put(memory: Memory): Promise<void> {
    await this.init();
    if (this.isFallback || !this.db) {
      this.fallbackMemory.set(memory.id, memory);
      this.saveFallback();
      return;
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(this.storeName, 'readwrite');
      const store = tx.objectStore(this.storeName);
      const req = store.put(memory);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  public async get(id: string): Promise<Memory | undefined> {
    await this.init();
    if (this.isFallback || !this.db) {
      return this.fallbackMemory.get(id);
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(this.storeName, 'readonly');
      const store = tx.objectStore(this.storeName);
      const req = store.get(id);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  public async getByKey(key: string, category?: MemoryCategory): Promise<Memory | undefined> {
    const all = await this.getAll();
    const normalized = key.toLowerCase().trim();
    return all.find((m) => {
      const matchesKey = m.key.toLowerCase().trim() === normalized;
      if (category) {
        return matchesKey && m.category === category;
      }
      return matchesKey;
    });
  }

  public async getAll(): Promise<Memory[]> {
    await this.init();
    if (this.isFallback || !this.db) {
      return Array.from(this.fallbackMemory.values()).sort((a, b) => b.updatedAt - a.updatedAt);
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(this.storeName, 'readonly');
      const store = tx.objectStore(this.storeName);
      const req = store.getAll();
      req.onsuccess = () => {
        const res: Memory[] = req.result || [];
        res.sort((a, b) => b.updatedAt - a.updatedAt);
        resolve(res);
      };
      req.onerror = () => reject(req.error);
    });
  }

  public async getByCategory(category: MemoryCategory): Promise<Memory[]> {
    const all = await this.getAll();
    return all.filter((m) => m.category === category);
  }

  public async delete(id: string): Promise<boolean> {
    await this.init();
    if (this.isFallback || !this.db) {
      const existed = this.fallbackMemory.delete(id);
      this.saveFallback();
      return existed;
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(this.storeName, 'readwrite');
      const store = tx.objectStore(this.storeName);
      const req = store.delete(id);
      req.onsuccess = () => resolve(true);
      req.onerror = () => reject(req.error);
    });
  }

  public async deleteByKey(key: string, category?: MemoryCategory): Promise<boolean> {
    const target = await this.getByKey(key, category);
    if (target) {
      return await this.delete(target.id);
    }
    return false;
  }

  public async clear(): Promise<void> {
    await this.init();
    if (this.isFallback || !this.db) {
      this.fallbackMemory.clear();
      this.saveFallback();
      return;
    }

    return new Promise((resolve, reject) => {
      const tx = this.db!.transaction(this.storeName, 'readwrite');
      const store = tx.objectStore(this.storeName);
      const req = store.clear();
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  }

  public async count(): Promise<number> {
    const all = await this.getAll();
    return all.length;
  }
}
