import { IMemoryStore, IndexedDBMemoryStore } from './MemoryStore.ts';
import { Memory, MemoryCategory, MemoryFilter, MemorySearchResult } from './MemoryTypes.ts';
import { MemoryRetriever } from './MemoryRetriever.ts';
import { MemoryContext } from './MemoryContext.ts';

export class MemoryManager {
  private store: IMemoryStore;
  private memoryListeners: Set<(memories: Memory[]) => void> = new Set();
  private cachedMemories: Memory[] = [];
  private isLoaded = false;

  constructor(store?: IMemoryStore) {
    this.store = store || new IndexedDBMemoryStore();
  }

  public async init(): Promise<void> {
    if (this.isLoaded) return;
    await this.store.init();
    await this.refreshCache();
    this.isLoaded = true;
  }

  public subscribe(listener: (memories: Memory[]) => void): () => void {
    this.memoryListeners.add(listener);
    if (this.isLoaded) {
      listener(this.cachedMemories);
    } else {
      this.init().then(() => listener(this.cachedMemories));
    }
    return () => {
      this.memoryListeners.delete(listener);
    };
  }

  private notify() {
    this.memoryListeners.forEach((l) => l(this.cachedMemories));
  }

  private async refreshCache(): Promise<Memory[]> {
    this.cachedMemories = await this.store.getAll();
    this.notify();
    return this.cachedMemories;
  }

  public async getAllMemories(): Promise<Memory[]> {
    await this.init();
    return this.cachedMemories;
  }

  /**
   * Saves a new memory or logically updates an existing one if the key already exists
   * to avoid contradictory duplicated memories.
   */
  public async saveMemory(params: {
    category: MemoryCategory;
    key: string;
    value: string;
    confidence?: number;
    source?: 'user' | 'conversation' | 'system';
    tags?: string[];
  }): Promise<Memory> {
    await this.init();
    const normalizedKey = params.key.toLowerCase().trim();
    const now = Date.now();

    const existing = this.cachedMemories.find((m) => {
      const matchKey = m.key.toLowerCase().trim() === normalizedKey;
      return matchKey;
    });

    let targetMemory: Memory;

    if (existing) {
      targetMemory = {
        ...existing,
        category: params.category || existing.category,
        key: params.key.trim(),
        value: params.value.trim(),
        confidence: params.confidence !== undefined ? params.confidence : existing.confidence,
        source: params.source || existing.source,
        updatedAt: now,
        lastUsedAt: now,
        tags: params.tags || existing.tags,
      };
      console.log(`[ZinxN3kBrain] Updating existing memory (${existing.key} -> ${params.value})`);
    } else {
      targetMemory = {
        id: `mem_${now}_${Math.random().toString(36).substring(2, 7)}`,
        category: params.category,
        key: params.key.trim(),
        value: params.value.trim(),
        confidence:
          params.confidence !== undefined ? Math.max(0.1, Math.min(1.0, params.confidence)) : 1.0,
        source: params.source || 'user',
        createdAt: now,
        updatedAt: now,
        lastUsedAt: now,
        tags: params.tags || [],
      };
      console.log(
        `[ZinxN3kBrain] Stored new memory: [${params.category}] ${params.key} = ${params.value}`,
      );
    }

    await this.store.put(targetMemory);
    await this.refreshCache();
    return targetMemory;
  }

  public async updateMemory(
    id: string,
    updates: Partial<Omit<Memory, 'id' | 'createdAt'>>,
  ): Promise<Memory | null> {
    await this.init();
    const existing = await this.store.get(id);
    if (!existing) return null;

    const updated: Memory = {
      ...existing,
      ...updates,
      updatedAt: Date.now(),
    };
    await this.store.put(updated);
    await this.refreshCache();
    return updated;
  }

  public async deleteMemory(id: string): Promise<boolean> {
    await this.init();
    const res = await this.store.delete(id);
    await this.refreshCache();
    return res;
  }

  public async deleteMemoryByKey(key: string, category?: MemoryCategory): Promise<boolean> {
    await this.init();
    const normalizedKey = key.toLowerCase().trim();
    const target = this.cachedMemories.find((m) => {
      const matches = m.key.toLowerCase().trim() === normalizedKey;
      return category ? matches && m.category === category : matches;
    });

    if (target) {
      return await this.deleteMemory(target.id);
    }
    return false;
  }

  public async searchMemory(filter: MemoryFilter): Promise<MemorySearchResult[]> {
    await this.init();
    return MemoryRetriever.rankMemories(
      this.cachedMemories,
      filter.query || '',
      filter.category,
      filter.minConfidence,
      filter.limit,
    );
  }

  public async getRelevantMemories(query: string, limit = 5): Promise<Memory[]> {
    await this.init();
    const ranked = MemoryRetriever.rankMemories(this.cachedMemories, query, 'all', 0.5, limit);
    return ranked.map((r) => r.memory);
  }

  public async markUsed(id: string): Promise<void> {
    const memory = this.cachedMemories.find((m) => m.id === id);
    if (memory) {
      memory.lastUsedAt = Date.now();
      await this.store.put(memory);
    }
  }

  public async clearAllMemories(): Promise<void> {
    await this.init();
    await this.store.clear();
    await this.refreshCache();
    console.log('[ZinxN3kBrain] Cleared all persistent memories');
  }

  public async exportMemories(): Promise<string> {
    await this.init();
    return JSON.stringify(this.cachedMemories, null, 2);
  }

  public async importMemories(jsonString: string): Promise<number> {
    await this.init();
    try {
      const parsed = JSON.parse(jsonString);
      if (!Array.isArray(parsed)) throw new Error('Expected array of memories');
      let count = 0;
      for (const item of parsed) {
        if (item.key && item.value && item.category) {
          await this.saveMemory({
            category: item.category,
            key: item.key,
            value: item.value,
            confidence: item.confidence,
            source: item.source || 'user',
            tags: item.tags,
          });
          count++;
        }
      }
      await this.refreshCache();
      return count;
    } catch (err: any) {
      console.error('[ZinxN3kBrain] Import failed:', err);
      throw new Error(`Import failed: ${err?.message || 'Invalid format'}`);
    }
  }

  public getCompactContext(): string {
    return MemoryContext.buildCompactContext(this.cachedMemories);
  }

  public getMemoriesCount(): number {
    return this.cachedMemories.length;
  }
}

export const globalMemoryManager = new MemoryManager();
