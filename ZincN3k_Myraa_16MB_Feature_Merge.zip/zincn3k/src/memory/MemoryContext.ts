import { Memory } from './MemoryTypes.ts';

export class MemoryContext {
  /**
   * Generates a compact, high-value prompt block to inject into Gemini Live system instruction.
   * Prioritizes identity, preferred language, communication preferences, and key favorites.
   */
  public static buildCompactContext(memories: Memory[]): string {
    if (!memories || memories.length === 0) {
      return '';
    }

    // Group or filter top memories
    const identityMemories = memories.filter((m) => m.category === 'identity' && m.confidence >= 0.8);
    const commMemories = memories.filter(
      (m) =>
        (m.category === 'communication_style' ||
          m.category === 'language' ||
          m.category === 'preferences') &&
        m.confidence >= 0.7,
    );
    const topInterests = memories
      .filter(
        (m) =>
          (m.category === 'favorites' ||
            m.category === 'likes' ||
            m.category === 'projects' ||
            m.category === 'hobbies') &&
          m.confidence >= 0.8,
      )
      .slice(0, 6);

    const items: string[] = [];

    // Identity items (e.g. name, nickname)
    identityMemories.forEach((m) => {
      items.push(`* ${m.key}: ${m.value}`);
    });

    // Communication & Language items
    commMemories.forEach((m) => {
      items.push(`* ${m.key}: ${m.value}`);
    });

    // Top Interests & Projects
    topInterests.forEach((m) => {
      items.push(`* ${m.key}: ${m.value}`);
    });

    // Other high-confidence items if not already added
    const otherImportant = memories
      .filter((m) => m.confidence === 1.0 && !items.some((i) => i.includes(m.key)))
      .slice(0, 5);
    otherImportant.forEach((m) => {
      items.push(`* ${m.key}: ${m.value}`);
    });

    if (items.length === 0) {
      return '';
    }

    return `
========================================
KNOWN USER CONTEXT & LONG-TERM MEMORY:
(You have spoken with this user before and stored these verified memories. Naturally refer to them when relevant, but do NOT robotically state memory record numbers):
${items.join('\n')}
========================================`;
  }
}
