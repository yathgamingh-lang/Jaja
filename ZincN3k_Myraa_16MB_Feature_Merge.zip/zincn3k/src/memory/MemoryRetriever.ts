import { Memory, MemoryCategory, MemorySearchResult } from './MemoryTypes.ts';

export class MemoryRetriever {
  /**
   * Scores and ranks memories based on relevance to a given query or context string.
   * Considers keyword overlap, category affinity, confidence level, and recency.
   */
  public static rankMemories(
    memories: Memory[],
    query: string,
    targetCategory?: MemoryCategory | 'all',
    minConfidence = 0.5,
    limit = 6,
  ): MemorySearchResult[] {
    const cleanQuery = query.toLowerCase().trim();
    const queryTokens = cleanQuery
      .split(/[\s,?.!;:_/-]+/)
      .filter((t) => t.length > 1);

    const now = Date.now();
    const scored: MemorySearchResult[] = [];

    for (const mem of memories) {
      if (mem.confidence < minConfidence) continue;
      if (targetCategory && targetCategory !== 'all' && mem.category !== targetCategory) {
        continue;
      }

      let score = 0;
      const keyLower = mem.key.toLowerCase();
      const valLower = mem.value.toLowerCase();
      const catLower = mem.category.toLowerCase();

      // 1. Direct key exact or partial match
      if (keyLower === cleanQuery) {
        score += 8.0;
      } else if (cleanQuery.includes(keyLower) || keyLower.includes(cleanQuery)) {
        score += 4.5;
      }

      // 2. Token overlap scoring
      for (const token of queryTokens) {
        if (keyLower.includes(token)) {
          score += 3.0;
        }
        if (valLower.includes(token)) {
          score += 2.0;
        }
        if (catLower.includes(token)) {
          score += 1.5;
        }
      }

      // 3. Category match boost
      if (targetCategory && mem.category === targetCategory) {
        score += 2.0;
      }

      // 4. Confidence weighting (0.5 to 1.0)
      score *= mem.confidence || 0.8;

      // 5. Recency boost (memories updated in the last 7 days get a slight bump)
      const ageHours = (now - mem.updatedAt) / (1000 * 60 * 60);
      if (ageHours < 24) {
        score += 0.8;
      } else if (ageHours < 168) {
        score += 0.4;
      }

      // 6. Last used boost
      if (mem.lastUsedAt) {
        const lastUsedHours = (now - mem.lastUsedAt) / (1000 * 60 * 60);
        if (lastUsedHours < 12) {
          score += 0.5;
        }
      }

      if (score > 0 || !cleanQuery) {
        scored.push({
          memory: mem,
          score: cleanQuery ? score : mem.confidence + mem.updatedAt / now,
          matchReason: score > 3 ? 'High semantic match' : 'Keyword correlation',
        });
      }
    }

    // Sort descending by score
    scored.sort((a, b) => b.score - a.score);
    return scored.slice(0, limit);
  }
}
