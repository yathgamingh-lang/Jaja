export type MemoryCategory =
  | 'identity'
  | 'preferences'
  | 'likes'
  | 'dislikes'
  | 'hobbies'
  | 'interests'
  | 'favorites'
  | 'communication_style'
  | 'language'
  | 'projects'
  | 'goals'
  | 'routines'
  | 'frequently_used_commands'
  | 'assistant_preferences'
  | 'important_context'
  | 'custom_memory';

export interface Memory {
  id: string;
  category: MemoryCategory;
  key: string;
  value: string;
  source: 'user' | 'conversation' | 'system';
  confidence: number; // e.g. 1.0 (explicit), 0.9 (clear), 0.7 (implied), 0.5 (uncertain)
  createdAt: number;
  updatedAt: number;
  lastUsedAt?: number;
  tags?: string[];
}

export interface MemoryFilter {
  query?: string;
  category?: MemoryCategory | 'all';
  minConfidence?: number;
  limit?: number;
}

export interface MemoryStats {
  total: number;
  byCategory: Record<MemoryCategory, number>;
  lastUpdated: number;
}

export interface MemorySearchResult {
  memory: Memory;
  score: number;
  matchReason?: string;
}

export const MEMORY_CATEGORIES: { id: MemoryCategory; label: string; icon: string; description: string }[] = [
  { id: 'identity', label: 'Identity', icon: 'User', description: 'Name, nickname, role, and who the user is' },
  { id: 'preferences', label: 'Preferences', icon: 'Sliders', description: 'General habits and lifestyle preferences' },
  { id: 'likes', label: 'Likes', icon: 'ThumbsUp', description: 'Things, music, food, or activities enjoyed' },
  { id: 'dislikes', label: 'Dislikes', icon: 'ThumbsDown', description: 'Aversions, pet peeves, and things to avoid' },
  { id: 'hobbies', label: 'Hobbies', icon: 'Gamepad2', description: 'Leisure activities, crafts, and sports' },
  { id: 'interests', label: 'Interests', icon: 'Compass', description: 'Fields of study, curiosities, and passions' },
  { id: 'favorites', label: 'Favorites', icon: 'Star', description: 'Top picks (game, color, food, book, etc.)' },
  { id: 'communication_style', label: 'Style', icon: 'MessageSquare', description: 'Concise vs detailed, humor, tone' },
  { id: 'language', label: 'Language', icon: 'Languages', description: 'Preferred languages and dialects' },
  { id: 'projects', label: 'Projects', icon: 'Briefcase', description: 'Current ventures, apps, and coding projects' },
  { id: 'goals', label: 'Goals', icon: 'Target', description: 'Short and long-term milestones' },
  { id: 'routines', label: 'Routines', icon: 'Clock', description: 'Daily schedules, sleep, workout patterns' },
  { id: 'frequently_used_commands', label: 'Common Tasks', icon: 'Repeat', description: 'Frequently invoked voice commands' },
  { id: 'assistant_preferences', label: 'ZinxN3k Persona', icon: 'Sparkles', description: 'Preferences for how ZinxN3k acts' },
  { id: 'important_context', label: 'Context', icon: 'Info', description: 'Family, colleagues, location, background' },
  { id: 'custom_memory', label: 'Custom', icon: 'Bookmark', description: 'Custom notes and user-requested facts' },
];
