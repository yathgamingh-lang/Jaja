export type AssistantState =
  | 'disconnected'
  | 'connecting'
  | 'listening'
  | 'thinking'
  | 'executing'
  | 'speaking'
  | 'interrupted'
  | 'error';

export type DynamicIslandState =
  | 'collapsed'
  | 'listening'
  | 'thinking'
  | 'executing'
  | 'speaking'
  | 'screen_active'
  | 'error'
  | 'command_center';

export type AssistantTheme =
  | 'cyber-cyan'
  | 'electric-violet'
  | 'midnight-emerald'
  | 'solar-amber'
  | 'crimson-pulse';

export interface ThemeConfig {
  id: AssistantTheme;
  name: string;
  primary: string;
  glow: string;
  secondary: string;
  accent: string;
  bgGlow: string;
}

export type VoicePersona = 'Fenrir' | 'Puck' | 'Charon' | 'Orus' | 'Kore' | 'Zephyr';

export interface VoiceOption {
  id: VoicePersona;
  name: string;
  description: string;
  gender: string;
  tag: string;
}

export interface YouTubeSearchResultItem {
  videoId: string;
  title: string;
  author?: string;
  thumbnail: string;
  duration?: string;
}

export interface BrowserTabState {
  isOpen: boolean;
  url: string;
  inputUrl: string;
  title: string;
  isLoading: boolean;
  canGoBack: boolean;
  canGoForward: boolean;
  isIframeBlocked: boolean;
  blockReason?: string | null;
  mode: 'web' | 'youtube';
  youtubeQuery?: string;
  youtubeVideoId?: string;
  youtubeResults?: YouTubeSearchResultItem[];
  isPlaying?: boolean;
  volume?: number;
}

export type ScreenShareStatus =
  | 'idle'
  | 'requesting'
  | 'active'
  | 'paused'
  | 'stopped'
  | 'error';

export interface ScreenShareState {
  status: ScreenShareStatus;
  isSharing: boolean;
  isPaused?: boolean;
  isPreviewMinimized: boolean;
  stream: MediaStream | null;
  lastCapturedTimestamp: number;
  error?: string | null;
}

export interface AndroidPlatformCapabilities {
  isAndroidNative: boolean;
  accessibilityEnabled: boolean;
  mediaProjectionActive: boolean;
  mediaProjectionPaused: boolean;
  foregroundPackage: string;
  micGranted: boolean;
  cameraGranted: boolean;
  notificationsGranted: boolean;
  notificationListenerEnabled: boolean;
  contactsGranted: boolean;
}

export interface ActiveTimer {
  id: string;
  label: string;
  totalSeconds: number;
  remainingSeconds: number;
  isPaused: boolean;
  createdAt: number;
}

export interface ToolActionCard {
  id: string;
  type:
    | 'website'
    | 'theme'
    | 'timer'
    | 'info'
    | 'math'
    | 'camera'
    | 'search'
    | 'status'
    | 'android'
    | 'game'
    | 'pc';
  title: string;
  content: string;
  url?: string;
  timestamp: number;
  tag?: string;
}

export interface AudioStats {
  userLevel: number; // 0 to 1
  assistantLevel: number; // 0 to 1
  isMuted: boolean;
  activeMicLabel: string;
}

export interface SessionInfo {
  startTime: number | null;
  durationSeconds: number;
  latencyMs: number;
  turnsCount: number;
  model: string;
  voice: VoicePersona;
}

export type PermissionStatusType = 'granted' | 'denied' | 'prompt' | 'not_supported';

export interface SystemPermissions {
  microphone: PermissionStatusType;
  camera: PermissionStatusType;
  notifications: PermissionStatusType;
  location: PermissionStatusType;
}

export type SupportedLanguage =
  | 'English'
  | 'Hindi'
  | 'Hinglish'
  | 'Punjabi'
  | 'Portuguese'
  | 'Russian'
  | 'Chinese';
