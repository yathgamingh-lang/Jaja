import { globalMemoryManager, MemoryManager } from '../memory/MemoryManager.ts';
import { MemoryCategory } from '../memory/MemoryTypes.ts';

export function registerMemoryTools(
  registerTool: (
    name: string,
    handler: (args: Record<string, any>, callId: string) => Promise<any> | any,
  ) => void,
  memoryManager: MemoryManager = globalMemoryManager,
) {
  // 1. saveMemory
  registerTool('saveMemory', async (args) => {
    const category = (args.category || 'important_context') as MemoryCategory;
    const key = String(args.key || '').trim();
    const value = String(args.value || '').trim();
    const confidence = Number(args.confidence !== undefined ? args.confidence : 1.0);

    if (!key || !value) {
      return { status: 'error', message: 'Both key and value are required to save a memory' };
    }

    const saved = await memoryManager.saveMemory({
      category,
      key,
      value,
      confidence,
      source: 'user',
    });

    return {
      status: 'success',
      action: 'saved',
      memoryId: saved.id,
      key: saved.key,
      value: saved.value,
      category: saved.category,
      message: `Successfully remembered ${saved.key} as ${saved.value}`,
    };
  });

  // 2. updateMemory
  registerTool('updateMemory', async (args) => {
    const key = String(args.key || '').trim();
    const value = String(args.value || '').trim();
    const memoryId = args.memoryId ? String(args.memoryId) : undefined;
    const category = args.category ? (String(args.category) as MemoryCategory) : undefined;

    if (memoryId) {
      const updated = await memoryManager.updateMemory(memoryId, {
        value,
        ...(key ? { key } : {}),
        ...(category ? { category } : {}),
      });
      if (updated) {
        return {
          status: 'success',
          action: 'updated',
          key: updated.key,
          value: updated.value,
          message: `Updated memory for ${updated.key}`,
        };
      }
    }

    if (key && value) {
      const updated = await memoryManager.saveMemory({
        category: category || 'preferences',
        key,
        value,
        confidence: 1.0,
      });
      return {
        status: 'success',
        action: 'updated',
        key: updated.key,
        value: updated.value,
        message: `Updated memory for ${updated.key}`,
      };
    }

    return { status: 'error', message: 'Need either memoryId or key and new value' };
  });

  // 3. deleteMemory
  registerTool('deleteMemory', async (args) => {
    const memoryId = args.memoryId ? String(args.memoryId) : undefined;
    const key = args.key ? String(args.key).trim() : undefined;
    const category = args.category ? (String(args.category) as MemoryCategory) : undefined;

    let deleted = false;
    if (memoryId) {
      deleted = await memoryManager.deleteMemory(memoryId);
    } else if (key) {
      deleted = await memoryManager.deleteMemoryByKey(key, category);
    }

    if (deleted) {
      return {
        status: 'success',
        action: 'deleted',
        message: `Removed memory ${key || memoryId}`,
      };
    }

    return {
      status: 'not_found',
      message: `No matching memory found for ${key || memoryId}`,
    };
  });

  // 4. searchMemory & memorySearch
  const handleSearchMemory = async (args: Record<string, any>) => {
    const query = String(args.query || '').trim();
    const category = args.category ? (args.category as MemoryCategory) : 'all';

    const results = await memoryManager.searchMemory({
      query,
      category,
      limit: 8,
    });

    const memories = results.map((r) => ({
      key: r.memory.key,
      value: r.memory.value,
      category: r.memory.category,
      confidence: r.memory.confidence,
    }));

    return {
      status: 'success',
      query,
      count: memories.length,
      memories,
    };
  };

  registerTool('searchMemory', handleSearchMemory);
  registerTool('memorySearch', handleSearchMemory);

  // 5. getRelevantMemories
  registerTool('getRelevantMemories', async (args) => {
    const query = String(args.query || args.context || '').trim();
    const memories = await memoryManager.getRelevantMemories(query, 5);
    return {
      status: 'success',
      relevant: memories.map((m) => ({
        key: m.key,
        value: m.value,
        category: m.category,
      })),
    };
  });

  // 6. clearAllMemories
  registerTool('clearAllMemories', async (args) => {
    const confirm = Boolean(args.confirm);
    if (!confirm) {
      return {
        status: 'confirmation_required',
        message:
          'This will delete all saved memories. Please confirm with the user before proceeding.',
      };
    }
    await memoryManager.clearAllMemories();
    return {
      status: 'success',
      action: 'cleared_all',
      message: 'All long-term memories have been cleared.',
    };
  });

  // 7. listMemories
  registerTool('listMemories', async (args) => {
    const category = args.category ? (args.category as MemoryCategory) : undefined;
    const all = await memoryManager.getAllMemories();
    const filtered = category ? all.filter((m) => m.category === category) : all;
    return {
      status: 'success',
      total: filtered.length,
      memories: filtered.slice(0, 15).map((m) => ({
        key: m.key,
        value: m.value,
        category: m.category,
      })),
    };
  });
}
