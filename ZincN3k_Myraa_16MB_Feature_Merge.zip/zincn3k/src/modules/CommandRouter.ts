import { ToolManager } from './ToolManager.ts';
import { globalAndroidBridge } from './AndroidBridge.ts';
import { globalStateManager } from './StateManager.ts';

export interface UnifiedCommandPacket {
  intent:
    | 'launch_application'
    | 'launch_game'
    | 'open_game_hub'
    | 'browser_navigate'
    | 'browser_search'
    | 'youtube_search'
    | 'youtube_play'
    | 'system_navigation'
    | 'text_input'
    | 'screen_vision'
    | 'screen_share_control'
    | 'volume_control'
    | 'media_control'
    | 'memory_operation'
    | 'device_management'
    | 'pc_control'
    | 'file_operation'
    | 'system_status';
  target?: string;
  device: 'android' | 'windows' | 'web_hud' | 'auto';
  query?: string;
  parameters: Record<string, any>;
}

/**
 * CommandRouter
 * Implements the N3k V4 Unified Command Protocol and parses natural-language
 * voice commands (including English, Hindi, and Hinglish variations like
 * "Youtube kholo", "YouTube chalao", "Instagram kholo", "Launch Minecraft",
 * "Open YouTube on my PC", "Show connected devices").
 */
export class CommandRouter {
  public static parseNaturalCommand(rawText: string): UnifiedCommandPacket | null {
    const clean = rawText.trim();
    const lower = clean.toLowerCase();
    if (!lower) return null;

    const explicitPc =
      lower.includes('on my pc') ||
      lower.includes('on pc') ||
      lower.includes('on windows') ||
      lower.includes('on my computer');
    const explicitAndroid =
      lower.includes('on my phone') || lower.includes('on android');

    const defaultDevice: UnifiedCommandPacket['device'] = explicitPc
      ? 'windows'
      : explicitAndroid
        ? 'android'
        : globalAndroidBridge.isNativeAndroid()
          ? 'android'
          : 'auto';

    // Strip device suffix for cleaner target extraction
    const stripped = clean
      .replace(/\s+(on my pc|on pc|on windows|on my computer|on my phone|on android)$/i, '')
      .trim();
    const strippedLower = stripped.toLowerCase();

    // 1. Game Hub & Game Launching ("Open Game Hub", "Open my games", "Launch Minecraft", "Open Steam", "Open Epic Games")
    if (
      strippedLower === 'open game hub' ||
      strippedLower === 'open my games' ||
      strippedLower === 'open my game' ||
      strippedLower === 'show games'
    ) {
      return {
        intent: 'open_game_hub',
        device: 'web_hud',
        parameters: {},
      };
    }

    if (
      strippedLower.startsWith('launch ') ||
      strippedLower.startsWith('start game ') ||
      strippedLower === 'open steam' ||
      strippedLower === 'open epic games' ||
      strippedLower === 'open minecraft' ||
      strippedLower === 'play minecraft'
    ) {
      const gameTarget = stripped
        .replace(/^(launch|start game|open|play)\s+/i, '')
        .trim();
      return {
        intent: 'launch_game',
        target: gameTarget || 'Minecraft',
        device:
          gameTarget.toLowerCase().includes('steam') ||
          gameTarget.toLowerCase().includes('epic')
            ? 'windows'
            : defaultDevice,
        parameters: { gameName: gameTarget || 'Minecraft' },
      };
    }

    // 2. Multilingual App Openers ("Youtube kholo", "YouTube chalao", "Instagram kholo", "Open YouTube", "Go to YouTube")
    const kholoMatch = strippedLower.match(/^(.+?)\s+(kholo|chalao|open karo|chalu karo)$/i);
    if (kholoMatch) {
      const targetApp = kholoMatch[1].trim();
      return {
        intent: 'launch_application',
        target: targetApp,
        device: defaultDevice,
        parameters: { appName: targetApp },
      };
    }

    // 3. YouTube Search & Play
    if (strippedLower.startsWith('search youtube for ')) {
      const q = stripped.replace(/^search youtube for /i, '').trim();
      return {
        intent: 'youtube_search',
        query: q,
        device: defaultDevice,
        parameters: { query: q },
      };
    }

    if (
      strippedLower === 'play the first result' ||
      strippedLower === 'play a video' ||
      (strippedLower.startsWith('play ') && strippedLower.includes(' on youtube'))
    ) {
      const q = stripped
        .replace(/^play /i, '')
        .replace(/ on youtube$/i, '')
        .trim();
      return {
        intent: 'youtube_play',
        query: q,
        device: defaultDevice,
        parameters: { query: q },
      };
    }

    // 4. Web Search
    if (
      strippedLower.startsWith('search google for ') ||
      strippedLower.startsWith('search the web for ') ||
      strippedLower.startsWith('search for ')
    ) {
      const q = stripped
        .replace(/^(search google for|search the web for|search for)\s+/i, '')
        .trim();
      return {
        intent: 'browser_search',
        query: q,
        device: defaultDevice,
        parameters: { query: q, engine: 'google' },
      };
    }

    // 5. Screen Vision & Screen Sharing
    if (
      strippedLower.includes('what is on my screen') ||
      strippedLower.includes('take a look at this') ||
      strippedLower.includes('look at my screen') ||
      strippedLower === 'show my pc screen'
    ) {
      return {
        intent: 'screen_vision',
        device: strippedLower.includes('pc') ? 'windows' : defaultDevice,
        parameters: { prompt: clean },
      };
    }

    if (strippedLower === 'show my screen' || strippedLower === 'share my screen') {
      return {
        intent: 'screen_share_control',
        target: 'start',
        device: defaultDevice,
        parameters: {},
      };
    }

    // 6. Connected Devices & PC Pairing
    if (
      strippedLower === 'connect my pc' ||
      strippedLower === 'show connected devices' ||
      strippedLower === 'connected devices'
    ) {
      return {
        intent: 'device_management',
        device: 'web_hud',
        parameters: {},
      };
    }

    // 7. File Operations ("Open my files")
    if (strippedLower === 'open my files' || strippedLower === 'open file explorer') {
      return {
        intent: 'file_operation',
        target: 'explorer',
        device: 'windows',
        parameters: { operation: 'list' },
      };
    }

    // 8. Volume & Media Controls
    if (
      strippedLower === 'increase volume' ||
      strippedLower === 'volume up' ||
      strippedLower === 'decrease volume' ||
      strippedLower === 'volume down' ||
      strippedLower === 'mute'
    ) {
      const cmd =
        strippedLower.includes('increase') || strippedLower.includes('up')
          ? 'up'
          : strippedLower.includes('decrease') || strippedLower.includes('down')
            ? 'down'
            : 'mute';
      return {
        intent: 'volume_control',
        target: cmd,
        device: defaultDevice,
        parameters: { command: cmd },
      };
    }

    if (
      strippedLower === 'pause music' ||
      strippedLower === 'play music' ||
      strippedLower === 'resume music'
    ) {
      const isPause = strippedLower.includes('pause');
      return {
        intent: 'media_control',
        target: isPause ? 'pause' : 'play',
        device: defaultDevice,
        parameters: { command: isPause ? 'pause' : 'play' },
      };
    }

    // 9. Navigation ("Go back", "Go home", "Open recent apps")
    if (
      strippedLower === 'go back' ||
      strippedLower === 'go home' ||
      strippedLower === 'open recents' ||
      strippedLower === 'open recent apps'
    ) {
      return {
        intent: 'system_navigation',
        target: strippedLower.includes('back')
          ? 'back'
          : strippedLower.includes('home')
            ? 'home'
            : 'recents',
        device: defaultDevice,
        parameters: {},
      };
    }

    // 10. Generic "Open [Target]" / "Go to [Target]"
    if (strippedLower.startsWith('open ') || strippedLower.startsWith('go to ')) {
      const target = stripped.replace(/^(open|go to)\s+/i, '').trim();
      return {
        intent: 'launch_application',
        target,
        device: defaultDevice,
        parameters: { appName: target },
      };
    }

    return null;
  }

  public static async executePacket(
    packet: UnifiedCommandPacket,
    toolManager: ToolManager,
  ): Promise<any> {
    globalStateManager.setAssistantState('executing');
    try {
      switch (packet.intent) {
        case 'open_game_hub':
          return await toolManager.executeTool('openGameHub', {}, 'router');

        case 'launch_game':
          return await toolManager.executeTool(
            'launchGame',
            {
              gameName: packet.target || packet.parameters.gameName,
              device: packet.device,
            },
            'router',
          );

        case 'launch_application': {
          const t = String(packet.target || '').trim();
          if (packet.device === 'windows') {
            if (t.toLowerCase().includes('youtube')) {
              return await toolManager.executeTool(
                'openPcUrl',
                { url: 'https://www.youtube.com' },
                'router',
              );
            }
            return await toolManager.executeTool('openPcApp', { appName: t }, 'router');
          }
          if (t.toLowerCase() === 'settings') {
            return await toolManager.executeTool('openSettings', { section: 'main' }, 'router');
          }
          if (t.toLowerCase() === 'wikipedia') {
            return await toolManager.executeTool(
              'openWebsite',
              { url: 'https://en.wikipedia.org', title: 'Wikipedia' },
              'router',
            );
          }
          return await toolManager.executeTool(
            'openApp',
            { packageOrName: t },
            'router',
          );
        }

        case 'youtube_search':
          return await toolManager.executeTool(
            'searchYouTube',
            { query: packet.query || '' },
            'router',
          );

        case 'youtube_play': {
          const q = packet.query || 'sci-fi ambient music';
          return await toolManager.executeTool('playYouTube', { query: q }, 'router');
        }

        case 'browser_search':
          return await toolManager.executeTool(
            'searchWeb',
            { query: packet.query || '', engine: 'google' },
            'router',
          );

        case 'screen_vision':
          return await toolManager.executeTool(
            'analyzeScreen',
            { prompt: packet.parameters.prompt || 'What is on my screen?' },
            'router',
          );

        case 'screen_share_control':
          return await toolManager.executeTool('startScreenShare', {}, 'router');

        case 'device_management':
          globalStateManager.setCommandCenterOpen(true);
          return await toolManager.executeTool('getConnectedDevices', {}, 'router');

        case 'file_operation':
          return await toolManager.executeTool(
            'manageFiles',
            { operation: packet.parameters.operation || 'list' },
            'router',
          );

        case 'volume_control':
          return await toolManager.executeTool(
            'controlPcVolume',
            { command: packet.target || 'up' },
            'router',
          );

        case 'media_control':
          if (packet.target === 'pause') {
            return await toolManager.executeTool('pauseMedia', {}, 'router');
          }
          return await toolManager.executeTool('resumeMedia', {}, 'router');

        case 'system_navigation':
          if (packet.target === 'back') {
            return await toolManager.executeTool('goBack', {}, 'router');
          }
          if (packet.target === 'home') {
            return await toolManager.executeTool('goHome', {}, 'router');
          }
          return await toolManager.executeTool('openRecents', {}, 'router');

        default:
          return { status: 'unsupported', validationStatus: 'NOT_SUPPORTED' };
      }
    } finally {
      const current = globalStateManager.getState().assistantState;
      if (current === 'executing') {
        globalStateManager.setAssistantState('disconnected');
      }
    }
  }
}
