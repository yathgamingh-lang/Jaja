export interface PcSystemTelemetry {
  hostname: string;
  platform: string;
  osRelease: string;
  cpuUsagePercent: number;
  memoryUsedGb: number;
  memoryTotalGb: number;
  memoryUsagePercent: number;
  uptimeHours: number;
  activeWindowTitle: string;
  autoStartEnabled: boolean;
  executionMode: 'companion_agent' | 'local_host_bridge';
}

export interface PcBridgeState {
  status: 'disconnected' | 'connecting' | 'connected' | 'error';
  connectionMode: 'server_relay' | 'direct_lan';
  directAgentUrl: string;
  pairingToken: string;
  latencyMs: number;
  telemetry: PcSystemTelemetry | null;
  lastCommandStatus: string | null;
  pendingDangerAction: {
    action: 'shutdown' | 'restart' | 'sleep';
    requestedAt: number;
  } | null;
}

type PcStateListener = (state: PcBridgeState) => void;

const STORAGE_KEY_PC_URL = 'n3k_pc_agent_url';
const STORAGE_KEY_PC_TOKEN = 'n3k_pc_pairing_token';
const STORAGE_KEY_PC_MODE = 'n3k_pc_connection_mode';

export class PcBridgeManager {
  private state: PcBridgeState = {
    status: 'disconnected',
    connectionMode: 'server_relay',
    directAgentUrl: 'http://localhost:47831',
    pairingToken: 'N3K-JARVIS-7749',
    latencyMs: 12,
    telemetry: null,
    lastCommandStatus: null,
    pendingDangerAction: null,
  };

  private listeners: Set<PcStateListener> = new Set();
  private pollTimer: any = null;

  constructor() {
    if (typeof window !== 'undefined') {
      const savedUrl = localStorage.getItem(STORAGE_KEY_PC_URL);
      const savedToken = localStorage.getItem(STORAGE_KEY_PC_TOKEN);
      const savedMode = localStorage.getItem(STORAGE_KEY_PC_MODE) as
        | 'server_relay'
        | 'direct_lan'
        | null;

      if (savedUrl) this.state.directAgentUrl = savedUrl;
      if (savedToken) this.state.pairingToken = savedToken;
      if (savedMode && ['server_relay', 'direct_lan'].includes(savedMode)) {
        this.state.connectionMode = savedMode;
      }

      // Probe PC bridge on startup
      setTimeout(() => {
        this.refreshStatus();
      }, 800);

      this.pollTimer = setInterval(() => {
        if (this.state.status === 'connected') {
          this.refreshStatus(true);
        }
      }, 10000);
    }
  }

  public getState(): PcBridgeState {
    return this.state;
  }

  public subscribe(listener: PcStateListener): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l({ ...this.state }));
  }

  public setConnectionConfig(
    mode: 'server_relay' | 'direct_lan',
    directAgentUrl: string,
    pairingToken: string,
  ) {
    this.state.connectionMode = mode;
    this.state.directAgentUrl = directAgentUrl.trim().replace(/\/+$/, '');
    this.state.pairingToken = pairingToken.trim() || 'N3K-JARVIS-7749';
    try {
      localStorage.setItem(STORAGE_KEY_PC_MODE, mode);
      localStorage.setItem(STORAGE_KEY_PC_URL, this.state.directAgentUrl);
      localStorage.setItem(STORAGE_KEY_PC_TOKEN, this.state.pairingToken);
    } catch {}
    this.notify();
    this.refreshStatus();
  }

  public async refreshStatus(silent = false): Promise<PcBridgeState> {
    if (!silent) {
      this.state.status = 'connecting';
      this.notify();
    }

    const t0 = performance.now();
    try {
      const endpoint =
        this.state.connectionMode === 'direct_lan'
          ? `${this.state.directAgentUrl}/status`
          : '/api/pc/status';

      const res = await fetch(endpoint, {
        method: 'GET',
        headers: {
          'x-n3k-token': this.state.pairingToken,
        },
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }

      const data = await res.json();
      const latency = Math.max(1, Math.round(performance.now() - t0));

      if (data && data.connected) {
        this.state.status = 'connected';
        this.state.latencyMs = latency;
        this.state.telemetry = data.telemetry || null;
      } else {
        this.state.status = 'disconnected';
        this.state.telemetry = data?.telemetry || null;
      }
    } catch (err: any) {
      this.state.status = 'disconnected';
      if (!silent) {
        this.state.lastCommandStatus = `PC Agent unreachable (${err?.message || 'offline'})`;
      }
    }

    this.notify();
    return this.state;
  }

  public async executePcCommand(
    action: string,
    params: Record<string, any> = {},
  ): Promise<{
    status: 'success' | 'confirmation_required' | 'pc_offline' | 'error';
    message: string;
    data?: any;
  }> {
    // Safety guard for destructive PC system power actions
    if (
      ['shutdown', 'restart', 'sleep'].includes(action) &&
      params.confirmed !== true
    ) {
      this.state.pendingDangerAction = {
        action: action as 'shutdown' | 'restart' | 'sleep',
        requestedAt: Date.now(),
      };
      this.state.lastCommandStatus = `Confirmation required for PC ${action.toUpperCase()}`;
      this.notify();
      return {
        status: 'confirmation_required',
        message: `SAFETY GUARD: PC ${action} requires explicit user confirmation. A confirmation prompt is now displayed on the N3k HUD, or the user can confirm verbally.`,
      };
    }

    this.state.pendingDangerAction = null;

    const endpoint =
      this.state.connectionMode === 'direct_lan'
        ? `${this.state.directAgentUrl}/command`
        : '/api/pc/command';

    try {
      const t0 = performance.now();
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-n3k-token': this.state.pairingToken,
        },
        body: JSON.stringify({
          action,
          params,
          token: this.state.pairingToken,
        }),
      });

      const data = await res.json();
      this.state.latencyMs = Math.max(1, Math.round(performance.now() - t0));

      if (data.telemetry) {
        this.state.telemetry = data.telemetry;
      }
      if (data.status === 'success') {
        this.state.status = 'connected';
      }

      this.state.lastCommandStatus = data.message || `Executed ${action}`;
      this.notify();
      return {
        status: data.status || 'success',
        message: data.message || `PC command ${action} completed.`,
        data,
      };
    } catch (err: any) {
      this.state.status = 'disconnected';
      const msg = `PC Companion Agent is offline or unreachable (${err?.message || 'connection failed'}). Run the N3k PC Agent on your Windows/PC desktop or connect on LAN.`;
      this.state.lastCommandStatus = msg;
      this.notify();
      return {
        status: 'pc_offline',
        message: msg,
      };
    }
  }

  public cancelPendingDangerAction() {
    this.state.pendingDangerAction = null;
    this.state.lastCommandStatus = 'Cancelled PC power action.';
    this.notify();
  }

  public async confirmPendingDangerAction() {
    if (!this.state.pendingDangerAction) return;
    const act = this.state.pendingDangerAction.action;
    this.state.pendingDangerAction = null;
    this.notify();
    return this.executePcCommand(act, { confirmed: true });
  }
}

export const globalPcBridgeManager = new PcBridgeManager();
