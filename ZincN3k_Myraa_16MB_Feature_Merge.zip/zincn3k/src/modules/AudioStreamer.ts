export class AudioStreamer {
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private isStreaming = false;
  private isMuted = false;

  private onAudioChunkCallback: ((base64Pcm: string) => void) | null = null;
  private onVolumeChangeCallback: ((volume: number) => void) | null = null;
  private currentVolume = 0;
  private animFrameId: number | null = null;

  constructor(
    private targetSampleRate = 16000,
    private bufferSize = 2048,
  ) {}

  public setOnAudioChunk(callback: (base64Pcm: string) => void) {
    this.onAudioChunkCallback = callback;
  }

  public setOnVolumeChange(callback: (volume: number) => void) {
    this.onVolumeChangeCallback = callback;
  }

  public getIsStreaming(): boolean {
    return this.isStreaming;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (this.mediaStream) {
      this.mediaStream.getAudioTracks().forEach((track) => {
        track.enabled = !muted;
      });
    }
  }

  public async start(deviceId?: string): Promise<string> {
    if (this.isStreaming) return '';

    try {
      const constraints: MediaStreamConstraints = {
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: this.targetSampleRate,
          ...(deviceId ? { deviceId: { exact: deviceId } } : {}),
        },
        video: false,
      };

      this.mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      const activeTrack = this.mediaStream.getAudioTracks()[0];
      const micLabel = activeTrack ? activeTrack.label : 'Microphone';

      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new AudioCtxClass({
        sampleRate: this.targetSampleRate,
      });

      if (this.audioContext.state === 'suspended') {
        await this.audioContext.resume();
      }

      const inputSampleRate = this.audioContext.sampleRate;
      this.sourceNode = this.audioContext.createMediaStreamSource(this.mediaStream);

      this.processorNode = this.audioContext.createScriptProcessor(this.bufferSize, 1, 1);

      this.processorNode.onaudioprocess = (e: AudioProcessingEvent) => {
        if (!this.isStreaming || this.isMuted) {
          this.currentVolume = 0;
          return;
        }

        const inputData = e.inputBuffer.getChannelData(0);

        let sum = 0;
        for (let i = 0; i < inputData.length; i++) {
          sum += inputData[i] * inputData[i];
        }
        const rms = Math.sqrt(sum / inputData.length);
        this.currentVolume = this.currentVolume * 0.7 + Math.min(1, rms * 5) * 0.3;

        const resampled = this.resampleAudio(inputData, inputSampleRate, this.targetSampleRate);

        const pcm16 = this.floatTo16BitPCM(resampled);
        const base64 = this.arrayBufferToBase64(pcm16.buffer);

        if (this.onAudioChunkCallback) {
          this.onAudioChunkCallback(base64);
        }
      };

      this.sourceNode.connect(this.processorNode);
      this.processorNode.connect(this.audioContext.destination);

      this.isStreaming = true;
      this.startVolumeLoop();

      return micLabel;
    } catch (err) {
      this.stop();
      throw err;
    }
  }

  public stop() {
    this.isStreaming = false;
    this.currentVolume = 0;

    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }

    if (this.processorNode) {
      this.processorNode.onaudioprocess = null;
      try {
        this.processorNode.disconnect();
      } catch {}
      this.processorNode = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {}
      this.sourceNode = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.audioContext) {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }
  }

  private startVolumeLoop() {
    const loop = () => {
      if (!this.isStreaming) return;
      if (this.onVolumeChangeCallback) {
        this.onVolumeChangeCallback(this.isMuted ? 0 : this.currentVolume);
      }
      this.animFrameId = requestAnimationFrame(loop);
    };
    this.animFrameId = requestAnimationFrame(loop);
  }

  private resampleAudio(
    input: Float32Array,
    inputRate: number,
    outputRate: number,
  ): Float32Array {
    if (inputRate === outputRate) {
      return input;
    }
    const ratio = inputRate / outputRate;
    const outputLength = Math.round(input.length / ratio);
    const output = new Float32Array(outputLength);

    for (let i = 0; i < outputLength; i++) {
      const position = i * ratio;
      const index = Math.floor(position);
      const frac = position - index;
      const p0 = input[index] || 0;
      const p1 = input[index + 1] !== undefined ? input[index + 1] : p0;
      output[i] = p0 + (p1 - p0) * frac;
    }
    return output;
  }

  private floatTo16BitPCM(input: Float32Array): Int16Array {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  private arrayBufferToBase64(buffer: ArrayBufferLike): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }
}
