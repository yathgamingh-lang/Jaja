import { globalStateManager } from './StateManager.ts';
import { globalAndroidBridge } from './AndroidBridge.ts';
import { globalPcBridgeManager } from './PcBridgeManager.ts';
import { globalWakeWordManager } from './WakeWordManager.ts';
import { globalScreenCaptureManager } from './ScreenShareManager.ts';

export type SubsystemHealthStatus =
  | 'WORKING'
  | 'PERMISSION REQUIRED'
  | 'ERROR'
  | 'UNAVAILABLE';

export interface SubsystemDiagnosticItem {
  id: string;
  name: string;
  status: SubsystemHealthStatus;
  whatItDoes: string;
  whatHappened?: string;
  why?: string;
  howToFix?: string;
}

type ErrorCenterListener = (items: SubsystemDiagnosticItem[]) => void;

export class ErrorCenterManager {
  private webglAvailable = true;
  private model3dLoaded = true;
  private animationsRunning = true;
  private micErrorDetail: string | null = null;
  private geminiErrorDetail: string | null = null;
  private listeners: Set<ErrorCenterListener> = new Set();

  constructor() {
    if (typeof window !== 'undefined') {
      try {
        const canvas = document.createElement('canvas');
        const gl =
          canvas.getContext('webgl2') ||
          canvas.getContext('webgl') ||
          canvas.getContext('experimental-webgl');
        this.webglAvailable = Boolean(gl);
      } catch {
        this.webglAvailable = false;
      }

      window.addEventListener('online', () => this.notify());
      window.addEventListener('offline', () => this.notify());
    }
  }

  public set3DStatus(webglOk: boolean, modelOk: boolean, animsOk: boolean) {
    this.webglAvailable = webglOk;
    this.model3dLoaded = modelOk;
    this.animationsRunning = animsOk;
    this.notify();
  }

  public reportMicError(err: string | null) {
    this.micErrorDetail = err;
    this.notify();
  }

  public reportGeminiError(err: string | null) {
    this.geminiErrorDetail = err;
    this.notify();
  }

  public subscribe(listener: ErrorCenterListener): () => void {
    this.listeners.add(listener);
    listener(this.getDiagnostics());
    return () => {
      this.listeners.delete(listener);
    };
  }

  public notify() {
    const items = this.getDiagnostics();
    this.listeners.forEach((l) => l(items));
  }

  public getDiagnostics(): SubsystemDiagnosticItem[] {
    const appState = globalStateManager.getState();
    const androidCaps = globalAndroidBridge.getCapabilities();
    const pcState = globalPcBridgeManager.getState();
    const wakeState = globalWakeWordManager.getState();
    const isOnlineNet = typeof navigator !== 'undefined' ? navigator.onLine : true;

    const micPerm = appState.systemPermissions.microphone;
    const micStatus: SubsystemHealthStatus = this.micErrorDetail
      ? 'ERROR'
      : micPerm === 'granted'
        ? 'WORKING'
        : micPerm === 'denied'
          ? 'PERMISSION REQUIRED'
          : 'PERMISSION REQUIRED';

    const geminiStatus: SubsystemHealthStatus =
      this.geminiErrorDetail || appState.errorMessage
        ? 'ERROR'
        : !isOnlineNet
          ? 'UNAVAILABLE'
          : 'WORKING';

    const screenCaptureActive = globalScreenCaptureManager.isActive();
    const hasDisplayMedia =
      typeof navigator !== 'undefined' &&
      Boolean(navigator.mediaDevices && 'getDisplayMedia' in navigator.mediaDevices);

    const screenCaptureStatus: SubsystemHealthStatus = appState.screenShareState.error
      ? 'ERROR'
      : screenCaptureActive
        ? 'WORKING'
        : hasDisplayMedia || androidCaps.isAndroidNative
          ? 'PERMISSION REQUIRED'
          : 'UNAVAILABLE';

    return [
      {
        id: 'microphone',
        name: 'Microphone',
        status: micStatus,
        whatItDoes: 'Captures 16kHz PCM voice input with echo cancellation and single-stream lock.',
        whatHappened:
          micStatus !== 'WORKING'
            ? this.micErrorDetail || 'Microphone permission has not been granted yet.'
            : undefined,
        why:
          micStatus !== 'WORKING'
            ? 'Browser or Android OS requires explicit user permission to access audio input.'
            : undefined,
        howToFix:
          micStatus !== 'WORKING'
            ? 'Click the Mic button or open Permissions Center and allow Microphone access.'
            : undefined,
      },
      {
        id: 'gemini',
        name: 'Gemini Live AI',
        status: geminiStatus,
        whatItDoes: 'Streams real-time bidirectional voice and tool calls with Gemini Live.',
        whatHappened:
          geminiStatus !== 'WORKING'
            ? this.geminiErrorDetail || appState.errorMessage || 'Network offline.'
            : undefined,
        why:
          geminiStatus !== 'WORKING'
            ? 'Temporary API rate limit, missing API key, or network disconnection.'
            : undefined,
        howToFix:
          geminiStatus !== 'WORKING'
            ? 'Click Retry to reconnect or check API key configuration on the server.'
            : undefined,
      },
      {
        id: 'audio_output',
        name: 'Audio Output & Viseme Analyser',
        status: 'WORKING',
        whatItDoes: 'Plays 24kHz Gemini voice audio and feeds frequency formants to 3D Lip Sync.',
      },
      {
        id: 'wake_word',
        name: 'Wake Word ("Hey N3k")',
        status: !wakeState.isSupported
          ? 'UNAVAILABLE'
          : wakeState.isEnabled
            ? 'WORKING'
            : 'PERMISSION REQUIRED',
        whatItDoes: 'Listens for configurable wake phrase ("Hey N3k" / "N3k") to activate voice.',
        whatHappened: !wakeState.isSupported
          ? 'Web Speech API is not supported in this browser.'
          : !wakeState.isEnabled
            ? 'Wake Word listening is currently toggled off.'
            : undefined,
        why: !wakeState.isSupported
          ? 'Browser engine lacks SpeechRecognition API.'
          : !wakeState.isEnabled
            ? 'Requires user activation in Command Center.'
            : undefined,
        howToFix: !wakeState.isSupported
          ? 'Use Chrome/Edge or the Android APK.'
          : 'Enable Wake Word in Command Center -> Wake Word.',
      },
      {
        id: 'screen_capture',
        name: 'Screen Capture',
        status: screenCaptureStatus,
        whatItDoes: 'Streams live display frames via getDisplayMedia or Android MediaProjection.',
        whatHappened: !screenCaptureActive ? 'Screen sharing is currently inactive.' : undefined,
        why: !screenCaptureActive
          ? 'Screen capture only runs when explicitly started by the user.'
          : undefined,
        howToFix: !screenCaptureActive
          ? 'Click "Start Screen Share" in Command Center or say "Share my screen".'
          : undefined,
      },
      {
        id: 'screen_vision',
        name: 'Screen Vision AI',
        status: screenCaptureActive ? 'WORKING' : 'PERMISSION REQUIRED',
        whatItDoes: 'Analyzes the current shared screen frame on-demand when asked.',
        whatHappened: !screenCaptureActive
          ? 'Waiting for active Screen Share stream.'
          : undefined,
        why: !screenCaptureActive
          ? 'Screen Vision requires an active screen share stream to capture a frame.'
          : undefined,
        howToFix: !screenCaptureActive
          ? 'Start Screen Share first, then ask "What is on my screen?".'
          : undefined,
      },
      {
        id: 'browser',
        name: 'Holographic Browser & YouTube',
        status: 'WORKING',
        whatItDoes: 'Navigates websites, runs web searches, and plays real YouTube videos.',
      },
      {
        id: 'android_bridge',
        name: 'Android Native Bridge',
        status: androidCaps.isAndroidNative
          ? androidCaps.accessibilityEnabled
            ? 'WORKING'
            : 'PERMISSION REQUIRED'
          : 'UNAVAILABLE',
        whatItDoes: 'Executes native Android PackageManager, Settings, and Accessibility actions.',
        whatHappened: !androidCaps.isAndroidNative
          ? 'Running in Web/Desktop environment instead of Android APK.'
          : !androidCaps.accessibilityEnabled
            ? 'Android AccessibilityService is not enabled yet.'
            : undefined,
        why: !androidCaps.isAndroidNative
          ? 'Native Android intents require the compiled /android APK.'
          : 'Android requires manual toggle in Accessibility Settings.',
        howToFix: !androidCaps.isAndroidNative
          ? 'Install the N3k Android app on your phone for native Android OS control.'
          : 'Open Accessibility Settings from Permissions Center and enable N3k.',
      },
      {
        id: 'windows_agent',
        name: 'Windows / PC Companion Agent',
        status: pcState.status === 'connected' ? 'WORKING' : 'UNAVAILABLE',
        whatItDoes: 'Controls Windows apps, files, keyboard/mouse, volume, and screenshots.',
        whatHappened:
          pcState.status !== 'connected' ? 'PC Companion Agent is not connected.' : undefined,
        why:
          pcState.status !== 'connected'
            ? 'The desktop companion script is offline or unreachable.'
            : undefined,
        howToFix:
          pcState.status !== 'connected'
            ? 'Click "Sync" or download and run n3k-pc-agent.mjs on your Windows PC.'
            : undefined,
      },
      {
        id: 'memory',
        name: 'N3k Brain Memory (IndexedDB)',
        status: 'WORKING',
        whatItDoes: `Stores and recalls persistent user facts across ${appState.memoryCount} records.`,
      },
      {
        id: 'model_3d',
        name: '3D Model (N3k Anime Male Rig)',
        status: this.model3dLoaded ? 'WORKING' : 'ERROR',
        whatItDoes: 'Renders the articulated 3D N3k character with head, eyes, jaw, hair & hoodie.',
      },
      {
        id: 'webgl',
        name: 'WebGL Graphics Pipeline',
        status: this.webglAvailable ? 'WORKING' : 'UNAVAILABLE',
        whatItDoes: 'Hardware-accelerated Three.js 3D rendering with adaptive mobile/desktop LOD.',
      },
      {
        id: 'animations',
        name: 'Layered 3D Animations & Lip Sync',
        status: this.animationsRunning ? 'WORKING' : 'ERROR',
        whatItDoes: 'Blends Idle, Breathing, Blink, Gaze, 27 Expressions, 17 Visemes & Gestures.',
      },
      {
        id: 'network',
        name: 'Network Connectivity',
        status: isOnlineNet ? 'WORKING' : 'ERROR',
        whatItDoes: 'Maintains low-latency WebSocket and REST communication.',
      },
      {
        id: 'permissions',
        name: 'System Permissions',
        status: micPerm === 'granted' ? 'WORKING' : 'PERMISSION REQUIRED',
        whatItDoes: 'Tracks real OS/Browser permission states for Mic, Camera, Screen & Notifications.',
      },
    ];
  }
}

export const globalErrorCenterManager = new ErrorCenterManager();
