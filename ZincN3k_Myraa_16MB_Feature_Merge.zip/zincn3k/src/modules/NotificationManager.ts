export interface N3kNotificationItem {
  id: string;
  title: string;
  body: string;
  category:
    | 'connection'
    | 'pc'
    | 'screen'
    | 'error'
    | 'permission'
    | 'game'
    | 'system';
  timestamp: number;
  read: boolean;
}

type NotificationListener = (items: N3kNotificationItem[]) => void;

export class NotificationManager {
  private notifications: N3kNotificationItem[] = [];
  private listeners: Set<NotificationListener> = new Set();

  constructor() {
    this.push(
      'N3k V4 Core Initialized',
      'Voice, Wake Word, Screen Vision, Game Hub & Cross-Device Bridge ready.',
      'system',
      false,
    );
  }

  public getNotifications(): N3kNotificationItem[] {
    return this.notifications;
  }

  public subscribe(listener: NotificationListener): () => void {
    this.listeners.add(listener);
    listener(this.notifications);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners() {
    const copy = [...this.notifications];
    this.listeners.forEach((l) => l(copy));
  }

  public push(
    title: string,
    body: string,
    category: N3kNotificationItem['category'] = 'system',
    triggerSystemNotification = true,
  ): N3kNotificationItem {
    const item: N3kNotificationItem = {
      id: `notif_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      title,
      body,
      category,
      timestamp: Date.now(),
      read: false,
    };

    this.notifications = [item, ...this.notifications].slice(0, 30);
    this.notifyListeners();

    if (
      triggerSystemNotification &&
      typeof window !== 'undefined' &&
      'Notification' in window &&
      Notification.permission === 'granted'
    ) {
      try {
        new Notification(`N3k — ${title}`, {
          body,
          silent: true,
        });
      } catch {}
    }

    return item;
  }

  public markAllRead() {
    this.notifications = this.notifications.map((n) => ({ ...n, read: true }));
    this.notifyListeners();
  }

  public clearAll() {
    this.notifications = [];
    this.notifyListeners();
  }
}

export const globalNotificationManager = new NotificationManager();
