import { YouTubeSearchResultItem } from '../types/assistant.ts';

export interface BrowserNavigationResolution {
  url: string;
  displayUrl: string;
  title: string;
  mode: 'web' | 'youtube';
  isFrameRestricted: boolean;
  blockReason?: string | null;
  youtubeQuery?: string;
  youtubeVideoId?: string;
}

export interface IBrowserProvider {
  readonly providerName: string;
  readonly isUnrestrictedNativeWebView: boolean;
  resolveTarget(input: string, preferredTitle?: string): BrowserNavigationResolution;
  searchYouTube(query: string): Promise<YouTubeSearchResultItem[]>;
  openExternal(url: string): void;
}

// Domains known to send X-Frame-Options: DENY or SAMEORIGIN on standard web pages
const FRAME_RESTRICTED_DOMAINS = [
  'github.com',
  'twitter.com',
  'x.com',
  'facebook.com',
  'instagram.com',
  'linkedin.com',
  'reddit.com',
  'netflix.com',
  'discord.com',
  'whatsapp.com',
  'amazon.com',
  ' stackoverflow.com',
];

export class WebBrowserProvider implements IBrowserProvider {
  public get providerName(): string {
    if (typeof window !== 'undefined' && (window as any).ZinxN3kAndroidBridge) {
      return 'AndroidWebViewBridge';
    }
    return 'HolographicWebSandbox';
  }

  public get isUnrestrictedNativeWebView(): boolean {
    return Boolean(typeof window !== 'undefined' && (window as any).ZinxN3kAndroidBridge);
  }

  public resolveTarget(input: string, preferredTitle?: string): BrowserNavigationResolution {
    const raw = String(input || '').trim();
    if (!raw) {
      return {
        url: 'https://www.google.com/webhp?igu=1',
        displayUrl: 'https://www.google.com',
        title: 'Google',
        mode: 'web',
        isFrameRestricted: false,
      };
    }

    // Check if input is a YouTube search shorthand
    if (/^(youtube|yt)\s+/i.test(raw)) {
      const ytQuery = raw.replace(/^(youtube|yt)\s+/i, '').trim();
      return {
        url: `https://www.youtube-nocookie.com/embed?listType=search&list=${encodeURIComponent(ytQuery)}&autoplay=1&enablejsapi=1`,
        displayUrl: `https://www.youtube.com/results?search_query=${encodeURIComponent(ytQuery)}`,
        title: preferredTitle || `YouTube: ${ytQuery}`,
        mode: 'youtube',
        isFrameRestricted: false,
        youtubeQuery: ytQuery,
      };
    }

    const isUrlOrDomain =
      /^https?:\/\//i.test(raw) ||
      /^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+(\/.*)?$/i.test(raw);

    if (!isUrlOrDomain) {
      // Treat as a web search query
      const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(raw)}&igu=1`;
      return {
        url: searchUrl,
        displayUrl: `https://www.google.com/search?q=${encodeURIComponent(raw)}`,
        title: preferredTitle || `Google: ${raw}`,
        mode: 'web',
        isFrameRestricted: false,
      };
    }

    const normalizedUrl = /^https?:\/\//i.test(raw) ? raw : `https://${raw}`;
    let parsed: URL;
    try {
      parsed = new URL(normalizedUrl);
    } catch {
      const fallbackSearch = `https://www.google.com/search?q=${encodeURIComponent(raw)}&igu=1`;
      return {
        url: fallbackSearch,
        displayUrl: fallbackSearch,
        title: preferredTitle || raw,
        mode: 'web',
        isFrameRestricted: false,
      };
    }

    const host = parsed.hostname.toLowerCase().replace(/^www\./, '');

    // Handle YouTube URLs specifically using official YouTube embed & real search
    if (host === 'youtube.com' || host === 'm.youtube.com' || host === 'youtu.be') {
      const videoIdParam =
        parsed.searchParams.get('v') ||
        (host === 'youtu.be' ? parsed.pathname.slice(1) : '');
      const searchQueryParam = parsed.searchParams.get('search_query');

      if (videoIdParam) {
        return {
          url: `https://www.youtube.com/embed/${videoIdParam}?autoplay=1&enablejsapi=1`,
          displayUrl: `https://www.youtube.com/watch?v=${videoIdParam}`,
          title: preferredTitle || 'YouTube Video',
          mode: 'youtube',
          isFrameRestricted: false,
          youtubeVideoId: videoIdParam,
        };
      }

      if (searchQueryParam) {
        return {
          url: `https://www.youtube-nocookie.com/embed?listType=search&list=${encodeURIComponent(searchQueryParam)}&autoplay=1&enablejsapi=1`,
          displayUrl: normalizedUrl,
          title: preferredTitle || `YouTube: ${searchQueryParam}`,
          mode: 'youtube',
          isFrameRestricted: false,
          youtubeQuery: searchQueryParam,
        };
      }

      if (parsed.pathname.startsWith('/embed')) {
        return {
          url: normalizedUrl,
          displayUrl: normalizedUrl,
          title: preferredTitle || 'YouTube',
          mode: 'youtube',
          isFrameRestricted: false,
        };
      }

      // Opening YouTube root ("Open YouTube")
      return {
        url: 'https://www.youtube-nocookie.com/embed?listType=search&list=trending+technology+music&enablejsapi=1',
        displayUrl: 'https://www.youtube.com',
        title: preferredTitle || 'YouTube',
        mode: 'youtube',
        isFrameRestricted: false,
        youtubeQuery: 'trending technology music',
      };
    }

    // Handle Google root or search URLs so they render inside the holographic browser
    if (host === 'google.com') {
      if (parsed.pathname === '/' || parsed.pathname === '') {
        return {
          url: 'https://www.google.com/webhp?igu=1',
          displayUrl: 'https://www.google.com',
          title: preferredTitle || 'Google',
          mode: 'web',
          isFrameRestricted: false,
        };
      }
      if (parsed.pathname.startsWith('/search') && !parsed.searchParams.has('igu')) {
        parsed.searchParams.set('igu', '1');
        return {
          url: parsed.toString(),
          displayUrl: normalizedUrl,
          title: preferredTitle || `Google Search`,
          mode: 'web',
          isFrameRestricted: false,
        };
      }
    }

    // Check if host is known to block iframe embedding (unless running inside native Android WebView)
    const isRestricted =
      !this.isUnrestrictedNativeWebView &&
      FRAME_RESTRICTED_DOMAINS.some((d) => host === d.trim() || host.endsWith(`.${d.trim()}`));

    return {
      url: normalizedUrl,
      displayUrl: normalizedUrl,
      title: preferredTitle || host,
      mode: 'web',
      isFrameRestricted: isRestricted,
      blockReason: isRestricted
        ? `${host} sends X-Frame-Options / Content-Security-Policy headers that block iframe embedding in standard web browsers.`
        : null,
    };
  }

  public async searchYouTube(query: string): Promise<YouTubeSearchResultItem[]> {
    try {
      const res = await fetch(`/api/youtube-search?q=${encodeURIComponent(query)}`);
      if (!res.ok) return [];
      const data = await res.json();
      return Array.isArray(data.results) ? data.results : [];
    } catch (err) {
      console.warn('[BrowserProvider] YouTube search fetch failed:', err);
      return [];
    }
  }

  public openExternal(url: string): void {
    if (!url) return;
    if (typeof window !== 'undefined') {
      const bridge = (window as any).ZinxN3kAndroidBridge;
      if (bridge && typeof bridge.openUrl === 'function') {
        bridge.openUrl(url);
        return;
      }
      const a = document.createElement('a');
      a.href = url;
      a.target = '_blank';
      a.rel = 'noopener noreferrer';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  }
}

export const globalBrowserProvider: IBrowserProvider = new WebBrowserProvider();
