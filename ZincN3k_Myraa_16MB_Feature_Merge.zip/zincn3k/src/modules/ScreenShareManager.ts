import { globalStateManager } from './StateManager.ts';
import { globalAndroidBridge } from './AndroidBridge.ts';

/**
 * ScreenCaptureManager
 * Manages real screen sharing across both:
 * 1) Android Native MediaProjection (`N3kMediaProjectionService` + `VirtualDisplay` + `ImageReader`)
 * 2) Browser `navigator.mediaDevices.getDisplayMedia()`
 *
 * Supports Start, Pause, Resume, Stop, and on-demand frame capture (`getCurrentFrame()`)
 * without recording or continuously streaming unnecessary video frames.
 */
export class ScreenCaptureManager {
  private stream: MediaStream | null = null;
  private videoElement: HTMLVideoElement | null = null;
  private canvasElement: HTMLCanvasElement | null = null;
  private paused = false;

  constructor() {
    if (typeof window !== 'undefined') {
      this.videoElement = document.createElement('video');
      this.videoElement.autoplay = true;
      this.videoElement.muted = true;
      this.videoElement.playsInline = true;
      this.canvasElement = document.createElement('canvas');
    }
  }

  public getVideoTrack(): MediaStreamTrack | null {
    if (!this.stream) return null;
    const tracks = this.stream.getVideoTracks();
    return tracks.length > 0 ? tracks[0] : null;
  }

  /**
   * Returns true ONLY when a real Android MediaProjection service OR a live Web MediaStreamTrack is active
   */
  public isActive(): boolean {
    if (globalAndroidBridge.isNativeAndroid()) {
      const caps = globalAndroidBridge.getCapabilities();
      return caps.mediaProjectionActive;
    }
    const track = this.getVideoTrack();
    return Boolean(this.stream && track && track.readyState === 'live');
  }

  public isPaused(): boolean {
    if (globalAndroidBridge.isNativeAndroid()) {
      return globalAndroidBridge.getCapabilities().mediaProjectionPaused;
    }
    return this.paused;
  }

  public getIsSharing(): boolean {
    return this.isActive();
  }

  public getStream(): MediaStream | null {
    return this.isActive() ? this.stream : null;
  }

  /**
   * Initiates real Android MediaProjection OR browser getDisplayMedia() permission picker
   */
  public async start(): Promise<{
    status: 'active' | 'requesting' | 'error';
    isSharing: boolean;
    message: string;
  }> {
    // 1. Native Android MediaProjection path
    if (globalAndroidBridge.isNativeAndroid()) {
      const caps = globalAndroidBridge.getCapabilities();
      if (caps.mediaProjectionActive) {
        this.paused = false;
        globalAndroidBridge.setScreenVisionPaused(false);
        globalStateManager.setScreenShareState('active', null, null);
        return {
          status: 'active',
          isSharing: true,
          message: 'Android MediaProjection Screen Vision is already active.',
        };
      }

      globalStateManager.setScreenShareState('requesting', null, null);
      const res = globalAndroidBridge.startScreenShare();
      if (res.status === 'requesting' || res.status === 'success') {
        return {
          status: 'requesting',
          isSharing: false,
          message:
            'Requested Android MediaProjection permission dialog. Approve the system prompt to start Screen Vision.',
        };
      } else {
        globalStateManager.setScreenShareState('error', null, res.message);
        return {
          status: 'error',
          isSharing: false,
          message: res.message || 'Failed to launch Android MediaProjection dialog.',
        };
      }
    }

    // 2. Web Browser getDisplayMedia() path
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getDisplayMedia) {
      const err = 'Screen sharing (getDisplayMedia / MediaProjection) is not supported in this environment.';
      globalStateManager.setScreenShareState('error', null, err);
      return { status: 'error', isSharing: false, message: err };
    }

    if (this.isActive() && this.stream) {
      this.paused = false;
      globalStateManager.setScreenPreviewMinimized(false);
      globalStateManager.setScreenShareState('active', this.stream, null);
      return {
        status: 'active',
        isSharing: true,
        message: 'Screen sharing is already active.',
      };
    }

    globalStateManager.setScreenShareState('requesting', null, null);

    try {
      let mediaStream: MediaStream;
      try {
        mediaStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
          audio: true,
        });
      } catch (firstErr: any) {
        if (
          firstErr?.name === 'NotAllowedError' ||
          firstErr?.name === 'AbortError' ||
          String(firstErr?.message || '').toLowerCase().includes('permission')
        ) {
          throw firstErr;
        }
        mediaStream = await navigator.mediaDevices.getDisplayMedia({
          video: true,
        });
      }

      const videoTrack = mediaStream.getVideoTracks()[0];
      if (!videoTrack || videoTrack.readyState !== 'live') {
        mediaStream.getTracks().forEach((t) => t.stop());
        const msg = 'No live video track was returned from screen share selection.';
        globalStateManager.setScreenShareState('error', null, msg);
        return { status: 'error', isSharing: false, message: msg };
      }

      this.stream = mediaStream;
      this.paused = false;

      videoTrack.onended = () => {
        this.handleEnded();
      };

      if (this.videoElement) {
        this.videoElement.srcObject = mediaStream;
        await this.videoElement.play().catch(() => {});
      }

      globalStateManager.setScreenPreviewMinimized(false);
      globalStateManager.setScreenShareState('active', mediaStream, null);

      return {
        status: 'active',
        isSharing: true,
        message:
          'Screen Vision is now ACTIVE. N3k can inspect your screen on demand whenever you ask.',
      };
    } catch (err: any) {
      console.warn('[ScreenCaptureManager] Screen share request failed or cancelled:', err);
      const isDenied = err?.name === 'NotAllowedError';
      const errMsg = isDenied
        ? 'Screen sharing permission was cancelled or denied.'
        : err?.message || 'Could not start screen sharing.';

      this.releaseResources();
      globalStateManager.setScreenShareState(isDenied ? 'idle' : 'error', null, errMsg);
      return {
        status: 'error',
        isSharing: false,
        message: errMsg,
      };
    }
  }

  public async startScreenShare() {
    return this.start();
  }

  public async startCapture() {
    return this.start();
  }

  public pause(): { status: 'paused' | 'error'; message: string } {
    if (!this.isActive()) {
      return { status: 'error', message: 'Screen sharing is not currently active.' };
    }
    this.paused = true;
    if (globalAndroidBridge.isNativeAndroid()) {
      globalAndroidBridge.setScreenVisionPaused(true);
    }
    globalStateManager.setScreenSharePaused(true);
    return { status: 'paused', message: 'Screen Vision paused. No frames will be captured while paused.' };
  }

  public resume(): { status: 'active' | 'error'; message: string } {
    if (!this.isActive()) {
      return { status: 'error', message: 'Screen sharing is not currently active.' };
    }
    this.paused = false;
    if (globalAndroidBridge.isNativeAndroid()) {
      globalAndroidBridge.setScreenVisionPaused(false);
    }
    globalStateManager.setScreenSharePaused(false);
    return { status: 'active', message: 'Screen Vision resumed.' };
  }

  public stop(): { status: 'stopped'; isSharing: boolean; message: string } {
    this.paused = false;
    if (globalAndroidBridge.isNativeAndroid()) {
      globalAndroidBridge.stopScreenShare();
    }
    this.releaseResources();
    globalStateManager.setScreenShareState('stopped', null, null);
    return {
      status: 'stopped',
      isSharing: false,
      message: 'Screen sharing stopped and all tracks released.',
    };
  }

  public stopScreenShare() {
    return this.stop();
  }

  public stopCapture() {
    return this.stop();
  }

  public handleEnded(): void {
    console.log('[ScreenCaptureManager] Native MediaStreamTrack ended');
    this.paused = false;
    this.releaseResources();
    globalStateManager.setScreenShareState('stopped', null, null);
  }

  private releaseResources(): void {
    if (this.stream) {
      this.stream.getTracks().forEach((track) => {
        try {
          track.onended = null;
          track.stop();
        } catch {}
      });
      this.stream = null;
    }
    if (this.videoElement) {
      try {
        this.videoElement.pause();
        this.videoElement.srcObject = null;
      } catch {}
    }
  }

  /**
   * Captures the current shared screen frame on demand (from Android MediaProjection ImageReader
   * or Web offscreen canvas), returns the base64 JPEG image, and immediately clears temporary buffers.
   */
  public getCurrentFrame(): string | null {
    if (!this.isActive() || this.isPaused()) {
      return null;
    }

    if (globalAndroidBridge.isNativeAndroid()) {
      const res = globalAndroidBridge.captureCurrentScreen();
      if (res.status === 'success' && res.imageBase64) {
        globalStateManager.updateScreenShareTimestamp();
        return String(res.imageBase64);
      }
      return null;
    }

    if (!this.videoElement || !this.canvasElement) {
      return null;
    }

    const video = this.videoElement;
    if (video.videoWidth === 0 || video.videoHeight === 0) {
      return null;
    }

    const canvas = this.canvasElement;
    const maxDim = 1280;
    let width = video.videoWidth;
    let height = video.videoHeight;

    if (width > maxDim || height > maxDim) {
      if (width > height) {
        height = Math.round((height * maxDim) / width);
        width = maxDim;
      } else {
        width = Math.round((width * maxDim) / height);
        height = maxDim;
      }
    }

    canvas.width = width;
    canvas.height = height;

    const ctx = canvas.getContext('2d');
    if (!ctx) return null;

    ctx.drawImage(video, 0, 0, width, height);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.8);

    // Immediately discard temporary pixel buffer on canvas for privacy
    ctx.clearRect(0, 0, width, height);
    canvas.width = 0;
    canvas.height = 0;

    globalStateManager.updateScreenShareTimestamp();

    const base64Data = dataUrl.split(',')[1] || null;
    return base64Data;
  }

  public captureCurrentFrame(): string | null {
    return this.getCurrentFrame();
  }
}

export { ScreenCaptureManager as ScreenShareManager, ScreenCaptureManager as ScreenVisionManager };
export const globalScreenCaptureManager = new ScreenCaptureManager();
export const globalScreenShareManager = globalScreenCaptureManager;
export const globalScreenVisionManager = globalScreenCaptureManager;
