import { globalAndroidBridge } from './AndroidBridge.ts';
import { globalPcBridgeManager } from './PcBridgeManager.ts';
import { globalNotificationManager } from './NotificationManager.ts';

export interface GameItem {
  id: string;
  name: string;
  platform: 'android' | 'windows' | 'cross_platform';
  launcher: 'android_apk' | 'steam' | 'epic' | 'xbox' | 'pc_standalone';
  packageOrCommand: string;
  genre: string;
  icon: string;
  isFavorite: boolean;
  lastPlayedAt: number | null;
  installed: boolean;
}

type GameListener = (games: GameItem[]) => void;

const STORAGE_KEY_GAMES_STATE = 'n3k_v4_games_state';

const DEFAULT_GAMES: GameItem[] = [
  {
    id: 'game_minecraft',
    name: 'Minecraft',
    platform: 'cross_platform',
    launcher: 'xbox',
    packageOrCommand: 'com.mojang.minecraftpe',
    genre: 'Sandbox / Survival',
    icon: '⛏️',
    isFavorite: true,
    lastPlayedAt: null,
    installed: true,
  },
  {
    id: 'game_steam_client',
    name: 'Steam Launcher',
    platform: 'windows',
    launcher: 'steam',
    packageOrCommand: 'steam://open/main',
    genre: 'PC Game Platform',
    icon: '🎮',
    isFavorite: true,
    lastPlayedAt: null,
    installed: true,
  },
  {
    id: 'game_epic_client',
    name: 'Epic Games Launcher',
    platform: 'windows',
    launcher: 'epic',
    packageOrCommand: 'com.epicgames.launcher://show',
    genre: 'PC Game Platform',
    icon: '🚀',
    isFavorite: false,
    lastPlayedAt: null,
    installed: true,
  },
  {
    id: 'game_gta5',
    name: 'Grand Theft Auto V',
    platform: 'windows',
    launcher: 'steam',
    packageOrCommand: 'steam://rungameid/271590',
    genre: 'Action / Open World',
    icon: '🏎️',
    isFavorite: true,
    lastPlayedAt: null,
    installed: true,
  },
  {
    id: 'game_cyberpunk',
    name: 'Cyberpunk 2077',
    platform: 'windows',
    launcher: 'steam',
    packageOrCommand: 'steam://rungameid/1091500',
    genre: 'Sci-Fi RPG',
    icon: '🦾',
    isFavorite: false,
    lastPlayedAt: null,
    installed: true,
  },
  {
    id: 'game_cs2',
    name: 'Counter-Strike 2',
    platform: 'windows',
    launcher: 'steam',
    packageOrCommand: 'steam://rungameid/730',
    genre: 'Tactical Shooter',
    icon: '🎯',
    isFavorite: false,
    lastPlayedAt: null,
    installed: true,
  },
  {
    id: 'game_bgmi_pubg',
    name: 'PUBG Mobile / BGMI',
    platform: 'android',
    launcher: 'android_apk',
    packageOrCommand: 'com.tencent.ig',
    genre: 'Battle Royale',
    icon: '🪂',
    isFavorite: true,
    lastPlayedAt: null,
    installed: false,
  },
  {
    id: 'game_genshin',
    name: 'Genshin Impact',
    platform: 'cross_platform',
    launcher: 'android_apk',
    packageOrCommand: 'com.miHoYo.GenshinImpact',
    genre: 'Action RPG',
    icon: '⚔️',
    isFavorite: false,
    lastPlayedAt: null,
    installed: false,
  },
  {
    id: 'game_roblox',
    name: 'Roblox',
    platform: 'cross_platform',
    launcher: 'android_apk',
    packageOrCommand: 'com.roblox.client',
    genre: 'Metaverse / Sandbox',
    icon: '🧱',
    isFavorite: false,
    lastPlayedAt: null,
    installed: true,
  },
];

export class GameManager {
  private games: GameItem[] = [...DEFAULT_GAMES];
  private listeners: Set<GameListener> = new Set();

  constructor() {
    this.loadSavedState();
    this.discoverNativeAndroidGames();
  }

  private loadSavedState() {
    if (typeof window === 'undefined') return;
    try {
      const raw = localStorage.getItem(STORAGE_KEY_GAMES_STATE);
      if (raw) {
        const savedMap: Record<string, { isFavorite: boolean; lastPlayedAt: number | null }> =
          JSON.parse(raw);
        this.games = this.games.map((g) =>
          savedMap[g.id]
            ? {
                ...g,
                isFavorite: savedMap[g.id].isFavorite,
                lastPlayedAt: savedMap[g.id].lastPlayedAt,
              }
            : g,
        );
      }
    } catch {}
  }

  private persistState() {
    if (typeof window === 'undefined') return;
    try {
      const map: Record<string, { isFavorite: boolean; lastPlayedAt: number | null }> = {};
      for (const g of this.games) {
        map[g.id] = { isFavorite: g.isFavorite, lastPlayedAt: g.lastPlayedAt };
      }
      localStorage.setItem(STORAGE_KEY_GAMES_STATE, JSON.stringify(map));
    } catch {}
  }

  public discoverNativeAndroidGames() {
    if (!globalAndroidBridge.isNativeAndroid()) return;
    const res = globalAndroidBridge.getInstalledGames();
    if (res.status === 'success' && Array.isArray(res.games)) {
      for (const nativeGame of res.games) {
        const pkg = String(nativeGame.packageName || '');
        const label = String(nativeGame.appName || pkg);
        if (!pkg) continue;
        const existing = this.games.find(
          (g) =>
            g.packageOrCommand.toLowerCase() === pkg.toLowerCase() ||
            g.name.toLowerCase() === label.toLowerCase(),
        );
        if (existing) {
          existing.installed = true;
          existing.packageOrCommand = pkg;
        } else {
          this.games.unshift({
            id: `android_${pkg}`,
            name: label,
            platform: 'android',
            launcher: 'android_apk',
            packageOrCommand: pkg,
            genre: 'Installed Android Game',
            icon: '🕹️',
            isFavorite: false,
            lastPlayedAt: null,
            installed: true,
          });
        }
      }
      this.notify();
    }
  }

  public getGames(): GameItem[] {
    return this.games;
  }

  public subscribe(listener: GameListener): () => void {
    this.listeners.add(listener);
    listener(this.games);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    const copy = [...this.games];
    this.listeners.forEach((l) => l(copy));
  }

  public toggleFavorite(gameId: string) {
    this.games = this.games.map((g) =>
      g.id === gameId ? { ...g, isFavorite: !g.isFavorite } : g,
    );
    this.persistState();
    this.notify();
  }

  public addCustomGame(
    name: string,
    platform: 'android' | 'windows',
    packageOrCommand: string,
  ): GameItem {
    const newGame: GameItem = {
      id: `custom_${Date.now()}`,
      name: name.trim(),
      platform,
      launcher: platform === 'android' ? 'android_apk' : 'pc_standalone',
      packageOrCommand: packageOrCommand.trim(),
      genre: 'Custom Title',
      icon: '🎮',
      isFavorite: true,
      lastPlayedAt: null,
      installed: true,
    };
    this.games = [newGame, ...this.games];
    this.persistState();
    this.notify();
    return newGame;
  }

  /**
   * Launches a game by name or ID on Android (via PackageManager) or Windows PC (via PC Companion Agent).
   * Returns real validation status: SUCCESS, FAILED, NOT_SUPPORTED, or PERMISSION_REQUIRED.
   */
  public async launchGame(
    nameOrId: string,
    targetDevice?: 'android' | 'windows' | 'auto',
  ): Promise<{
    validationStatus: 'SUCCESS' | 'FAILED' | 'NOT_SUPPORTED' | 'PERMISSION_REQUIRED';
    status: string;
    gameName: string;
    platformUsed: string;
    message: string;
  }> {
    const clean = nameOrId.trim().toLowerCase();
    const matched =
      this.games.find(
        (g) =>
          g.id.toLowerCase() === clean ||
          g.name.toLowerCase() === clean ||
          g.name.toLowerCase().includes(clean) ||
          clean.includes(g.name.toLowerCase()),
      ) || null;

    const gameName = matched ? matched.name : nameOrId.trim();
    const isAndroidRuntime = globalAndroidBridge.isNativeAndroid();
    const preferAndroid =
      targetDevice === 'android' ||
      (targetDevice !== 'windows' &&
        isAndroidRuntime &&
        matched?.platform !== 'windows');

    // 1. Android Launch Path
    if (preferAndroid && isAndroidRuntime) {
      const pkgOrName = matched ? matched.packageOrCommand : gameName;
      const res = globalAndroidBridge.openApp(pkgOrName);
      if (res.status === 'success') {
        if (matched) {
          matched.lastPlayedAt = Date.now();
          this.persistState();
          this.notify();
        }
        globalNotificationManager.push(
          'Game Launched',
          `Launched ${gameName} on Android.`,
          'game',
        );
        return {
          validationStatus: 'SUCCESS',
          status: 'success',
          gameName,
          platformUsed: 'android',
          message: `Launched ${gameName} on Android via PackageManager.`,
        };
      }
      return {
        validationStatus: 'FAILED',
        status: res.status,
        gameName,
        platformUsed: 'android',
        message: res.message || `Could not launch ${gameName} on Android.`,
      };
    }

    // 2. Windows PC Companion Launch Path
    const pcState = globalPcBridgeManager.getState();
    if (pcState.status === 'connected' || targetDevice === 'windows' || !isAndroidRuntime) {
      const cmdTarget = matched ? matched.packageOrCommand : gameName;
      const res = await globalPcBridgeManager.executePcCommand('launch_game', {
        gameName,
        command: cmdTarget,
        launcher: matched?.launcher || 'pc_standalone',
      });

      if (res.status === 'success') {
        if (matched) {
          matched.lastPlayedAt = Date.now();
          this.persistState();
          this.notify();
        }
        globalNotificationManager.push(
          'Game Launched on PC',
          `Dispatched ${gameName} launch on Windows PC.`,
          'game',
        );
        return {
          validationStatus: 'SUCCESS',
          status: 'success',
          gameName,
          platformUsed: 'windows',
          message: res.message || `Launched ${gameName} on Windows PC.`,
        };
      }

      return {
        validationStatus: 'FAILED',
        status: res.status,
        gameName,
        platformUsed: 'windows',
        message:
          res.message ||
          `Could not launch ${gameName} because the Windows PC Agent is offline.`,
      };
    }

    return {
      validationStatus: 'NOT_SUPPORTED',
      status: 'not_supported',
      gameName,
      platformUsed: 'none',
      message: `Launching "${gameName}" requires either the N3k Android APK or a connected Windows PC Companion Agent.`,
    };
  }
}

export const globalGameManager = new GameManager();
