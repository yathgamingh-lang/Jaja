import { AndroidPlatformCapabilities } from '../types/assistant.ts';

export interface NativeAndroidBridgeInterface {
  getPlatformCapabilities(): string;
  openApp(packageOrName: string): string;
  openUrl(url: string): string;
  searchYouTube(query: string): string;
  openSettings(section?: string | null): string;
  openAccessibilitySettings(): string;
  goBack(): string;
  goHome(): string;
  openRecents(): string;
  typeText(text: string): string;
  clickText(text: string): string;
  clickCoordinate(x: number, y: number): string;
  scroll(direction: string): string;
  getScreenInfo(): string;
  startScreenShare(): string;
  stopScreenShare(): string;
  setScreenVisionPaused(paused: boolean): string;
  captureCurrentScreen(): string;
  setWakeWordServiceEnabled?(enabled: boolean): string;
  setAutoStartOnBoot?(enabled: boolean): string;
  getInstalledGames?(): string;
  setFlashlight?(enabled: boolean): string;
  setBrightness?(levelPercent: number): string;
  setAlarm?(hour: number, minute: number, message: string): string;
  dialPhone?(phoneNumber: string): string;
  prepareMessage?(recipient: string, text: string, app: string): string;
  getRecentNotifications?(limit: number): string;
  openNotificationAccessSettings?(): string;
  requestContactsPermission?(): string;
}

declare global {
  interface Window {
    N3kAndroidBridge?: NativeAndroidBridgeInterface;
    ZinxN3kAndroidBridge?: NativeAndroidBridgeInterface;
  }
}

export interface AndroidToolResponse {
  status:
    | 'success'
    | 'not_installed'
    | 'requires_accessibility'
    | 'requires_android_apk'
    | 'requires_contacts_permission'
    | 'requires_notification_access'
    | 'not_found'
    | 'not_active'
    | 'requesting'
    | 'stopped'
    | 'error';
  message: string;
  [key: string]: any;
}

/**
 * AndroidBridge
 * Connects the N3k TypeScript AI runtime to the real Kotlin JavascriptInterface (`N3kNativeBridge.kt`).
 * When running inside the compiled Android app (`MainActivity.kt`), all methods invoke real
 * Android PackageManager, Intent, AccessibilityService, and MediaProjection APIs.
 * When running in a standard desktop/mobile browser tab, it accurately reports platform status
 * without faking OS-level execution.
 */
export class AndroidBridge {
  private getNative(): NativeAndroidBridgeInterface | null {
    if (typeof window === 'undefined') return null;
    return window.N3kAndroidBridge || window.ZinxN3kAndroidBridge || null;
  }

  public isNativeAndroid(): boolean {
    return this.getNative() !== null;
  }

  private safeParse(jsonStr: string | undefined | null): AndroidToolResponse {
    if (!jsonStr) {
      return { status: 'error', message: 'Empty response from Android bridge.' };
    }
    try {
      return JSON.parse(jsonStr);
    } catch {
      return { status: 'error', message: String(jsonStr) };
    }
  }

  public getCapabilities(): AndroidPlatformCapabilities {
    const native = this.getNative();
    if (!native) {
      return {
        isAndroidNative: false,
        accessibilityEnabled: false,
        mediaProjectionActive: false,
        mediaProjectionPaused: false,
        foregroundPackage: 'web.hud.session',
        micGranted: false,
        cameraGranted: false,
        notificationsGranted: false,
        notificationListenerEnabled: false,
        contactsGranted: false,
      };
    }

    try {
      const parsed = JSON.parse(native.getPlatformCapabilities());
      return {
        isAndroidNative: Boolean(parsed.isAndroidNative),
        accessibilityEnabled: Boolean(parsed.accessibilityEnabled),
        mediaProjectionActive: Boolean(parsed.mediaProjectionActive),
        mediaProjectionPaused: Boolean(parsed.mediaProjectionPaused),
        foregroundPackage: String(parsed.foregroundPackage || 'ai.n3k.assistant'),
        micGranted: Boolean(parsed.micGranted),
        cameraGranted: Boolean(parsed.cameraGranted),
        notificationsGranted: Boolean(parsed.notificationsGranted),
        notificationListenerEnabled: Boolean(parsed.notificationListenerEnabled),
        contactsGranted: Boolean(parsed.contactsGranted),
      };
    } catch {
      return {
        isAndroidNative: true,
        accessibilityEnabled: false,
        mediaProjectionActive: false,
        mediaProjectionPaused: false,
        foregroundPackage: 'ai.n3k.assistant',
        micGranted: false,
        cameraGranted: false,
        notificationsGranted: false,
        notificationListenerEnabled: false,
        contactsGranted: false,
      };
    }
  }

  /** Triggers the on-demand Android READ_CONTACTS permission dialog. */
  public requestContactsPermission(): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.requestContactsPermission) {
      return {
        status: 'requires_android_apk',
        message: 'Requesting Contacts permission can only be done from inside the N3k Android APK.',
      };
    }
    return this.safeParse(native.requestContactsPermission());
  }

  /** Reads real recently-posted Android system notifications (requires user-granted Notification access). */
  public getRecentNotifications(limit: number = 10): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.getRecentNotifications) {
      return {
        status: 'requires_android_apk',
        message: 'Reading system notifications requires the N3k Android APK with Notification access granted.',
      };
    }
    return this.safeParse(native.getRecentNotifications(limit));
  }

  /** Opens Settings > Notification access so the user can grant N3k the special permission. */
  public openNotificationAccessSettings(): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.openNotificationAccessSettings) {
      return {
        status: 'requires_android_apk',
        message: 'Notification access settings can only be opened from inside the N3k Android APK.',
      };
    }
    return this.safeParse(native.openNotificationAccessSettings());
  }

  public openApp(packageOrName: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        appName: packageOrName,
        message: `Native Android PackageManager is only available inside the N3k Android APK. In Web HUD mode, N3k can open web equivalents in the Holographic Browser.`,
      };
    }
    return this.safeParse(native.openApp(packageOrName));
  }

  public openUrl(url: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        url,
        message: 'Native Android Intent.ACTION_VIEW requires the Android APK.',
      };
    }
    return this.safeParse(native.openUrl(url));
  }

  public searchYouTube(query: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        query,
        message: 'Native YouTube app intent requires the Android APK.',
      };
    }
    return this.safeParse(native.searchYouTube(query));
  }

  public openSettings(section?: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        section: section || 'main',
        message:
          'Android OS Settings intents require the N3k Android app. Opening N3k HUD System Settings instead.',
      };
    }
    return this.safeParse(native.openSettings(section || null));
  }

  public openAccessibilitySettings(): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        message:
          'Android Accessibility Settings can only be launched when running inside the N3k Android APK (Settings.ACTION_ACCESSIBILITY_SETTINGS).',
      };
    }
    return this.safeParse(native.openAccessibilitySettings());
  }

  public goBack(): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        message:
          'Android GLOBAL_ACTION_BACK requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    }
    return this.safeParse(native.goBack());
  }

  public goHome(): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        message:
          'Android GLOBAL_ACTION_HOME requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    }
    return this.safeParse(native.goHome());
  }

  public openRecents(): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        message:
          'Android GLOBAL_ACTION_RECENTS requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    }
    return this.safeParse(native.openRecents());
  }

  public typeText(text: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        typedText: text,
        message:
          'Cross-app text entry (ACTION_SET_TEXT) requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    }
    return this.safeParse(native.typeText(text));
  }

  public clickText(text: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        targetText: text,
        message:
          'Clicking arbitrary Android UI nodes requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    }
    return this.safeParse(native.clickText(text));
  }

  public clickCoordinate(x: number, y: number): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        x,
        y,
        message:
          'Dispatching OS tap gestures requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    }
    return this.safeParse(native.clickCoordinate(x, y));
  }

  public scroll(direction: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        direction,
        message:
          'Scrolling Android views requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    }
    return this.safeParse(native.scroll(direction));
  }

  public getScreenInfo(): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        message:
          'Inspecting the Android AccessibilityNodeInfo tree requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    }
    return this.safeParse(native.getScreenInfo());
  }

  public startScreenShare(): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        message: 'Using browser getDisplayMedia() instead of Android MediaProjection.',
      };
    }
    return this.safeParse(native.startScreenShare());
  }

  public stopScreenShare(): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        message: 'Stopped web screen share.',
      };
    }
    return this.safeParse(native.stopScreenShare());
  }

  public setScreenVisionPaused(paused: boolean): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return { status: 'success', paused, message: `Screen vision ${paused ? 'paused' : 'resumed'}.` };
    }
    return this.safeParse(native.setScreenVisionPaused(paused));
  }

  public captureCurrentScreen(): AndroidToolResponse {
    const native = this.getNative();
    if (!native) {
      return {
        status: 'requires_android_apk',
        message: 'Using web canvas frame capture.',
      };
    }
    return this.safeParse(native.captureCurrentScreen());
  }

  public setWakeWordServiceEnabled(enabled: boolean): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.setWakeWordServiceEnabled) {
      return {
        status: 'success',
        enabled,
        message: `Web Wake Word detection ${enabled ? 'enabled' : 'disabled'}.`,
      };
    }
    return this.safeParse(native.setWakeWordServiceEnabled(enabled));
  }

  public setAutoStartOnBoot(enabled: boolean): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.setAutoStartOnBoot) {
      return {
        status: 'success',
        enabled,
        message: `Auto-Start preference saved (${enabled ? 'enabled' : 'disabled'}).`,
      };
    }
    return this.safeParse(native.setAutoStartOnBoot(enabled));
  }

  public getInstalledGames(): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.getInstalledGames) {
      return {
        status: 'requires_android_apk',
        games: [],
        message: 'Native Android game discovery requires running inside the N3k Android APK.',
      };
    }
    return this.safeParse(native.getInstalledGames());
  }

  public setFlashlight(enabled: boolean): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.setFlashlight) {
      return {
        status: 'requires_android_apk',
        enabled,
        message: 'Hardware camera torch control requires running inside the N3k Android APK.',
      };
    }
    return this.safeParse(native.setFlashlight(enabled));
  }

  public setBrightness(levelPercent: number): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.setBrightness) {
      return {
        status: 'requires_android_apk',
        level: levelPercent,
        message: 'Android OS screen brightness control requires running inside the N3k Android APK.',
      };
    }
    return this.safeParse(native.setBrightness(levelPercent));
  }

  public setAlarm(hour: number, minute: number, message: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.setAlarm) {
      return {
        status: 'requires_android_apk',
        hour,
        minute,
        message: 'Android AlarmClock intent requires running inside the N3k Android APK.',
      };
    }
    return this.safeParse(native.setAlarm(hour, minute, message));
  }

  public dialPhone(phoneNumber: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.dialPhone) {
      return {
        status: 'requires_android_apk',
        phoneNumber,
        message: 'Android Phone Dialer intent requires running inside the N3k Android APK.',
      };
    }
    return this.safeParse(native.dialPhone(phoneNumber));
  }

  public prepareMessage(recipient: string, text: string, app: string): AndroidToolResponse {
    const native = this.getNative();
    if (!native || !native.prepareMessage) {
      return {
        status: 'requires_android_apk',
        recipient,
        app,
        message: 'Native SMS/WhatsApp intent requires running inside the N3k Android APK.',
      };
    }
    return this.safeParse(native.prepareMessage(recipient, text, app));
  }
}

export const globalAndroidBridge = new AndroidBridge();
