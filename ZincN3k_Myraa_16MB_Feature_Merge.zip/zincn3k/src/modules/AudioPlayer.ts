export class AudioPlayer {
  private audioContext: AudioContext | null = null;
  private analyserNode: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  private nextStartTime = 0;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  private isPlaying = false;

  private onSpeakingStateChange: ((isSpeaking: boolean) => void) | null = null;
  private onLevelChange: ((level: number) => void) | null = null;
  private levelAnimFrameId: number | null = null;
  private endTimeoutId: any = null;

  constructor(private sampleRate = 24000) {}

  public setOnSpeakingStateChange(callback: (isSpeaking: boolean) => void) {
    this.onSpeakingStateChange = callback;
  }

  public setOnLevelChange(callback: (level: number) => void) {
    this.onLevelChange = callback;
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyserNode;
  }

  public async init() {
    if (!this.audioContext) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.audioContext = new AudioCtxClass({ sampleRate: this.sampleRate });

      this.gainNode = this.audioContext.createGain();
      this.gainNode.gain.value = 1.0;

      this.analyserNode = this.audioContext.createAnalyser();
      this.analyserNode.fftSize = 512;
      this.analyserNode.smoothingTimeConstant = 0.8;

      this.gainNode.connect(this.analyserNode);
      this.analyserNode.connect(this.audioContext.destination);

      this.startLevelLoop();
    }

    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }
  }

  public queuePcmChunk(base64Pcm: string) {
    if (!this.audioContext || !this.gainNode) {
      return;
    }

    try {
      const binaryString = window.atob(base64Pcm);
      const len = binaryString.length;
      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      const numSamples = Math.floor(bytes.length / 2);
      const floatSamples = new Float32Array(numSamples);
      const dataView = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);

      for (let i = 0; i < numSamples; i++) {
        const int16 = dataView.getInt16(i * 2, true);
        floatSamples[i] = int16 < 0 ? int16 / 0x8000 : int16 / 0x7fff;
      }

      const audioBuffer = this.audioContext.createBuffer(
        1,
        numSamples,
        this.sampleRate,
      );
      audioBuffer.copyToChannel(floatSamples, 0);

      const source = this.audioContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.gainNode);

      const currentTime = this.audioContext.currentTime;
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime;
      }

      const scheduledStart = this.nextStartTime;
      source.start(scheduledStart);
      this.nextStartTime += audioBuffer.duration;

      this.activeSources.add(source);

      if (!this.isPlaying) {
        this.isPlaying = true;
        if (this.onSpeakingStateChange) {
          this.onSpeakingStateChange(true);
        }
      }

      if (this.endTimeoutId) {
        clearTimeout(this.endTimeoutId);
      }
      const remainingMs = Math.max(0, (this.nextStartTime - currentTime) * 1000) + 120;
      this.endTimeoutId = setTimeout(() => {
        if (this.audioContext && this.audioContext.currentTime >= this.nextStartTime - 0.05) {
          this.isPlaying = false;
          if (this.onSpeakingStateChange) {
            this.onSpeakingStateChange(false);
          }
        }
      }, remainingMs);

      source.onended = () => {
        this.activeSources.delete(source);
        if (this.activeSources.size === 0) {
          if (this.isPlaying) {
            this.isPlaying = false;
            if (this.onSpeakingStateChange) {
              this.onSpeakingStateChange(false);
            }
          }
        }
      };
    } catch (err) {
      console.error('[AudioPlayer] Error processing PCM chunk:', err);
    }
  }

  /**
   * Immediately stops playback and clears all scheduled buffers upon interruption
   */
  public interrupt() {
    if (this.endTimeoutId) {
      clearTimeout(this.endTimeoutId);
      this.endTimeoutId = null;
    }

    this.activeSources.forEach((source) => {
      try {
        source.stop();
        source.disconnect();
      } catch {}
    });
    this.activeSources.clear();

    if (this.audioContext) {
      this.nextStartTime = this.audioContext.currentTime;
    } else {
      this.nextStartTime = 0;
    }

    if (this.isPlaying) {
      this.isPlaying = false;
      if (this.onSpeakingStateChange) {
        this.onSpeakingStateChange(false);
      }
    }

    if (this.onLevelChange) {
      this.onLevelChange(0);
    }
  }

  public stop() {
    this.interrupt();
    if (this.levelAnimFrameId !== null) {
      cancelAnimationFrame(this.levelAnimFrameId);
      this.levelAnimFrameId = null;
    }
    if (this.audioContext) {
      try {
        this.audioContext.close();
      } catch {}
      this.audioContext = null;
    }
    this.gainNode = null;
    this.analyserNode = null;
  }

  private startLevelLoop() {
    const dataArray = new Uint8Array(256);
    const checkLevel = () => {
      if (this.analyserNode && this.isPlaying) {
        this.analyserNode.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          sum += dataArray[i];
        }
        const avg = sum / dataArray.length;
        const normalized = Math.min(1, avg / 128);
        if (this.onLevelChange) {
          this.onLevelChange(normalized);
        }
      } else {
        if (this.onLevelChange) {
          this.onLevelChange(0);
        }
      }
      this.levelAnimFrameId = requestAnimationFrame(checkLevel);
    };
    this.levelAnimFrameId = requestAnimationFrame(checkLevel);
  }
}
