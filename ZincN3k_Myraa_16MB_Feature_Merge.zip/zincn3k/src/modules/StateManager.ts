import {
  ActiveTimer,
  AndroidPlatformCapabilities,
  AssistantState,
  AssistantTheme,
  AudioStats,
  BrowserTabState,
  ScreenShareState,
  ScreenShareStatus,
  SessionInfo,
  SupportedLanguage,
  SystemPermissions,
  ThemeConfig,
  ToolActionCard,
  VoicePersona,
  YouTubeSearchResultItem,
} from '../types/assistant.ts';
import { globalAndroidBridge } from './AndroidBridge.ts';

export const THEME_CONFIGS: Record<AssistantTheme, ThemeConfig> = {
  'cyber-cyan': {
    id: 'cyber-cyan',
    name: 'Cyber Cyan',
    primary: '#00e5ff',
    glow: 'rgba(0, 229, 255, 0.45)',
    secondary: '#0088ff',
    accent: '#38bdf8',
    bgGlow: 'radial-gradient(circle at 50% 50%, rgba(0, 229, 255, 0.18), transparent 70%)',
  },
  'electric-violet': {
    id: 'electric-violet',
    name: 'Electric Violet',
    primary: '#a855f7',
    glow: 'rgba(168, 85, 247, 0.45)',
    secondary: '#7c3aed',
    accent: '#c084fc',
    bgGlow: 'radial-gradient(circle at 50% 50%, rgba(168, 85, 247, 0.16), transparent 70%)',
  },
  'midnight-emerald': {
    id: 'midnight-emerald',
    name: 'Midnight Emerald',
    primary: '#10b981',
    glow: 'rgba(16, 185, 129, 0.45)',
    secondary: '#059669',
    accent: '#34d399',
    bgGlow: 'radial-gradient(circle at 50% 50%, rgba(16, 185, 129, 0.14), transparent 70%)',
  },
  'solar-amber': {
    id: 'solar-amber',
    name: 'Solar Amber',
    primary: '#f59e0b',
    glow: 'rgba(245, 158, 11, 0.45)',
    secondary: '#d97706',
    accent: '#fbbf24',
    bgGlow: 'radial-gradient(circle at 50% 50%, rgba(245, 158, 11, 0.14), transparent 70%)',
  },
  'crimson-pulse': {
    id: 'crimson-pulse',
    name: 'Crimson Pulse',
    primary: '#f43f5e',
    glow: 'rgba(244, 63, 94, 0.45)',
    secondary: '#e11d48',
    accent: '#fb7185',
    bgGlow: 'radial-gradient(circle at 50% 50%, rgba(244, 63, 94, 0.15), transparent 70%)',
  },
};

export interface AppState {
  assistantState: AssistantState;
  currentTheme: AssistantTheme;
  voicePersona: VoicePersona;
  audioStats: AudioStats;
  sessionInfo: SessionInfo;
  activeTimers: ActiveTimer[];
  actionCards: ToolActionCard[];
  errorMessage: string | null;
  selectedAudioInputId: string;
  memoryCount: number;
  isCommandCenterOpen: boolean;
  isGameHubOpen: boolean;
  isCameraVisionOpen: boolean;
  isHoloGirlVisible: boolean;
  isPermissionOnboardingOpen: boolean;
  systemPermissions: SystemPermissions;
  androidCapabilities: AndroidPlatformCapabilities;
  activeLanguage: SupportedLanguage;
  browserState: BrowserTabState;
  screenShareState: ScreenShareState;
}

export class StateManager {
  private state: AppState = {
    assistantState: 'disconnected',
    currentTheme: 'cyber-cyan',
    voicePersona: 'Fenrir', // Default adult male armored-AI voice
    audioStats: {
      userLevel: 0,
      assistantLevel: 0,
      isMuted: false,
      activeMicLabel: 'Default Mic',
    },
    sessionInfo: {
      startTime: null,
      durationSeconds: 0,
      latencyMs: 24,
      turnsCount: 0,
      model: 'gemini-3.8-live',
      voice: 'Fenrir',
    },
    activeTimers: [],
    actionCards: [],
    errorMessage: null,
    selectedAudioInputId: 'default',
    memoryCount: 0,
    isCommandCenterOpen: false,
    isGameHubOpen: false,
    isCameraVisionOpen: false,
    isHoloGirlVisible: true,
    isPermissionOnboardingOpen: false,
    systemPermissions: {
      microphone: 'prompt',
      camera: 'prompt',
      notifications: 'prompt',
      location: 'not_supported',
    },
    androidCapabilities: globalAndroidBridge.getCapabilities(),
    activeLanguage: 'English',
    browserState: {
      isOpen: false,
      url: 'https://www.google.com/webhp?igu=1',
      inputUrl: 'https://www.google.com',
      title: 'Google',
      isLoading: false,
      canGoBack: false,
      canGoForward: false,
      isIframeBlocked: false,
      blockReason: null,
      mode: 'web',
      youtubeResults: [],
      isPlaying: false,
      volume: 80,
    },
    screenShareState: {
      status: 'idle',
      isSharing: false,
      isPaused: false,
      isPreviewMinimized: false,
      stream: null,
      lastCapturedTimestamp: 0,
      error: null,
    },
  };

  private listeners: Set<(state: AppState) => void> = new Set();
  private durationTimerId: any = null;
  private countdownTimerId: any = null;

  constructor() {
    this.startTimersInterval();
    this.checkInitialPermissions();
    this.setupAndroidBridgeListeners();
  }

  private setupAndroidBridgeListeners() {
    if (typeof window === 'undefined') return;

    window.addEventListener('n3k:android:sync', () => {
      this.syncAndroidCapabilities();
    });

    window.addEventListener('n3k:mediaprojection:state', (e: any) => {
      const detail = e?.detail || {};
      const active = Boolean(detail.active);
      const err = detail.error || null;
      this.syncAndroidCapabilities();
      this.setScreenShareState(active ? 'active' : err ? 'error' : 'stopped', null, err);
    });
  }

  public syncAndroidCapabilities(): AndroidPlatformCapabilities {
    const caps = globalAndroidBridge.getCapabilities();
    this.state = {
      ...this.state,
      androidCapabilities: caps,
    };
    if (caps.isAndroidNative) {
      if (caps.micGranted) {
        this.state.systemPermissions.microphone = 'granted';
      }
      if (caps.cameraGranted) {
        this.state.systemPermissions.camera = 'granted';
      }
      if (caps.notificationsGranted) {
        this.state.systemPermissions.notifications = 'granted';
      }
      if (caps.mediaProjectionActive) {
        this.state.screenShareState.isSharing = true;
        this.state.screenShareState.isPaused = caps.mediaProjectionPaused;
        this.state.screenShareState.status = caps.mediaProjectionPaused ? 'paused' : 'active';
      }
    }
    this.notify();
    return caps;
  }

  public getState(): AppState {
    return this.state;
  }

  public subscribe(listener: (state: AppState) => void): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((listener) => listener(this.state));
  }

  public setAssistantState(newState: AssistantState) {
    if (this.state.assistantState === newState) return;

    this.state = {
      ...this.state,
      assistantState: newState,
    };

    if (newState === 'connecting' && !this.state.sessionInfo.startTime) {
      this.state.sessionInfo.startTime = Date.now();
      this.startDurationCounter();
    } else if (newState === 'disconnected') {
      this.stopDurationCounter();
      this.state.sessionInfo.startTime = null;
      this.state.sessionInfo.durationSeconds = 0;
      this.state.audioStats.userLevel = 0;
      this.state.audioStats.assistantLevel = 0;
    }

    this.notify();
  }

  public setTheme(theme: AssistantTheme) {
    this.state = {
      ...this.state,
      currentTheme: theme,
    };
    this.notify();
  }

  public setVoicePersona(voice: VoicePersona) {
    this.state = {
      ...this.state,
      voicePersona: voice,
      sessionInfo: {
        ...this.state.sessionInfo,
        voice,
      },
    };
    this.notify();
  }

  public setUserAudioLevel(level: number) {
    if (Math.abs(this.state.audioStats.userLevel - level) < 0.02) return;
    this.state = {
      ...this.state,
      audioStats: {
        ...this.state.audioStats,
        userLevel: level,
      },
    };
    this.notify();
  }

  public setAssistantAudioLevel(level: number) {
    if (Math.abs(this.state.audioStats.assistantLevel - level) < 0.02) return;
    this.state = {
      ...this.state,
      audioStats: {
        ...this.state.audioStats,
        assistantLevel: level,
      },
    };
    this.notify();
  }

  public setMuted(isMuted: boolean) {
    this.state = {
      ...this.state,
      audioStats: {
        ...this.state.audioStats,
        isMuted,
      },
    };
    this.notify();
  }

  public setMicLabel(label: string) {
    this.state = {
      ...this.state,
      audioStats: {
        ...this.state.audioStats,
        activeMicLabel: label,
      },
    };
    this.notify();
  }

  public setSelectedAudioInputId(deviceId: string) {
    this.state = {
      ...this.state,
      selectedAudioInputId: deviceId,
    };
    this.notify();
  }

  public setActiveLanguage(language: SupportedLanguage) {
    this.state = {
      ...this.state,
      activeLanguage: language,
    };
    this.notify();
  }

  public setLatency(latencyMs: number) {
    this.state = {
      ...this.state,
      sessionInfo: {
        ...this.state.sessionInfo,
        latencyMs,
      },
    };
    this.notify();
  }

  public incrementTurn() {
    this.state = {
      ...this.state,
      sessionInfo: {
        ...this.state.sessionInfo,
        turnsCount: this.state.sessionInfo.turnsCount + 1,
      },
    };
    this.notify();
  }

  public setMemoryCount(count: number) {
    if (this.state.memoryCount === count) return;
    this.state = {
      ...this.state,
      memoryCount: count,
    };
    this.notify();
  }

  public setCommandCenterOpen(isOpen: boolean) {
    if (isOpen) {
      this.syncAndroidCapabilities();
    }
    this.state = {
      ...this.state,
      isCommandCenterOpen: isOpen,
    };
    this.notify();
  }

  public setGameHubOpen(isOpen: boolean) {
    this.state = {
      ...this.state,
      isGameHubOpen: isOpen,
    };
    this.notify();
  }

  public setCameraVisionOpen(isOpen: boolean) {
    this.state = {
      ...this.state,
      isCameraVisionOpen: isOpen,
    };
    this.notify();
  }

  public setHoloGirlVisible(isVisible: boolean) {
    this.state = {
      ...this.state,
      isHoloGirlVisible: isVisible,
    };
    this.notify();
  }

  public setPermissionOnboardingOpen(isOpen: boolean) {
    if (isOpen) {
      this.syncAndroidCapabilities();
    }
    this.state = {
      ...this.state,
      isPermissionOnboardingOpen: isOpen,
    };
    this.notify();
  }

  public setLanguage(lang: SupportedLanguage) {
    this.state = {
      ...this.state,
      activeLanguage: lang,
    };
    this.notify();
  }

  public updatePermission(
    perm: keyof SystemPermissions,
    status: SystemPermissions[keyof SystemPermissions],
  ) {
    this.state = {
      ...this.state,
      systemPermissions: {
        ...this.state.systemPermissions,
        [perm]: status,
      },
    };
    this.notify();
  }

  public addActionCard(card: ToolActionCard) {
    const updated = [card, ...this.state.actionCards].slice(0, 6);
    this.state = {
      ...this.state,
      actionCards: updated,
    };
    this.notify();

    setTimeout(() => {
      this.removeActionCard(card.id);
    }, 12000);
  }

  public removeActionCard(id: string) {
    this.state = {
      ...this.state,
      actionCards: this.state.actionCards.filter((c) => c.id !== id),
    };
    this.notify();
  }

  public addTimer(timer: ActiveTimer) {
    this.state = {
      ...this.state,
      activeTimers: [...this.state.activeTimers, timer],
    };
    this.notify();
  }

  public removeTimer(id: string) {
    this.state = {
      ...this.state,
      activeTimers: this.state.activeTimers.filter((t) => t.id !== id),
    };
    this.notify();
  }

  public setErrorMessage(msg: string | null) {
    this.state = {
      ...this.state,
      errorMessage: msg,
    };
    this.notify();
  }

  private startDurationCounter() {
    if (this.durationTimerId) clearInterval(this.durationTimerId);
    this.durationTimerId = setInterval(() => {
      if (this.state.sessionInfo.startTime) {
        const sec = Math.floor((Date.now() - this.state.sessionInfo.startTime) / 1000);
        this.state = {
          ...this.state,
          sessionInfo: {
            ...this.state.sessionInfo,
            durationSeconds: sec,
          },
        };
        this.notify();
      }
    }, 1000);
  }

  private stopDurationCounter() {
    if (this.durationTimerId) {
      clearInterval(this.durationTimerId);
      this.durationTimerId = null;
    }
  }

  private startTimersInterval() {
    if (this.countdownTimerId) clearInterval(this.countdownTimerId);
    this.countdownTimerId = setInterval(() => {
      if (this.state.activeTimers.length === 0) return;
      let changed = false;
      const updated = this.state.activeTimers.map((timer) => {
        if (!timer.isPaused && timer.remainingSeconds > 0) {
          changed = true;
          const next = timer.remainingSeconds - 1;
          if (next === 0) {
            this.playChimeSound();
          }
          return { ...timer, remainingSeconds: next };
        }
        return timer;
      });
      if (changed) {
        this.state = {
          ...this.state,
          activeTimers: updated,
        };
        this.notify();
      }
    }, 1000);
  }

  // Browser State Management
  public setBrowserOpen(isOpen: boolean) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        isOpen,
      },
    };
    this.notify();
  }

  public setBrowserUrl(
    url: string,
    title?: string,
    mode: 'web' | 'youtube' = 'web',
    youtubeQuery?: string,
    youtubeVideoId?: string,
    displayUrl?: string,
    isIframeBlocked = false,
    blockReason: string | null = null,
  ) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        isOpen: true,
        url,
        inputUrl: displayUrl || url,
        title: title || this.state.browserState.title,
        mode,
        youtubeQuery,
        youtubeVideoId,
        isIframeBlocked,
        blockReason,
        isLoading: !isIframeBlocked,
      },
    };
    this.notify();
  }

  public setYouTubeResults(results: YouTubeSearchResultItem[]) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        youtubeResults: results,
      },
    };
    this.notify();
  }

  public setBrowserInputUrl(inputUrl: string) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        inputUrl,
      },
    };
    this.notify();
  }

  public setBrowserLoading(isLoading: boolean) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        isLoading,
      },
    };
    this.notify();
  }

  public setBrowserIframeBlocked(blocked: boolean, reason: string | null = null) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        isIframeBlocked: blocked,
        blockReason: reason,
        isLoading: false,
      },
    };
    this.notify();
  }

  public setBrowserMediaPlaying(isPlaying: boolean) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        isPlaying,
      },
    };
    this.notify();
  }

  public setBrowserVolume(volume: number) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        volume: Math.max(0, Math.min(100, volume)),
      },
    };
    this.notify();
  }

  public setBrowserNavState(canGoBack: boolean, canGoForward: boolean) {
    this.state = {
      ...this.state,
      browserState: {
        ...this.state.browserState,
        canGoBack,
        canGoForward,
      },
    };
    this.notify();
  }

  // Real Screen Share State Management (Supports both Android MediaProjection and Web getDisplayMedia)
  public setScreenShareState(
    status: ScreenShareStatus,
    stream: MediaStream | null = null,
    error: string | null = null,
  ) {
    const videoTrack = stream?.getVideoTracks()?.[0];
    const isWebTrackLive = Boolean(stream && videoTrack && videoTrack.readyState === 'live');
    const isAndroidProjectionLive =
      globalAndroidBridge.isNativeAndroid() &&
      globalAndroidBridge.getCapabilities().mediaProjectionActive;

    const isActuallyLive =
      (status === 'active' || status === 'paused') &&
      (isWebTrackLive || isAndroidProjectionLive);

    this.state = {
      ...this.state,
      screenShareState: {
        ...this.state.screenShareState,
        status: isActuallyLive ? status : status === 'active' ? 'stopped' : status,
        isSharing: isActuallyLive,
        isPaused: status === 'paused',
        isPreviewMinimized: isActuallyLive
          ? this.state.screenShareState.isPreviewMinimized
          : false,
        stream: isWebTrackLive ? stream : null,
        error,
      },
    };
    this.notify();
  }

  public setScreenSharing(
    isSharing: boolean,
    stream: MediaStream | null = null,
    error: string | null = null,
  ) {
    this.setScreenShareState(isSharing ? 'active' : error ? 'error' : 'stopped', stream, error);
  }

  public setScreenSharePaused(paused: boolean) {
    if (!this.state.screenShareState.isSharing) return;
    this.state = {
      ...this.state,
      screenShareState: {
        ...this.state.screenShareState,
        isPaused: paused,
        status: paused ? 'paused' : 'active',
      },
    };
    this.notify();
  }

  /**
   * Minimizes or restores ONLY the UI preview panel without stopping the MediaStream tracks!
   */
  public setScreenPreviewMinimized(minimized: boolean) {
    this.state = {
      ...this.state,
      screenShareState: {
        ...this.state.screenShareState,
        isPreviewMinimized: minimized,
      },
    };
    this.notify();
  }

  public updateScreenShareTimestamp() {
    this.state = {
      ...this.state,
      screenShareState: {
        ...this.state.screenShareState,
        lastCapturedTimestamp: Date.now(),
      },
    };
    this.notify();
  }

  public async checkInitialPermissions() {
    if (typeof window === 'undefined') return;

    this.syncAndroidCapabilities();

    if (navigator.permissions) {
      try {
        const micStatus = await navigator.permissions.query({
          name: 'microphone' as PermissionName,
        });
        this.updatePermission('microphone', micStatus.state as any);
        micStatus.onchange = () => this.updatePermission('microphone', micStatus.state as any);
      } catch {}

      try {
        const camStatus = await navigator.permissions.query({
          name: 'camera' as PermissionName,
        });
        this.updatePermission('camera', camStatus.state as any);
        camStatus.onchange = () => this.updatePermission('camera', camStatus.state as any);
      } catch {}
    }

    try {
      if ('Notification' in window) {
        const status =
          Notification.permission === 'default' ? 'prompt' : Notification.permission;
        this.updatePermission('notifications', status as any);
      }
    } catch {}

    const onboarded = localStorage.getItem('zinxn3k_permissions_onboarded');
    if (!onboarded) {
      this.setPermissionOnboardingOpen(true);
    }
  }

  private playChimeSound() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.setValueAtTime(880.0, ctx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.6);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.6);
    } catch {}
  }
}

export const globalStateManager = new StateManager();
