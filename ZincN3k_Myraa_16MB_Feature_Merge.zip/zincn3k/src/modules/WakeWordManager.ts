import { globalAndroidBridge } from './AndroidBridge.ts';

export interface WakeWordState {
  isEnabled: boolean;
  isListening: boolean;
  isSupported: boolean;
  autoStartEnabled: boolean;
  wakePhrases: string[];
  sensitivity: 'low' | 'medium' | 'high';
  lastDetectedAt: number | null;
  lastTranscript: string;
  statusMessage: string;
}

type WakeWordCallback = (commandAfterWakeWord: string, fullTranscript: string) => void;
type StateListener = (state: WakeWordState) => void;

const STORAGE_KEY_WAKEWORD_ENABLED = 'n3k_wakeword_enabled';
const STORAGE_KEY_AUTOSTART_ENABLED = 'n3k_autostart_enabled';
const STORAGE_KEY_SENSITIVITY = 'n3k_wakeword_sensitivity';

export class WakeWordManager {
  private recognition: any = null;
  private isRestarting = false;
  private pauseForLiveAudio = false;
  private onWakeDetectedCallback: WakeWordCallback | null = null;
  private listeners: Set<StateListener> = new Set();

  private state: WakeWordState = {
    isEnabled: false,
    isListening: false,
    isSupported: false,
    autoStartEnabled: false,
    wakePhrases: ['hey n3k', 'n3k', 'wake up n3k', 'hey neck', 'hey zinx', 'zinxn3k'],
    sensitivity: 'medium',
    lastDetectedAt: null,
    lastTranscript: '',
    statusMessage: 'Standby',
  };

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      const isNative = globalAndroidBridge.isNativeAndroid();
      this.state.isSupported = Boolean(SpeechRecognition) || isNative;

      const savedAutoStart = localStorage.getItem(STORAGE_KEY_AUTOSTART_ENABLED) === 'true';
      const savedWakeEnabled = localStorage.getItem(STORAGE_KEY_WAKEWORD_ENABLED) === 'true';
      const savedSens = localStorage.getItem(STORAGE_KEY_SENSITIVITY) as
        | 'low'
        | 'medium'
        | 'high'
        | null;

      this.state.autoStartEnabled = savedAutoStart;
      if (savedSens && ['low', 'medium', 'high'].includes(savedSens)) {
        this.state.sensitivity = savedSens;
      }

      if (savedWakeEnabled && this.state.isSupported) {
        setTimeout(() => {
          this.setEnabled(true);
        }, 1200);
      }

      // Listen for native Android wake word events if running inside Android APK
      window.addEventListener('n3k:wakeword:detected', (e: any) => {
        const transcript = String(e?.detail?.transcript || 'Hey N3k');
        const cmd = String(e?.detail?.command || '');
        this.triggerWakeWord(cmd, transcript);
      });
    }
  }

  public getState(): WakeWordState {
    return this.state;
  }

  public subscribe(listener: StateListener): () => void {
    this.listeners.add(listener);
    listener(this.state);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((l) => l({ ...this.state }));
  }

  public setOnWakeDetected(cb: WakeWordCallback) {
    this.onWakeDetectedCallback = cb;
  }

  public setAutoStart(enabled: boolean) {
    this.state.autoStartEnabled = enabled;
    try {
      localStorage.setItem(STORAGE_KEY_AUTOSTART_ENABLED, String(enabled));
    } catch {}
    if (globalAndroidBridge.isNativeAndroid()) {
      globalAndroidBridge.setAutoStartOnBoot(enabled);
    }
    this.state.statusMessage = enabled
      ? 'Auto-Start on Boot/Launch Enabled'
      : 'Auto-Start Disabled';
    this.notify();
  }

  public setSensitivity(sensitivity: 'low' | 'medium' | 'high') {
    this.state.sensitivity = sensitivity;
    try {
      localStorage.setItem(STORAGE_KEY_SENSITIVITY, sensitivity);
    } catch {}
    this.notify();
  }

  public setEnabled(enabled: boolean) {
    this.state.isEnabled = enabled;
    try {
      localStorage.setItem(STORAGE_KEY_WAKEWORD_ENABLED, String(enabled));
    } catch {}

    if (globalAndroidBridge.isNativeAndroid()) {
      globalAndroidBridge.setWakeWordServiceEnabled(enabled);
    }

    if (enabled) {
      this.startRecognition();
    } else {
      this.stopRecognition();
    }
    this.notify();
  }

  /**
   * When Gemini Live session is actively streaming the microphone, we can either
   * pause Web SpeechRecognition (to avoid mic conflict on mobile browsers) or resume when disconnected.
   */
  public setLiveSessionActive(active: boolean) {
    this.pauseForLiveAudio = active;
    if (active) {
      if (this.recognition && this.state.isListening) {
        try {
          this.recognition.stop();
        } catch {}
        this.state.isListening = false;
        this.state.statusMessage = 'Gemini Live Active (Voice Stream Engaged)';
        this.notify();
      }
    } else if (this.state.isEnabled) {
      setTimeout(() => {
        if (!this.pauseForLiveAudio && this.state.isEnabled) {
          this.startRecognition();
        }
      }, 600);
    }
  }

  private startRecognition() {
    if (typeof window === 'undefined') return;
    if (this.pauseForLiveAudio) {
      this.state.statusMessage = 'Gemini Live Voice Stream Active';
      this.notify();
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      if (globalAndroidBridge.isNativeAndroid()) {
        this.state.isListening = true;
        this.state.statusMessage = 'Android Foreground Wake Service Active';
        this.notify();
      } else {
        this.state.isSupported = false;
        this.state.isListening = false;
        this.state.statusMessage = 'Web Speech API not supported in this browser';
        this.notify();
      }
      return;
    }

    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {}
    }

    try {
      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';

      rec.onstart = () => {
        this.state.isListening = true;
        this.state.statusMessage = 'Listening for "Hey N3k"...';
        this.notify();
      };

      rec.onresult = (event: any) => {
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          const rawTranscript = String(result[0]?.transcript || '').trim();
          if (!rawTranscript) continue;

          const lower = rawTranscript.toLowerCase();
          this.state.lastTranscript = rawTranscript;

          const matchedWake = this.matchWakePhrase(lower);
          if (matchedWake) {
            // Wait for final result if user is still speaking a command, or trigger immediately if just wake phrase
            if (result.isFinal || lower === matchedWake.phrase) {
              const commandAfter = lower
                .slice(matchedWake.index + matchedWake.phrase.length)
                .replace(/^[,.\s:-]+/, '')
                .trim();

              this.triggerWakeWord(commandAfter, rawTranscript);
              break;
            }
          }
        }
      };

      rec.onerror = (event: any) => {
        const err = event?.error || 'unknown';
        if (err === 'not-allowed' || err === 'service-not-allowed') {
          this.state.isEnabled = false;
          this.state.isListening = false;
          this.state.statusMessage = 'Microphone permission required for Wake Word';
          this.notify();
          return;
        }
      };

      rec.onend = () => {
        this.state.isListening = false;
        this.notify();
        if (this.state.isEnabled && !this.pauseForLiveAudio && !this.isRestarting) {
          this.isRestarting = true;
          setTimeout(() => {
            this.isRestarting = false;
            if (this.state.isEnabled && !this.pauseForLiveAudio) {
              try {
                rec.start();
              } catch {}
            }
          }, 500);
        }
      };

      this.recognition = rec;
      rec.start();
    } catch (e: any) {
      this.state.isListening = false;
      this.state.statusMessage = e?.message || 'Wake Word engine ready';
      this.notify();
    }
  }

  private stopRecognition() {
    if (this.recognition) {
      try {
        this.recognition.onend = null;
        this.recognition.stop();
      } catch {}
      this.recognition = null;
    }
    this.state.isListening = false;
    this.state.statusMessage = 'Wake Word Disabled';
    this.notify();
  }

  private matchWakePhrase(lowerText: string): { phrase: string; index: number } | null {
    const phrases =
      this.state.sensitivity === 'high'
        ? [
            'hey n3k',
            'wake up n3k',
            'ok n3k',
            'n3k',
            'hey neck',
            'neck',
            'hey nick',
            'zinxn3k',
            'hey zinx',
          ]
        : this.state.sensitivity === 'low'
          ? ['hey n3k', 'wake up n3k']
          : ['hey n3k', 'wake up n3k', 'ok n3k', 'n3k', 'hey neck', 'zinxn3k'];

    for (const phrase of phrases) {
      const idx = lowerText.indexOf(phrase);
      if (idx !== -1) {
        return { phrase, index: idx };
      }
    }
    return null;
  }

  private triggerWakeWord(commandAfter: string, fullTranscript: string) {
    const now = Date.now();
    // Debounce within 2.2 seconds
    if (this.state.lastDetectedAt && now - this.state.lastDetectedAt < 2200) {
      return;
    }
    this.state.lastDetectedAt = now;
    this.state.statusMessage = commandAfter
      ? `Wake + Command: "${commandAfter}"`
      : 'Wake Word Detected ("Hey N3k")';
    this.playWakeChime();
    this.notify();

    if (this.onWakeDetectedCallback) {
      this.onWakeDetectedCallback(commandAfter, fullTranscript);
    }
  }

  private playWakeChime() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, ctx.currentTime); // C5
      osc.frequency.exponentialRampToValueAtTime(1046.5, ctx.currentTime + 0.18); // C6
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {}
  }
}

export const globalWakeWordManager = new WakeWordManager();
