import { ActiveTimer, AssistantTheme, ToolActionCard } from '../types/assistant.ts';
import { globalMemoryManager, MemoryManager } from '../memory/MemoryManager.ts';
import { globalStateManager } from './StateManager.ts';
import { registerMemoryTools } from '../tools/memoryTools.ts';
import { globalScreenCaptureManager } from './ScreenShareManager.ts';
import { globalBrowserProvider } from './BrowserProvider.ts';
import { globalAndroidBridge } from './AndroidBridge.ts';
import { globalPcBridgeManager } from './PcBridgeManager.ts';
import { globalWakeWordManager } from './WakeWordManager.ts';
import { globalGameManager } from './GameManager.ts';
import { globalDeviceManager } from './DeviceManager.ts';
import { globalNotificationManager } from './NotificationManager.ts';

export type ToolHandler = (args: Record<string, any>, callId: string) => Promise<any> | any;

export class ToolManager {
  private handlers: Map<string, ToolHandler> = new Map();
  private onActionCardCallback: ((card: ToolActionCard) => void) | null = null;
  private onThemeChangeCallback: ((theme: AssistantTheme) => void) | null = null;
  private onAddTimerCallback: ((timer: ActiveTimer) => void) | null = null;
  private onSendVideoFrameCallback: ((base64Jpeg: string) => void) | null = null;
  private memoryManager: MemoryManager;

  constructor(memoryManager?: MemoryManager) {
    this.memoryManager = memoryManager || globalMemoryManager;
    this.registerDefaultTools();
    this.registerMemorySystem();
  }

  public setOnActionCard(callback: (card: ToolActionCard) => void) {
    this.onActionCardCallback = callback;
  }

  public setOnThemeChange(callback: (theme: AssistantTheme) => void) {
    this.onThemeChangeCallback = callback;
  }

  public setOnAddTimer(callback: (timer: ActiveTimer) => void) {
    this.onAddTimerCallback = callback;
  }

  public setOnSendVideoFrame(callback: (base64Jpeg: string) => void) {
    this.onSendVideoFrameCallback = callback;
  }

  public registerTool(name: string, handler: ToolHandler) {
    this.handlers.set(name, handler);
  }

  public async executeTool(
    name: string,
    args: Record<string, any> = {},
    callId: string = 'local',
  ): Promise<any> {
    const handler = this.handlers.get(name);
    if (!handler) {
      console.warn(`[ToolManager] Unknown tool call: ${name}`);
      return { status: 'unsupported', message: `Tool ${name} is not implemented` };
    }

    try {
      const prevState = globalStateManager.getState().assistantState;
      if (prevState === 'thinking' || prevState === 'listening') {
        globalStateManager.setAssistantState('executing');
      }
      const res = await handler(args || {}, callId);
      if (globalStateManager.getState().assistantState === 'executing') {
        globalStateManager.setAssistantState(
          prevState === 'disconnected' ? 'disconnected' : 'listening',
        );
      }
      if (res && typeof res === 'object' && !res.validationStatus) {
        const s = String(res.status || 'success').toLowerCase();
        if (s === 'success' || s === 'active') {
          res.validationStatus = 'SUCCESS';
        } else if (
          s.includes('permission') ||
          s === 'requires_accessibility' ||
          s === 'confirmation_required'
        ) {
          res.validationStatus = 'PERMISSION_REQUIRED';
        } else if (
          s === 'requires_android_apk' ||
          s === 'unsupported' ||
          s === 'not_supported'
        ) {
          res.validationStatus = 'NOT_SUPPORTED';
        } else {
          res.validationStatus = 'FAILED';
        }
      }
      return res;
    } catch (err: any) {
      console.error(`[ToolManager] Error executing tool ${name}:`, err);
      globalNotificationManager.push(
        `Command Failed: ${name}`,
        err?.message || 'Execution failed',
        'error',
      );
      return {
        status: 'error',
        validationStatus: 'FAILED',
        message: err?.message || 'Execution failed',
      };
    }
  }

  private emitActionCard(
    type: ToolActionCard['type'],
    title: string,
    content: string,
    tag = 'SYSTEM',
    url?: string,
  ) {
    const card: ToolActionCard = {
      id: `card_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      type,
      title,
      content,
      url,
      timestamp: Date.now(),
      tag,
    };
    if (this.onActionCardCallback) {
      this.onActionCardCallback(card);
    }
  }

  private registerMemorySystem() {
    registerMemoryTools((name, handler) => {
      this.registerTool(name, async (args, callId) => {
        const result = await handler(args, callId);

        if (name === 'saveMemory' && result.status === 'success') {
          this.emitActionCard(
            'info',
            `Memory Saved: ${result.key}`,
            `"${result.value}" stored in ${result.category}.`,
            'BRAIN',
          );
        } else if (name === 'updateMemory' && result.status === 'success') {
          this.emitActionCard(
            'info',
            `Memory Updated: ${result.key}`,
            `Now remembered as "${result.value}".`,
            'BRAIN',
          );
        } else if (name === 'deleteMemory' && result.status === 'success') {
          this.emitActionCard('info', 'Memory Forgotten', 'Removed memory record.', 'BRAIN');
        } else if (name === 'clearAllMemories' && result.status === 'success') {
          this.emitActionCard(
            'info',
            'N3k Brain Cleared',
            'All stored memories have been deleted.',
            'BRAIN',
          );
        }

        return result;
      });
    }, this.memoryManager);
  }

  private registerDefaultTools() {
    // =========================================================================
    // 1. ANDROID APP LAUNCHER (`openApp`) + WEB HUD FALLBACK
    // =========================================================================
    this.registerTool('openApp', async (args) => {
      const rawName = String(args.packageOrName || args.appName || args.app || '').trim();
      if (!rawName) {
        return { status: 'error', message: 'App name or package name is required.' };
      }

      // If running inside the real Android APK, execute native PackageManager launch
      if (globalAndroidBridge.isNativeAndroid()) {
        const res = globalAndroidBridge.openApp(rawName);
        this.emitActionCard(
          'android',
          res.status === 'success' ? `Launched ${rawName}` : `App Launch: ${rawName}`,
          res.message,
          'ANDROID',
        );
        return res;
      }

      // In Web HUD mode, check if there is a real web equivalent we can open immediately
      const lower = rawName.toLowerCase();
      if (lower.includes('youtube')) {
        const webRes = await this.executeTool('openWebsite', {
          url: 'https://www.youtube.com',
          title: 'YouTube',
        });
        return {
          ...webRes,
          platform: 'web_hud',
          message:
            'Opened YouTube in the N3k Holographic Browser (running in Web HUD mode; install the N3k Android APK for native PackageManager app launching).',
        };
      }
      if (lower.includes('chrome') || lower.includes('browser') || lower.includes('google')) {
        const webRes = await this.executeTool('openWebsite', {
          url: 'https://www.google.com/webhp?igu=1',
          title: 'Google Chrome / Web',
        });
        return {
          ...webRes,
          platform: 'web_hud',
          message: 'Opened Google in the N3k Holographic Browser.',
        };
      }
      if (lower.includes('settings') || lower.includes('setting')) {
        globalStateManager.setPermissionOnboardingOpen(true);
        this.emitActionCard(
          'android',
          'N3k System Settings',
          'Opened N3k System & Permissions Configuration.',
          'SETTINGS',
        );
        return {
          status: 'success',
          platform: 'web_hud',
          message: 'Opened N3k System & Permissions Settings panel.',
        };
      }
      if (lower.includes('calculator') || lower.includes('calc')) {
        this.emitActionCard(
          'math',
          'N3k Calculator Ready',
          'Say any math expression or calculation and N3k will compute it immediately.',
          'MATH',
        );
        return {
          status: 'requires_android_apk',
          appName: rawName,
          message:
            'Native Android Calculator app launch requires the N3k Android APK. In Web HUD mode, ask me any math calculation directly.',
        };
      }
      if (lower.includes('notes') || lower.includes('keep')) {
        this.emitActionCard(
          'android',
          'Notes / Memory Storage',
          'Native Notes app requires the Android APK. You can store notes directly in N3k Brain memory.',
          'ANDROID',
        );
        return {
          status: 'requires_android_apk',
          appName: rawName,
          message:
            'Launching the native Android Notes/Keep app requires the N3k Android APK. However, I can save any note directly into N3k Brain persistent memory right now.',
        };
      }

      this.emitActionCard(
        'android',
        `Android App: ${rawName}`,
        `Native PackageManager launch for "${rawName}" requires the N3k Android APK.`,
        'ANDROID',
      );
      return {
        status: 'requires_android_apk',
        appName: rawName,
        message: `Launching the native Android app "${rawName}" requires running inside the N3k Android APK.`,
      };
    });

    // =========================================================================
    // 2. ANDROID SYSTEM NAVIGATION & ACCESSIBILITY CONTROL TOOLS
    // =========================================================================
    this.registerTool('goBack', () => {
      if (globalAndroidBridge.isNativeAndroid()) {
        const res = globalAndroidBridge.goBack();
        this.emitActionCard('android', 'Android Global Back', res.message, 'ANDROID');
        return res;
      }
      // If Holographic Browser is open in Web HUD, navigate back in browser history
      const state = globalStateManager.getState();
      if (state.browserState.isOpen) {
        window.dispatchEvent(new CustomEvent('zinxn3k:browser:back'));
        return {
          status: 'success',
          message: 'Navigated back in the Holographic Browser.',
        };
      }
      return {
        status: 'requires_accessibility',
        message:
          'Android OS global Back action requires the N3k Android APK with N3kAccessibilityService enabled.',
      };
    });

    this.registerTool('goHome', () => {
      if (globalAndroidBridge.isNativeAndroid()) {
        const res = globalAndroidBridge.goHome();
        this.emitActionCard('android', 'Android Global Home', res.message, 'ANDROID');
        return res;
      }
      // Close overlays in Web HUD to return to home HUD
      globalStateManager.setBrowserOpen(false);
      globalStateManager.setCommandCenterOpen(false);
      globalStateManager.setCameraVisionOpen(false);
      this.emitActionCard(
        'android',
        'Returned to N3k Home HUD',
        'Closed active overlays. Note: Android OS Home screen navigation requires the N3k Android APK with AccessibilityService enabled.',
        'ANDROID',
      );
      return {
        status: 'success',
        platform: 'web_hud',
        message:
          'Returned to the N3k Home HUD screen. (Note: OS-level Android Home screen action requires the N3k Android APK with AccessibilityService enabled.)',
      };
    });

    this.registerTool('openRecents', () => {
      const res = globalAndroidBridge.openRecents();
      this.emitActionCard('android', 'Android Recent Apps', res.message, 'ANDROID');
      return res;
    });

    this.registerTool('openSettings', (args) => {
      const section = args.section ? String(args.section) : undefined;
      if (globalAndroidBridge.isNativeAndroid()) {
        const res = globalAndroidBridge.openSettings(section);
        this.emitActionCard(
          'android',
          `Android Settings (${section || 'Main'})`,
          res.message,
          'ANDROID',
        );
        return res;
      }
      globalStateManager.setPermissionOnboardingOpen(true);
      this.emitActionCard(
        'android',
        'N3k System Settings & Permissions',
        'Opened N3k System Initialization & Android Accessibility configuration.',
        'SETTINGS',
      );
      return {
        status: 'success',
        platform: 'web_hud',
        message:
          'Opened N3k System Settings & Permissions panel. (Native Android OS Settings intents run when inside the N3k Android APK.)',
      };
    });

    this.registerTool('typeText', async (args) => {
      const text = String(args.text || '').trim();
      const appName = args.appName ? String(args.appName).trim() : '';
      if (!text) {
        return { status: 'error', message: 'Text to type is required.' };
      }

      if (globalAndroidBridge.isNativeAndroid()) {
        if (appName) {
          globalAndroidBridge.openApp(appName);
          // Give Android activity a brief moment to focus if launching an app first
          await new Promise((r) => setTimeout(r, 900));
        }
        const res = globalAndroidBridge.typeText(text);
        this.emitActionCard(
          'android',
          res.status === 'success' ? 'Typed Text into App' : 'Text Entry Status',
          res.message,
          'ACCESSIBILITY',
        );
        return res;
      }

      // In Web HUD mode, copy to clipboard as an honest fallback and explain Accessibility requirement
      let copied = false;
      try {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(text);
          copied = true;
        }
      } catch {}

      const msg = copied
        ? `Cross-app text typing (ACTION_SET_TEXT) requires the N3k Android APK with N3kAccessibilityService enabled. I copied "${text}" to your clipboard so you can paste it.`
        : `Cross-app text typing (ACTION_SET_TEXT) requires the N3k Android APK with N3kAccessibilityService enabled.`;

      this.emitActionCard('android', 'Text Automation', msg, 'ACCESSIBILITY');
      return {
        status: 'requires_accessibility',
        typedText: text,
        copiedToClipboard: copied,
        message: msg,
      };
    });

    this.registerTool('clickText', (args) => {
      const text = String(args.text || args.label || '').trim();
      if (!text) {
        return { status: 'error', message: 'Target text label is required.' };
      }
      const res = globalAndroidBridge.clickText(text);
      this.emitActionCard('android', `Click Element: "${text}"`, res.message, 'ACCESSIBILITY');
      return res;
    });

    this.registerTool('clickCoordinate', (args) => {
      const x = Number(args.x || 0);
      const y = Number(args.y || 0);
      const res = globalAndroidBridge.clickCoordinate(x, y);
      this.emitActionCard('android', `Tap (${x}, ${y})`, res.message, 'ACCESSIBILITY');
      return res;
    });

    this.registerTool('scroll', (args) => {
      const direction = String(args.direction || 'down').toLowerCase();
      const res = globalAndroidBridge.scroll(direction);
      this.emitActionCard('android', `Scroll ${direction.toUpperCase()}`, res.message, 'ACCESSIBILITY');
      return res;
    });

    this.registerTool('getScreenInfo', () => {
      const res = globalAndroidBridge.getScreenInfo();
      if (res.status === 'success') {
        this.emitActionCard(
          'android',
          `UI Tree Inspected (${res.packageName || 'Active Window'})`,
          `Found ${(res.visibleTexts || []).length} text nodes and ${(res.clickableElements || []).length} clickable elements.`,
          'ACCESSIBILITY',
        );
      } else {
        this.emitActionCard('android', 'UI Tree Inspection', res.message, 'ACCESSIBILITY');
      }
      return res;
    });

    // =========================================================================
    // 3. HOLOGRAPHIC BROWSER & YOUTUBE TOOLS
    // =========================================================================
    const handleOpenWebsite = async (args: Record<string, any>) => {
      const rawUrl = String(args.url || '').trim();
      const resolved = globalBrowserProvider.resolveTarget(rawUrl, args.title);

      globalStateManager.setBrowserUrl(
        resolved.url,
        resolved.title,
        resolved.mode,
        resolved.youtubeQuery,
        resolved.youtubeVideoId,
        resolved.displayUrl,
        resolved.isFrameRestricted,
        resolved.blockReason || null,
      );

      if (resolved.mode === 'youtube' && resolved.youtubeQuery) {
        const ytResults = await globalBrowserProvider.searchYouTube(resolved.youtubeQuery);
        globalStateManager.setYouTubeResults(ytResults);
        if (ytResults.length > 0 && !resolved.youtubeVideoId) {
          const firstVid = ytResults[0];
          globalStateManager.setBrowserUrl(
            `https://www.youtube.com/embed/${firstVid.videoId}?enablejsapi=1`,
            `YouTube: ${firstVid.title}`,
            'youtube',
            resolved.youtubeQuery,
            firstVid.videoId,
            `https://www.youtube.com/watch?v=${firstVid.videoId}`,
            false,
            null,
          );
          globalStateManager.setYouTubeResults(ytResults);
        }
      }

      this.emitActionCard(
        'website',
        resolved.title,
        resolved.isFrameRestricted
          ? `Opened ${resolved.title} in Holographic Browser (external launch ready due to CSP/X-Frame-Options).`
          : `Opened ${resolved.title} in Holographic Browser.`,
        'BROWSER',
        resolved.displayUrl,
      );

      return {
        status: 'success',
        url: resolved.displayUrl,
        title: resolved.title,
        mode: resolved.mode,
        isFrameRestricted: resolved.isFrameRestricted,
        message: resolved.isFrameRestricted
          ? `Opened ${resolved.title} panel. Note: ${resolved.title} restricts iframe embedding via X-Frame-Options, so a direct external launch button is displayed.`
          : `Opened ${resolved.title} in the holographic browser window.`,
      };
    };

    this.registerTool('openWebsite', handleOpenWebsite);
    this.registerTool('openUrl', handleOpenWebsite);

    this.registerTool('searchWeb', (args) => {
      const query = String(args.query || '').trim();
      const engine = String(args.engine || 'google').toLowerCase();
      const searchUrl =
        engine === 'duckduckgo'
          ? `https://duckduckgo.com/?q=${encodeURIComponent(query)}&ia=web`
          : `https://www.google.com/search?q=${encodeURIComponent(query)}&igu=1`;
      const displayUrl =
        engine === 'duckduckgo'
          ? `https://duckduckgo.com/?q=${encodeURIComponent(query)}`
          : `https://www.google.com/search?q=${encodeURIComponent(query)}`;

      globalStateManager.setBrowserUrl(
        searchUrl,
        `Search: ${query}`,
        'web',
        undefined,
        undefined,
        displayUrl,
        false,
        null,
      );

      this.emitActionCard(
        'search',
        `Web Search: ${query}`,
        `Searching ${engine === 'duckduckgo' ? 'DuckDuckGo' : 'Google'} for "${query}".`,
        'SEARCH',
        displayUrl,
      );

      return {
        status: 'success',
        query,
        engine,
        url: displayUrl,
        message: `Displayed web search results for "${query}" in the holographic browser.`,
      };
    });

    this.registerTool('searchYouTube', async (args) => {
      const query = String(args.query || '').trim();
      if (!query) {
        return { status: 'error', message: 'Missing search query for YouTube.' };
      }

      // If running inside Android Native and user asked to search YouTube natively, we also load the HUD player AND can launch native YouTube if requested
      const results = await globalBrowserProvider.searchYouTube(query);
      const firstVideo = results[0];
      const videoId = firstVideo?.videoId || 'dQw4w9WgXcQ';
      const videoTitle = firstVideo?.title || `YouTube: ${query}`;
      const embedUrl = `https://www.youtube.com/embed/${videoId}?enablejsapi=1`;
      const watchUrl = `https://www.youtube.com/watch?v=${videoId}`;

      globalStateManager.setBrowserUrl(
        embedUrl,
        videoTitle,
        'youtube',
        query,
        videoId,
        watchUrl,
        false,
        null,
      );
      globalStateManager.setYouTubeResults(results);
      globalStateManager.setBrowserMediaPlaying(false);

      this.emitActionCard(
        'website',
        `YouTube Search: ${query}`,
        `Loaded ${results.length} playable videos for "${query}". Top result: "${videoTitle}".`,
        'YOUTUBE',
        watchUrl,
      );

      return {
        status: 'success',
        query,
        resultsCount: results.length,
        topResult: {
          title: videoTitle,
          videoId,
          url: watchUrl,
        },
        message: `Found ${results.length} YouTube videos for "${query}" and loaded "${videoTitle}" in the Holographic YouTube Player.`,
      };
    });

    this.registerTool('playYouTube', async (args) => {
      const query = String(args.query || '').trim();
      const explicitVideoId = args.videoId ? String(args.videoId).trim() : '';

      let videoId = explicitVideoId;
      let videoTitle = query ? `YouTube: ${query}` : 'YouTube Video';
      let results = globalStateManager.getState().browserState.youtubeResults || [];

      if (!videoId && query) {
        results = await globalBrowserProvider.searchYouTube(query);
        if (results.length > 0) {
          videoId = results[0].videoId;
          videoTitle = results[0].title;
        }
      }

      if (!videoId) {
        return {
          status: 'error',
          message: `Could not find a playable YouTube video for "${query}".`,
        };
      }

      const embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1&enablejsapi=1`;
      const watchUrl = `https://www.youtube.com/watch?v=${videoId}`;

      globalStateManager.setBrowserUrl(
        embedUrl,
        videoTitle,
        'youtube',
        query || videoTitle,
        videoId,
        watchUrl,
        false,
        null,
      );
      if (results.length > 0) {
        globalStateManager.setYouTubeResults(results);
      }
      globalStateManager.setBrowserMediaPlaying(true);

      this.emitActionCard(
        'website',
        `Playing: ${videoTitle}`,
        `Streaming "${videoTitle}" in the N3k Holographic YouTube Player.`,
        'YOUTUBE',
        watchUrl,
      );

      return {
        status: 'success',
        query,
        videoId,
        title: videoTitle,
        url: watchUrl,
        message: `Now playing "${videoTitle}" on YouTube in the holographic browser.`,
      };
    });

    const handleBrowserBack = () => {
      window.dispatchEvent(new CustomEvent('zinxn3k:browser:back'));
      return {
        status: 'success',
        message: 'Navigated back in the Holographic Browser.',
      };
    };
    this.registerTool('browserBack', handleBrowserBack);
    this.registerTool('navigateBack', handleBrowserBack);

    const handleBrowserForward = () => {
      window.dispatchEvent(new CustomEvent('zinxn3k:browser:forward'));
      return {
        status: 'success',
        message: 'Navigated forward in the Holographic Browser.',
      };
    };
    this.registerTool('browserForward', handleBrowserForward);
    this.registerTool('navigateForward', handleBrowserForward);

    const handleBrowserReload = () => {
      const current = globalStateManager.getState().browserState;
      globalStateManager.setBrowserLoading(true);
      window.dispatchEvent(new CustomEvent('zinxn3k:browser:reload'));
      return {
        status: 'success',
        url: current.inputUrl,
        title: current.title,
        message: `Reloaded ${current.title}.`,
      };
    };
    this.registerTool('browserReload', handleBrowserReload);
    this.registerTool('reloadPage', handleBrowserReload);

    this.registerTool('pauseMedia', () => {
      globalStateManager.setBrowserMediaPlaying(false);
      window.dispatchEvent(new CustomEvent('zinxn3k:media:command', { detail: { command: 'pause' } }));
      return { status: 'success', state: 'paused', message: 'Paused media playback.' };
    });

    this.registerTool('resumeMedia', () => {
      globalStateManager.setBrowserMediaPlaying(true);
      window.dispatchEvent(new CustomEvent('zinxn3k:media:command', { detail: { command: 'play' } }));
      return { status: 'success', state: 'playing', message: 'Resumed media playback.' };
    });

    this.registerTool('stopMedia', () => {
      globalStateManager.setBrowserMediaPlaying(false);
      window.dispatchEvent(new CustomEvent('zinxn3k:media:command', { detail: { command: 'stop' } }));
      return { status: 'success', state: 'stopped', message: 'Stopped media playback.' };
    });

    this.registerTool('setMediaVolume', (args) => {
      const vol = Math.max(0, Math.min(100, Number(args.volume ?? 80)));
      globalStateManager.setBrowserVolume(vol);
      window.dispatchEvent(
        new CustomEvent('zinxn3k:media:command', { detail: { command: 'volume', volume: vol } }),
      );
      return { status: 'success', volume: vol, message: `Set media volume to ${vol}%.` };
    });

    // =========================================================================
    // 4. REAL SCREEN SHARING & ON-DEMAND VISION ANALYSIS
    // =========================================================================
    this.registerTool('startScreenShare', async () => {
      const res = await globalScreenCaptureManager.start();
      if ((res.status === 'active' && res.isSharing) || res.status === 'requesting') {
        const frame = globalScreenCaptureManager.getCurrentFrame();
        if (frame && this.onSendVideoFrameCallback) {
          this.onSendVideoFrameCallback(frame);
        }
        this.emitActionCard(
          'camera',
          res.status === 'active' ? 'Screen Vision Active' : 'Screen Vision Requested',
          res.message,
          'SCREEN',
        );
      }
      return res;
    });

    this.registerTool('stopScreenShare', () => {
      const res = globalScreenCaptureManager.stop();
      this.emitActionCard('info', 'Screen Vision Stopped', res.message, 'SCREEN');
      return res;
    });

    this.registerTool('pauseScreenShare', () => {
      const res = globalScreenCaptureManager.pause();
      this.emitActionCard('info', 'Screen Vision Paused', res.message, 'SCREEN');
      return res;
    });

    this.registerTool('resumeScreenShare', () => {
      const res = globalScreenCaptureManager.resume();
      this.emitActionCard('info', 'Screen Vision Resumed', res.message, 'SCREEN');
      return res;
    });

    const handleAnalyzeScreen = async (args: Record<string, any>) => {
      const prompt = String(
        args.prompt ||
          'Describe what is currently visible on the user screen, including any text, app UI, errors, or buttons, and answer the user question clearly.',
      );

      // Also check if Android Accessibility UI tree is available to enrich visual context
      let uiTreeSummary = '';
      if (globalAndroidBridge.isNativeAndroid()) {
        const uiInfo = globalAndroidBridge.getScreenInfo();
        if (uiInfo.status === 'success') {
          uiTreeSummary = `Active Package: ${uiInfo.packageName}. Visible UI Texts: ${JSON.stringify(
            (uiInfo.visibleTexts || []).slice(0, 25),
          )}. Clickable Elements: ${JSON.stringify(
            (uiInfo.clickableElements || []).slice(0, 15),
          )}.`;
        }
      }

      if (!globalScreenCaptureManager.isActive()) {
        if (uiTreeSummary) {
          return {
            status: 'partial_accessibility_only',
            isSharing: false,
            uiTree: uiTreeSummary,
            message: `MediaProjection screen capture is not active, so I cannot see pixels/images yet, but Android AccessibilityService reports the following on-screen UI elements: ${uiTreeSummary}`,
          };
        }
        return {
          status: 'not_sharing',
          isSharing: false,
          error:
            'Screen sharing is NOT currently active. Tell the user honestly that screen sharing is off and ask them to click "Share Screen" (or say "Share my screen" and approve the system prompt) so you can see their screen.',
        };
      }

      if (globalScreenCaptureManager.isPaused()) {
        return {
          status: 'paused',
          isSharing: true,
          isPaused: true,
          message:
            'Screen Vision is currently paused by the user. Ask the user to resume Screen Vision before capturing a frame.',
        };
      }

      const base64Frame = globalScreenCaptureManager.getCurrentFrame();
      if (!base64Frame) {
        return {
          status: 'error',
          isSharing: true,
          error: 'Could not capture a valid frame from the screen stream.',
        };
      }

      if (this.onSendVideoFrameCallback) {
        this.onSendVideoFrameCallback(base64Frame);
      }

      try {
        const response = await fetch('/api/analyze-screen', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64Frame,
            mimeType: 'image/jpeg',
            prompt: uiTreeSummary ? `${prompt}\n\nAndroid UI Tree Context: ${uiTreeSummary}` : prompt,
          }),
        });

        if (!response.ok) {
          throw new Error(`Vision API returned HTTP ${response.status}`);
        }

        const data = await response.json();
        const analysisText = String(data.analysis || '').trim();

        this.emitActionCard(
          'camera',
          'Screen Vision Analysis',
          analysisText.length > 180 ? `${analysisText.slice(0, 180)}...` : analysisText,
          'VISION',
        );

        return {
          status: 'success',
          isSharing: true,
          prompt,
          uiTree: uiTreeSummary || undefined,
          analysis: analysisText,
          message: `Visual analysis of the current shared screen frame: ${analysisText}`,
        };
      } catch {
        return {
          status: 'success',
          isSharing: true,
          prompt,
          uiTree: uiTreeSummary || undefined,
          message: 'Current screen frame captured and sent to the Gemini Live visual stream.',
        };
      }
    };

    this.registerTool('analyzeScreen', handleAnalyzeScreen);
    this.registerTool('getScreenFrame', handleAnalyzeScreen);
    this.registerTool('captureCurrentScreen', handleAnalyzeScreen);

    // =========================================================================
    // 5. ADDITIONAL SYSTEM, CAMERA, MAPS, TIMER & MATH TOOLS
    // =========================================================================
    this.registerTool('openCamera', () => {
      globalStateManager.setCameraVisionOpen(true);
      this.emitActionCard(
        'camera',
        'Vision Scanner Active',
        'Camera feed initialized for visual analysis.',
        'VISION',
      );
      return {
        status: 'success',
        module: 'vision',
        cameraActive: true,
      };
    });

    this.registerTool('openMaps', (args) => {
      const destination = String(args.query || args.destination || '').trim();
      const mapsUrl = destination
        ? `https://www.google.com/maps/search/${encodeURIComponent(destination)}`
        : 'https://maps.google.com';

      this.emitActionCard(
        'website',
        destination ? `Maps: ${destination}` : 'Google Maps',
        `Navigation lookup for ${destination || 'current location'}.`,
        'MAPS',
        mapsUrl,
      );

      return {
        status: 'success',
        destination,
        url: mapsUrl,
      };
    });

    this.registerTool('changeTheme', (args) => {
      const requested = String(args.theme || '').toLowerCase().trim();
      const validThemes: AssistantTheme[] = [
        'cyber-cyan',
        'electric-violet',
        'midnight-emerald',
        'solar-amber',
        'crimson-pulse',
      ];
      const matched =
        validThemes.find((t) => t.includes(requested) || requested.includes(t)) || 'cyber-cyan';

      if (this.onThemeChangeCallback) {
        this.onThemeChangeCallback(matched);
      }

      this.emitActionCard(
        'theme',
        'Theme Shift',
        args.comment || `Switched holographic aura to ${matched.replace('-', ' ')}.`,
        'SYSTEM',
      );

      return {
        status: 'success',
        theme: matched,
      };
    });

    this.registerTool('setTimer', (args) => {
      const seconds = Math.max(1, Math.round(Number(args.seconds) || 60));
      const label = String(args.label || 'Countdown').trim();

      const timer: ActiveTimer = {
        id: `timer_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        label,
        totalSeconds: seconds,
        remainingSeconds: seconds,
        isPaused: false,
        createdAt: Date.now(),
      };

      if (this.onAddTimerCallback) {
        this.onAddTimerCallback(timer);
      }

      this.emitActionCard('timer', `Timer: ${label}`, `Running for ${seconds} seconds.`, 'COUNTDOWN');

      return {
        status: 'success',
        timerId: timer.id,
        seconds,
      };
    });

    this.registerTool('getSystemStatus', () => {
      const state = globalStateManager.syncAndroidCapabilities();
      const appState = globalStateManager.getState();
      const isScreenActive = globalScreenCaptureManager.isActive();
      const statusInfo = {
        assistant: 'N3k (ZinxN3k)',
        status: appState.assistantState,
        aiCore: appState.assistantState !== 'disconnected' ? 'ONLINE' : 'STANDBY',
        voiceEngine: appState.assistantState !== 'disconnected' ? 'ACTIVE' : 'READY',
        visionModule: appState.isCameraVisionOpen ? 'ACTIVE' : 'READY',
        screenShare: isScreenActive
          ? globalScreenCaptureManager.isPaused()
            ? 'PAUSED'
            : 'ACTIVE'
          : 'OFF',
        androidNativeBridge: state.isAndroidNative ? 'CONNECTED' : 'WEB_HUD_MODE',
        accessibilityService: state.accessibilityEnabled ? 'ENABLED' : 'DISABLED',
        foregroundPackage: state.foregroundPackage,
        browser: appState.browserState.isOpen ? 'ACTIVE' : 'READY',
        memorySystem: `${appState.memoryCount} records`,
        theme: appState.currentTheme,
        language: appState.activeLanguage,
      };

      this.emitActionCard(
        'status',
        'N3k System Diagnostics',
        `AI Core: ${statusInfo.aiCore} · Screen: ${statusInfo.screenShare} · Accessibility: ${statusInfo.accessibilityService} · Memory: ${statusInfo.memorySystem}`,
        'STATUS',
      );

      return statusInfo;
    });

    this.registerTool('openCommandCenter', () => {
      globalStateManager.setCommandCenterOpen(true);
      return {
        status: 'success',
        message: 'Expanded Dynamic Island into the N3k Command Center (CC).',
      };
    });

    this.registerTool('showInteractiveCard', (args) => {
      this.emitActionCard(
        'info',
        String(args.title || 'N3k Insight'),
        String(args.content || ''),
        String(args.category || 'INTEL').toUpperCase(),
      );
      return { status: 'success' };
    });

    this.registerTool('calculateMath', (args) => {
      const expr = String(args.expression || '0');
      let result = '0';
      try {
        const clean = expr.replace(/[^0-9+\-*/(). %]/g, '');
        // eslint-disable-next-line no-eval
        result = String(Function(`'use strict'; return (${clean})`)());
      } catch {
        result = 'Syntax Error';
      }

      this.emitActionCard('math', 'Math Computation', `${expr} = ${result}`, 'MATH');

      return { status: 'success', expression: expr, result };
    });

    // =========================================================================
    // 6. PC / WINDOWS COMPANION AGENT CONTROL TOOLS & WAKE WORD TOOLS
    // =========================================================================
    this.registerTool('openPcApp', async (args) => {
      const appName = String(args.appName || args.app || 'Chrome').trim();
      const res = await globalPcBridgeManager.executePcCommand('open_app', { appName });
      this.emitActionCard('status', `PC App: ${appName}`, res.message, 'PC AGENT');
      return res;
    });

    this.registerTool('openPcUrl', async (args) => {
      const url = String(args.url || 'https://www.google.com').trim();
      const res = await globalPcBridgeManager.executePcCommand('open_url', { url });
      this.emitActionCard('website', 'PC Browser URL', res.message, 'PC AGENT', url);
      return res;
    });

    this.registerTool('typePcText', async (args) => {
      const text = String(args.text || '').trim();
      const res = await globalPcBridgeManager.executePcCommand('type_text', { text });
      this.emitActionCard('status', 'PC Keyboard Type', res.message, 'PC AGENT');
      return res;
    });

    this.registerTool('pressPcKeys', async (args) => {
      const keys = String(args.keys || 'ENTER').trim();
      const res = await globalPcBridgeManager.executePcCommand('press_keys', { keys });
      this.emitActionCard('status', `PC Key: ${keys}`, res.message, 'PC AGENT');
      return res;
    });

    this.registerTool('controlPcMouse', async (args) => {
      const subAction = String(args.action || args.subAction || 'click').toLowerCase();
      const x = Number(args.x ?? 640);
      const y = Number(args.y ?? 400);
      const res = await globalPcBridgeManager.executePcCommand('mouse', { subAction, x, y });
      this.emitActionCard('status', `PC Mouse: ${subAction.toUpperCase()}`, res.message, 'PC AGENT');
      return res;
    });

    this.registerTool('controlPcVolume', async (args) => {
      const command = String(args.command || args.action || 'up').toLowerCase();
      const res = await globalPcBridgeManager.executePcCommand('volume', { command });
      this.emitActionCard('status', `PC Volume: ${command.toUpperCase()}`, res.message, 'PC AGENT');
      return res;
    });

    this.registerTool('controlPcMedia', async (args) => {
      const command = String(args.command || args.action || 'play_pause').toLowerCase();
      const res = await globalPcBridgeManager.executePcCommand('media', { command });
      this.emitActionCard('status', `PC Media: ${command.toUpperCase()}`, res.message, 'PC AGENT');
      return res;
    });

    this.registerTool('controlPcSystem', async (args) => {
      const action = String(args.action || 'lock').toLowerCase();
      const confirmed = Boolean(args.confirmed);
      const res = await globalPcBridgeManager.executePcCommand(action, { confirmed });
      this.emitActionCard('status', `PC System: ${action.toUpperCase()}`, res.message, 'PC AGENT');
      return res;
    });

    this.registerTool('setPcAutoStart', async (args) => {
      const enabled = Boolean(args.enabled ?? true);
      const res = await globalPcBridgeManager.executePcCommand('set_autostart', { enabled });
      this.emitActionCard('status', 'PC Startup Auto-Start', res.message, 'PC AGENT');
      return res;
    });

    this.registerTool('setWakeWordEnabled', (args) => {
      const enabled = Boolean(args.enabled ?? true);
      globalWakeWordManager.setEnabled(enabled);
      this.emitActionCard(
        'status',
        `Wake Word ("Hey N3k"): ${enabled ? 'ACTIVE' : 'OFF'}`,
        enabled
          ? 'Continuous wake word detection for "Hey N3k" / "N3k" is now active.'
          : 'Wake word detection disabled.',
        'WAKE WORD',
      );
      return {
        status: 'success',
        enabled,
        message: `Wake word detection is now ${enabled ? 'enabled' : 'disabled'}.`,
      };
    });

    // =========================================================================
    // 7. N3k V4 GAME HUB, DEVICE MANAGER & FILE OPERATIONS
    // =========================================================================
    this.registerTool('openGameHub', () => {
      globalStateManager.setGameHubOpen(true);
      const games = globalGameManager.getGames();
      this.emitActionCard(
        'game',
        'N3k Game Hub Opened',
        `${games.length} Android & Windows PC titles ready for launch.`,
        'GAME HUB',
      );
      return {
        status: 'success',
        validationStatus: 'SUCCESS',
        gamesCount: games.length,
        games: games.map((g) => ({
          name: g.name,
          platform: g.platform,
          launcher: g.launcher,
          favorite: g.isFavorite,
        })),
        message: 'Opened the N3k Game Hub.',
      };
    });

    this.registerTool('launchGame', async (args) => {
      const gameName = String(args.gameName || args.target || args.name || 'Minecraft').trim();
      const device = (args.device as 'android' | 'windows' | 'auto') || 'auto';
      const res = await globalGameManager.launchGame(gameName, device);
      this.emitActionCard(
        'game',
        res.validationStatus === 'SUCCESS'
          ? `Game Launched: ${res.gameName}`
          : `Game Launch (${res.validationStatus}): ${res.gameName}`,
        res.message,
        'GAME HUB',
      );
      return res;
    });

    this.registerTool('getConnectedDevices', () => {
      const devices = globalDeviceManager.refreshDevices();
      const summary = devices
        .map((d) => `${d.name} [${d.platform.toUpperCase()}]: ${d.online ? 'ONLINE' : 'OFFLINE'}`)
        .join(' · ');
      this.emitActionCard('status', 'Connected Devices', summary, 'DEVICES');
      return {
        status: 'success',
        validationStatus: 'SUCCESS',
        devices,
        message: `Connected Devices: ${summary}`,
      };
    });

    this.registerTool('manageFiles', async (args) => {
      const operation = String(args.operation || 'list').toLowerCase();
      const fileName = args.fileName ? String(args.fileName) : undefined;
      const newName = args.newName ? String(args.newName) : undefined;
      const content = args.content ? String(args.content) : undefined;

      const res = await globalPcBridgeManager.executePcCommand('file_operation', {
        operation,
        fileName,
        newName,
        content,
      });

      this.emitActionCard(
        'pc',
        `File Manager (${operation.toUpperCase()})`,
        res.message,
        'FILES',
      );
      return {
        ...res,
        validationStatus: res.status === 'success' ? 'SUCCESS' : 'FAILED',
      };
    });

    // =========================================================================
    // 8. PRESERVED ANDROID HARDWARE, COMMS, GITHUB, CLIPBOARD, WINDOW & 3D TOOLS
    // =========================================================================
    this.registerTool('setFlashlight', (args) => {
      const enabled = Boolean(args.enabled ?? true);
      const res = globalAndroidBridge.setFlashlight(enabled);
      this.emitActionCard(
        'android',
        `Flashlight: ${enabled ? 'ON' : 'OFF'}`,
        res.message,
        'HARDWARE',
      );
      return res;
    });

    this.registerTool('setBrightness', async (args) => {
      const level = Math.max(0, Math.min(100, Number(args.level ?? 80)));
      const device = String(args.device || 'auto').toLowerCase();
      if (device === 'windows' || (!globalAndroidBridge.isNativeAndroid() && device !== 'android')) {
        const pcRes = await globalPcBridgeManager.executePcCommand('brightness', { level });
        this.emitActionCard('pc', `Brightness: ${level}%`, pcRes.message, 'DISPLAY');
        return pcRes;
      }
      const res = globalAndroidBridge.setBrightness(level);
      this.emitActionCard('android', `Brightness: ${level}%`, res.message, 'DISPLAY');
      return res;
    });

    this.registerTool('setAlarm', (args) => {
      const hour = Number(args.hour ?? 8);
      const minute = Number(args.minute ?? 0);
      const label = String(args.label || args.message || 'N3k Alarm');
      const res = globalAndroidBridge.setAlarm(hour, minute, label);
      this.emitActionCard(
        'timer',
        `Alarm: ${String(hour).padStart(2, '0')}:${String(minute).padStart(2, '0')}`,
        res.message,
        'ALARM',
      );
      return res;
    });

    this.registerTool('requestContactsAccess', () => {
      const res = globalAndroidBridge.requestContactsPermission();
      this.emitActionCard('android', 'Contacts Access', res.message, 'PERMISSION');
      return res;
    });

    this.registerTool('makePhoneCall', (args) => {
      const phoneNumber = String(args.phoneNumber || args.number || '').trim();
      const res = globalAndroidBridge.dialPhone(phoneNumber);
      this.emitActionCard('android', `Dial: ${phoneNumber}`, res.message, 'CALL');
      return res;
    });

    this.registerTool('prepareMessage', (args) => {
      const recipient = String(args.recipient || args.to || '').trim();
      const text = String(args.text || args.message || '').trim();
      const app = String(args.app || 'sms').toLowerCase();
      if (!globalAndroidBridge.isNativeAndroid() && app.includes('whatsapp')) {
        const waUrl = `https://web.whatsapp.com/send?phone=${encodeURIComponent(recipient)}&text=${encodeURIComponent(text)}`;
        this.emitActionCard('website', `WhatsApp: ${recipient}`, `Prepared WhatsApp message: "${text}"`, 'WHATSAPP', waUrl);
        return { status: 'success', recipient, app: 'whatsapp', url: waUrl, message: 'Prepared WhatsApp message link.' };
      }
      const res = globalAndroidBridge.prepareMessage(recipient, text, app);
      this.emitActionCard('android', `Message (${app.toUpperCase()}): ${recipient}`, res.message, 'MESSAGE');
      return res;
    });

    this.registerTool('readNotifications', (args) => {
      const limit = Number(args.limit ?? 10);
      const res = globalAndroidBridge.getRecentNotifications(limit);
      if (res.status === 'requires_notification_access' || res.status === 'requires_android_apk') {
        this.emitActionCard(
          'android',
          'Notification Access Required',
          res.message,
          'NOTIFICATIONS',
        );
        return res;
      }
      const count = Array.isArray(res.notifications) ? res.notifications.length : 0;
      this.emitActionCard(
        'android',
        'Recent Notifications',
        `Read ${count} recent notification${count === 1 ? '' : 's'}.`,
        'NOTIFICATIONS',
      );
      return res;
    });

    this.registerTool('openNotificationAccessSettings', () => {
      const res = globalAndroidBridge.openNotificationAccessSettings();
      this.emitActionCard('android', 'Notification Access', res.message, 'SETTINGS');
      return res;
    });

    this.registerTool('searchGitHub', (args) => {
      const query = String(args.query || '').trim();
      const ghUrl = `https://github.com/search?q=${encodeURIComponent(query)}&type=repositories`;
      globalStateManager.setBrowserUrl(
        ghUrl,
        `GitHub: ${query}`,
        'web',
        undefined,
        undefined,
        ghUrl,
        true,
        'GitHub restricts iframe embedding via X-Frame-Options; use external launch.',
      );
      this.emitActionCard('search', `GitHub Search: ${query}`, `Searched GitHub repositories for "${query}".`, 'GITHUB', ghUrl);
      return { status: 'success', query, url: ghUrl, message: `Opened GitHub search for "${query}".` };
    });

    this.registerTool('controlPcWindow', async (args) => {
      const operation = String(args.operation || 'minimize').toLowerCase();
      const res = await globalPcBridgeManager.executePcCommand('window', { operation });
      this.emitActionCard('pc', `PC Window: ${operation.toUpperCase()}`, res.message, 'WINDOW');
      return res;
    });

    this.registerTool('manageClipboard', async (args) => {
      const operation = String(args.operation || 'set').toLowerCase();
      const text = String(args.text || '');
      if (operation === 'set' && typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
        try {
          await navigator.clipboard.writeText(text);
        } catch {}
      }
      const res = await globalPcBridgeManager.executePcCommand('clipboard', { operation, text });
      this.emitActionCard('info', `Clipboard (${operation.toUpperCase()})`, res.message, 'CLIPBOARD');
      return res;
    });

    this.registerTool('stopSpeaking', () => {
      window.dispatchEvent(new CustomEvent('n3k:speech:stop'));
      this.emitActionCard('status', 'Speech Halted', 'Stopped N3k voice output immediately.', 'VOICE');
      return { status: 'success', message: 'Stopped speaking.' };
    });

    this.registerTool('cancelPendingAction', () => {
      globalPcBridgeManager.cancelPendingDangerAction();
      this.emitActionCard('status', 'Pending Action Cancelled', 'Cancelled pending confirmation action.', 'SAFETY');
      return { status: 'success', message: 'Cancelled pending action.' };
    });

    this.registerTool('set3DCameraPreset', (args) => {
      const preset = String(args.preset || 'portrait').toLowerCase();
      window.dispatchEvent(new CustomEvent('n3k:camera3d:preset', { detail: { preset } }));
      this.emitActionCard('camera', `3D Camera: ${preset.toUpperCase()}`, `Switched 3D character camera preset to ${preset}.`, '3D RIG');
      return { status: 'success', preset, message: `Switched 3D camera preset to ${preset}.` };
    });
  }
}
