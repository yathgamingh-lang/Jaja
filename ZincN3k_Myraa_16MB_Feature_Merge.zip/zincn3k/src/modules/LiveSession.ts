import { AssistantTheme, VoicePersona } from '../types/assistant.ts';
import { AudioPlayer } from './AudioPlayer.ts';
import { AudioStreamer } from './AudioStreamer.ts';
import { globalStateManager, StateManager } from './StateManager.ts';
import { ToolManager } from './ToolManager.ts';
import { globalMemoryManager } from '../memory/MemoryManager.ts';

export class LiveSession {
  private ws: WebSocket | null = null;
  private audioStreamer: AudioStreamer;
  private audioPlayer: AudioPlayer;
  private toolManager: ToolManager;
  private stateManager: StateManager;
  private pingIntervalId: any = null;
  private lastPingTimestamp = 0;
  private isConnecting = false;
  private userStoppedManually = false;
  private reconnectAttempts = 0;
  private reconnectTimeoutId: any = null;
  private pendingTextMessage: string | null = null;

  constructor(
    audioStreamer?: AudioStreamer,
    audioPlayer?: AudioPlayer,
    toolManager?: ToolManager,
    stateManager?: StateManager,
  ) {
    this.audioStreamer = audioStreamer || new AudioStreamer(16000);
    this.audioPlayer = audioPlayer || new AudioPlayer(24000);
    this.toolManager = toolManager || new ToolManager(globalMemoryManager);
    this.stateManager = stateManager || globalStateManager;

    this.setupListeners();
  }

  public getAudioPlayer(): AudioPlayer {
    return this.audioPlayer;
  }

  public getAudioStreamer(): AudioStreamer {
    return this.audioStreamer;
  }

  public getToolManager(): ToolManager {
    return this.toolManager;
  }

  public sendVideoFrame(base64Jpeg: string) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(
        JSON.stringify({
          type: 'video',
          data: base64Jpeg,
        }),
      );
    }
  }

  /**
   * Sends a text command/question into the active Gemini Live session
   * (or connects first and sends it once ready).
   */
  public async sendTextMessage(text: string) {
    const clean = text.trim();
    if (!clean) return;

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.stateManager.setAssistantState('thinking');
      this.ws.send(
        JSON.stringify({
          type: 'text',
          text: clean,
        }),
      );
    } else {
      this.pendingTextMessage = clean;
      await this.connect();
    }
  }

  private setupListeners() {
    this.audioStreamer.setOnAudioChunk((base64Pcm: string) => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(
          JSON.stringify({
            type: 'audio',
            data: base64Pcm,
          }),
        );
      }
    });

    this.audioStreamer.setOnVolumeChange((volume: number) => {
      this.stateManager.setUserAudioLevel(volume);
    });

    this.audioPlayer.setOnSpeakingStateChange((isSpeaking: boolean) => {
      const currentState = this.stateManager.getState().assistantState;
      if (currentState === 'disconnected' || currentState === 'connecting') return;
      if (isSpeaking) {
        this.stateManager.setAssistantState('speaking');
      } else {
        this.stateManager.setAssistantState('listening');
      }
    });

    this.audioPlayer.setOnLevelChange((level: number) => {
      this.stateManager.setAssistantAudioLevel(level);
    });

    this.toolManager.setOnActionCard((card) => {
      this.stateManager.addActionCard(card);
    });

    this.toolManager.setOnThemeChange((theme: AssistantTheme) => {
      this.stateManager.setTheme(theme);
    });

    this.toolManager.setOnAddTimer((timer) => {
      this.stateManager.addTimer(timer);
    });

    this.toolManager.setOnSendVideoFrame((base64Jpeg: string) => {
      this.sendVideoFrame(base64Jpeg);
    });
  }

  public async connect(voicePersona?: VoicePersona) {
    if (this.isConnecting || (this.ws && this.ws.readyState === WebSocket.OPEN)) return;
    this.isConnecting = true;
    this.userStoppedManually = false;
    if (this.reconnectTimeoutId) {
      clearTimeout(this.reconnectTimeoutId);
      this.reconnectTimeoutId = null;
    }

    this.stateManager.setAssistantState('connecting');
    this.stateManager.setErrorMessage(null);

    try {
      await globalMemoryManager.init();
      await this.audioPlayer.init();

      const state = this.stateManager.getState();
      const deviceId =
        state.selectedAudioInputId !== 'default' ? state.selectedAudioInputId : undefined;
      const micLabel = await this.audioStreamer.start(deviceId);
      this.stateManager.setMicLabel(micLabel);
      this.stateManager.updatePermission('microphone', 'granted');

      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const host = window.location.host;
      const wsUrl = `${protocol}//${host}/live`;

      console.log(`[LiveSession] Connecting to WebSocket at ${wsUrl}...`);
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[LiveSession] WebSocket connection established');
        this.isConnecting = false;
        this.reconnectAttempts = 0;
        const voice = voicePersona || this.stateManager.getState().voicePersona;

        const memoryContext = globalMemoryManager.getCompactContext();

        if (this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(
            JSON.stringify({
              type: 'init',
              voice,
              model: 'gemini-3.8-live',
              memoryContext,
            }),
          );
        }

        this.startPingPong();
      };

      this.ws.onmessage = async (event: MessageEvent) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'ready') {
            console.log(
              '[LiveSession] Gemini Live is ready with ZinxN3k Brain! Listening for user...',
            );
            this.stateManager.setAssistantState('listening');

            if (this.pendingTextMessage && this.ws && this.ws.readyState === WebSocket.OPEN) {
              const textToSend = this.pendingTextMessage;
              this.pendingTextMessage = null;
              this.stateManager.setAssistantState('thinking');
              this.ws.send(
                JSON.stringify({
                  type: 'text',
                  text: textToSend,
                }),
              );
            }
            return;
          }

          if (msg.type === 'audio' && msg.data) {
            this.audioPlayer.queuePcmChunk(msg.data);
            return;
          }

          if (msg.type === 'interrupted') {
            console.log('[LiveSession] User interrupted ZinxN3k');
            this.audioPlayer.interrupt();
            this.stateManager.setAssistantState('listening');
            return;
          }

          if (msg.type === 'turn_complete') {
            this.stateManager.incrementTurn();
            if (this.stateManager.getState().assistantState === 'thinking') {
              this.stateManager.setAssistantState('listening');
            }
            return;
          }

          if (msg.type === 'tool_call' && Array.isArray(msg.calls)) {
            console.log('[LiveSession] Executing real tool calls in ToolManager:', msg.calls);
            this.stateManager.setAssistantState('thinking');

            const functionResponses = [];
            for (const call of msg.calls) {
              let res: any;
              try {
                res = await this.toolManager.executeTool(call.name, call.args || {}, call.id);
              } catch (toolErr: any) {
                console.error(`[LiveSession] Tool ${call.name} failed:`, toolErr);
                res = {
                  status: 'error',
                  message: toolErr?.message || 'Tool execution failed',
                };
              }
              functionResponses.push({
                name: call.name,
                id: call.id,
                response: res || { status: 'success' },
              });
            }

            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
              this.ws.send(
                JSON.stringify({
                  type: 'tool_results',
                  responses: functionResponses,
                }),
              );
            }
            return;
          }

          if (msg.type === 'pong') {
            if (this.lastPingTimestamp > 0) {
              const rtt = Date.now() - this.lastPingTimestamp;
              this.stateManager.setLatency(rtt);
            }
            return;
          }

          if (msg.type === 'session_closed') {
            console.warn('[LiveSession] Remote Gemini Live session closed:', msg.reason);
            if (!this.userStoppedManually) {
              this.scheduleReconnect();
            }
            return;
          }

          if (msg.type === 'error') {
            console.error('[LiveSession] Server error:', msg.message);
            this.stateManager.setErrorMessage(msg.message || 'Error occurred in live session');
          }
        } catch (err) {
          console.error('[LiveSession] Error handling incoming ws message:', err);
        }
      };

      this.ws.onerror = (err) => {
        console.error('[LiveSession] WebSocket error:', err);
        this.stateManager.setErrorMessage('Live connection interrupted. Attempting recovery...');
      };

      this.ws.onclose = () => {
        console.log('[LiveSession] WebSocket closed');
        const wasManual = this.userStoppedManually;
        this.cleanup();
        if (!wasManual && this.reconnectAttempts < 3) {
          this.scheduleReconnect();
        }
      };
    } catch (err: any) {
      console.error('[LiveSession] Failed to connect:', err);
      if (err?.name === 'NotAllowedError') {
        this.stateManager.updatePermission('microphone', 'denied');
      }
      this.stateManager.setErrorMessage(
        err?.message || 'Could not access microphone or connect to ZinxN3k.',
      );
      this.cleanup();
    }
  }

  private scheduleReconnect() {
    if (this.userStoppedManually || this.reconnectAttempts >= 3) return;
    this.reconnectAttempts += 1;
    const delayMs = 1500 * this.reconnectAttempts;
    console.log(`[LiveSession] Scheduling automatic recovery attempt #${this.reconnectAttempts} in ${delayMs}ms...`);
    this.stateManager.setErrorMessage(`Connection dropped. Reconnecting (attempt ${this.reconnectAttempts}/3)...`);
    this.reconnectTimeoutId = setTimeout(() => {
      if (!this.userStoppedManually) {
        this.connect();
      }
    }, delayMs);
  }

  public disconnect() {
    console.log('[LiveSession] User triggered disconnect');
    this.userStoppedManually = true;
    if (this.reconnectTimeoutId) {
      clearTimeout(this.reconnectTimeoutId);
      this.reconnectTimeoutId = null;
    }
    this.cleanup();
  }

  public toggleMute(): boolean {
    const nextMuted = !this.audioStreamer.getIsMuted();
    this.audioStreamer.setMuted(nextMuted);
    this.stateManager.setMuted(nextMuted);
    return nextMuted;
  }

  public setVoicePersona(voice: VoicePersona) {
    this.stateManager.setVoicePersona(voice);
    if (this.stateManager.getState().assistantState !== 'disconnected') {
      this.disconnect();
      setTimeout(() => {
        this.connect(voice);
      }, 300);
    }
  }

  private startPingPong() {
    if (this.pingIntervalId) clearInterval(this.pingIntervalId);
    this.pingIntervalId = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.lastPingTimestamp = Date.now();
        this.ws.send(JSON.stringify({ type: 'ping' }));
      }
    }, 4000);
  }

  private cleanup() {
    this.isConnecting = false;
    if (this.pingIntervalId) {
      clearInterval(this.pingIntervalId);
      this.pingIntervalId = null;
    }
    if (this.ws) {
      try {
        this.ws.onclose = null;
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    this.audioStreamer.stop();
    this.audioPlayer.stop();
    this.stateManager.setAssistantState('disconnected');
  }
}

export const globalLiveSession = new LiveSession();
