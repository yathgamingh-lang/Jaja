import { globalAndroidBridge } from './AndroidBridge.ts';
import { globalPcBridgeManager, PcBridgeState } from './PcBridgeManager.ts';
import { globalNotificationManager } from './NotificationManager.ts';

export interface ConnectedDeviceInfo {
  id: string;
  name: string;
  platform: 'android' | 'windows' | 'web_hud';
  online: boolean;
  batteryPercent: number | null;
  isCharging: boolean | null;
  connectionStatus: 'connected' | 'paired_standby' | 'offline';
  lastSeen: number;
  capabilities: string[];
  details?: string;
}

type DeviceListener = (devices: ConnectedDeviceInfo[]) => void;

export class DeviceManager {
  private devices: ConnectedDeviceInfo[] = [];
  private listeners: Set<DeviceListener> = new Set();
  private localBatteryPercent: number | null = null;
  private localBatteryCharging: boolean | null = null;
  private wasPcConnected = false;

  constructor() {
    this.initBatteryMonitor();
    this.refreshDevices();

    globalPcBridgeManager.subscribe((pcState) => {
      const nowConnected = pcState.status === 'connected';
      if (nowConnected && !this.wasPcConnected) {
        globalNotificationManager.push(
          'PC Connected',
          `Paired with ${pcState.telemetry?.hostname || 'Windows PC'} (${pcState.latencyMs}ms).`,
          'pc',
        );
      }
      this.wasPcConnected = nowConnected;
      this.refreshDevices(pcState);
    });

    if (typeof window !== 'undefined') {
      window.addEventListener('n3k:android:sync', () => this.refreshDevices());
    }
  }

  private async initBatteryMonitor() {
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      try {
        const bat = await (navigator as any).getBattery();
        const updateBat = () => {
          this.localBatteryPercent = Math.round((bat.level ?? 1) * 100);
          this.localBatteryCharging = Boolean(bat.charging);
          this.refreshDevices();
        };
        updateBat();
        bat.addEventListener('levelchange', updateBat);
        bat.addEventListener('chargingchange', updateBat);
      } catch {}
    }
  }

  public refreshDevices(pcStateOverride?: PcBridgeState): ConnectedDeviceInfo[] {
    const androidCaps = globalAndroidBridge.getCapabilities();
    const pcState = pcStateOverride || globalPcBridgeManager.getState();
    const now = Date.now();

    const androidDevice: ConnectedDeviceInfo = {
      id: 'device_android_primary',
      name: androidCaps.isAndroidNative ? 'Android Mobile (N3k Native)' : 'Android Mobile Bridge',
      platform: 'android',
      online: androidCaps.isAndroidNative,
      batteryPercent: androidCaps.isAndroidNative ? this.localBatteryPercent : null,
      isCharging: androidCaps.isAndroidNative ? this.localBatteryCharging : null,
      connectionStatus: androidCaps.isAndroidNative ? 'connected' : 'paired_standby',
      lastSeen: now,
      capabilities: [
        'PackageManager App Launcher',
        'Android Game Launcher',
        androidCaps.accessibilityEnabled
          ? 'Accessibility UI Control (Active)'
          : 'Accessibility UI Control (Setup Required)',
        'MediaProjection Screen Vision',
        'Wake Word Foreground Service',
      ],
      details: androidCaps.isAndroidNative
        ? `Foreground: ${androidCaps.foregroundPackage}`
        : 'Install /android APK for native Android OS execution',
    };

    const windowsDevice: ConnectedDeviceInfo = {
      id: 'device_windows_pc',
      name: pcState.telemetry?.hostname || 'Windows PC Companion',
      platform: 'windows',
      online: pcState.status === 'connected',
      batteryPercent: this.localBatteryPercent,
      isCharging: this.localBatteryCharging,
      connectionStatus: pcState.status === 'connected' ? 'connected' : 'offline',
      lastSeen: now,
      capabilities: [
        'Desktop App & Game Launcher (Steam / Epic / Xbox)',
        'Win32 Keyboard & Mouse Automation',
        'System Volume & Media Control',
        'Windows Screen Capture & File Operations',
        'Power Control (Lock / Sleep / Shutdown)',
      ],
      details: pcState.telemetry
        ? `${pcState.telemetry.platform} · CPU ${pcState.telemetry.cpuUsagePercent}% · RAM ${pcState.telemetry.memoryUsedGb}/${pcState.telemetry.memoryTotalGb}GB · Active: ${pcState.telemetry.activeWindowTitle}`
        : 'PC Agent offline',
    };

    const webHudDevice: ConnectedDeviceInfo = {
      id: 'device_web_hud',
      name: 'N3k Holographic Command HUD',
      platform: 'web_hud',
      online: true,
      batteryPercent: this.localBatteryPercent,
      isCharging: this.localBatteryCharging,
      connectionStatus: 'connected',
      lastSeen: now,
      capabilities: [
        'Gemini Live 24kHz Voice Engine',
        'Wake Word Detection ("Hey N3k")',
        'On-Demand Screen Vision (getDisplayMedia)',
        'Holographic Browser & YouTube Player',
        'N3k Brain IndexedDB Memory',
      ],
      details: 'Active Voice & Visual Command Interface',
    };

    this.devices = [androidDevice, windowsDevice, webHudDevice];
    this.notifyListeners();
    return this.devices;
  }

  public getDevices(): ConnectedDeviceInfo[] {
    return this.devices;
  }

  public subscribe(listener: DeviceListener): () => void {
    this.listeners.add(listener);
    listener(this.devices);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners() {
    const copy = [...this.devices];
    this.listeners.forEach((l) => l(copy));
  }
}

export const globalDeviceManager = new DeviceManager();
