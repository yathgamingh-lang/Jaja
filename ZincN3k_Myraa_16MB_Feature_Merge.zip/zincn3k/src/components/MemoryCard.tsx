import React, { useState } from 'react';
import { Trash2, Edit3, Check, X, Clock, ShieldCheck, Tag } from 'lucide-react';
import { Memory, MEMORY_CATEGORIES } from '../memory/MemoryTypes.ts';
import { AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface MemoryCardProps {
  memory: Memory;
  theme: AssistantTheme;
  onUpdate: (id: string, key: string, value: string) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}

export const MemoryCard: React.FC<MemoryCardProps> = ({
  memory,
  theme,
  onUpdate,
  onDelete,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editKey, setEditKey] = useState(memory.key);
  const [editValue, setEditValue] = useState(memory.value);
  const [isSaving, setIsSaving] = useState(false);
  const [showConfirmDelete, setShowConfirmDelete] = useState(false);

  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];
  const categoryMeta = MEMORY_CATEGORIES.find((c) => c.id === memory.category);

  const handleSave = async () => {
    if (!editKey.trim() || !editValue.trim()) return;
    setIsSaving(true);
    try {
      await onUpdate(memory.id, editKey.trim(), editValue.trim());
      setIsEditing(false);
    } catch (err) {
      console.error('Failed to update memory:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setEditKey(memory.key);
    setEditValue(memory.value);
    setIsEditing(false);
  };

  const formatTime = (ts: number) => {
    const diff = Date.now() - ts;
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div
      className="group relative p-4 rounded-2xl bg-white/[0.03] border border-white/10 hover:border-white/20 transition-all duration-300 backdrop-blur-md"
      style={{
        boxShadow: isEditing ? `0 0 20px ${themeConfig.glow}` : undefined,
      }}
    >
      <div className="flex items-start justify-between gap-3">
        {/* Category Badge & Confidence */}
        <div className="flex items-center gap-2 flex-wrap">
          <span
            className="text-[10px] font-mono px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider flex items-center gap-1"
            style={{
              backgroundColor: `${themeConfig.primary}18`,
              color: themeConfig.primary,
              border: `1px solid ${themeConfig.primary}33`,
            }}
          >
            <Tag className="w-2.5 h-2.5" />
            <span>{categoryMeta?.label || memory.category}</span>
          </span>

          <span className="text-[10px] font-mono text-slate-400 flex items-center gap-1 tabular-nums">
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
            <span>{Math.round(memory.confidence * 100)}% conf</span>
          </span>

          <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1 ml-auto tabular-nums">
            <Clock className="w-2.5 h-2.5" />
            <span>{formatTime(memory.updatedAt)}</span>
          </span>
        </div>

        {/* Action Buttons */}
        {!isEditing && (
          <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => setIsEditing(true)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              title="Edit memory"
            >
              <Edit3 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setShowConfirmDelete(true)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors"
              title="Delete memory"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>

      {/* Content Area */}
      {isEditing ? (
        <div className="mt-3 space-y-2.5 animate-in fade-in duration-200">
          <div>
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1">
              Memory Key
            </label>
            <input
              type="text"
              value={editKey}
              onChange={(e) => setEditKey(e.target.value)}
              className="w-full bg-slate-900 border border-white/20 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400"
              placeholder="e.g. favorite_game, name"
            />
          </div>
          <div>
            <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-1">
              Memory Value
            </label>
            <textarea
              rows={2}
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              className="w-full bg-slate-900 border border-white/20 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 resize-none"
              placeholder="e.g. Minecraft, Yatharth"
            />
          </div>
          <div className="flex items-center justify-end gap-2 pt-1">
            <button
              onClick={handleCancel}
              disabled={isSaving}
              className="px-2.5 py-1 rounded-lg border border-white/10 text-xs text-slate-300 hover:bg-white/5 flex items-center gap-1"
            >
              <X className="w-3 h-3" />
              <span>Cancel</span>
            </button>
            <button
              onClick={handleSave}
              disabled={isSaving || !editKey.trim() || !editValue.trim()}
              className="px-3 py-1 rounded-lg text-xs font-semibold text-black transition-all flex items-center gap-1 shadow-md"
              style={{ backgroundColor: themeConfig.primary }}
            >
              <Check className="w-3 h-3" />
              <span>{isSaving ? 'Saving...' : 'Save'}</span>
            </button>
          </div>
        </div>
      ) : (
        <div className="mt-2.5">
          <div className="text-xs font-mono font-bold text-slate-300 uppercase tracking-wide">
            {memory.key}
          </div>
          <div className="text-sm font-medium text-white mt-1 leading-relaxed">
            {memory.value}
          </div>
        </div>
      )}

      {/* Delete Confirmation Overlay */}
      {showConfirmDelete && (
        <div className="absolute inset-0 bg-slate-950/90 rounded-2xl flex flex-col items-center justify-center p-4 z-20 backdrop-blur-sm animate-in fade-in duration-150">
          <p className="text-xs text-slate-200 text-center font-medium">
            Forget this memory about "{memory.key}"?
          </p>
          <div className="flex items-center gap-2 mt-3">
            <button
              onClick={() => setShowConfirmDelete(false)}
              className="px-3 py-1 rounded-lg border border-white/10 text-xs text-slate-300 hover:bg-white/10"
            >
              Cancel
            </button>
            <button
              onClick={async () => {
                await onDelete(memory.id);
                setShowConfirmDelete(false);
              }}
              className="px-3 py-1 rounded-lg bg-rose-600 text-xs font-semibold text-white hover:bg-rose-500 shadow-md"
            >
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
