import React, { useEffect, useRef, useState } from 'react';
import {
  Monitor,
  MonitorOff,
  Eye,
  Minimize2,
  Maximize2,
  Scan,
  AlertCircle,
  Pause,
  Play,
} from 'lucide-react';
import { AssistantTheme, ScreenShareState } from '../types/assistant.ts';
import { globalStateManager } from '../modules/StateManager.ts';
import { globalScreenCaptureManager } from '../modules/ScreenShareManager.ts';
import { globalLiveSession } from '../modules/LiveSession.ts';

interface ScreenShareHUDProps {
  screenShareState: ScreenShareState;
  theme: AssistantTheme;
  onStop?: () => void;
}

export const ScreenShareHUD: React.FC<ScreenShareHUDProps> = ({
  screenShareState,
  onStop,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const isStreamLive =
    (screenShareState.status === 'active' || screenShareState.status === 'paused') &&
    screenShareState.isSharing &&
    globalScreenCaptureManager.isActive();

  const isPaused = Boolean(screenShareState.isPaused || screenShareState.status === 'paused');
  const isMinimized = screenShareState.isPreviewMinimized;

  useEffect(() => {
    if (videoRef.current && screenShareState.stream && !isMinimized) {
      videoRef.current.srcObject = screenShareState.stream;
      videoRef.current.play().catch(() => {});
    }
  }, [screenShareState.stream, isMinimized]);

  if (!isStreamLive && screenShareState.status !== 'error') {
    return null;
  }

  /**
   * IMPORTANT: Minimizing ONLY hides the video preview UI.
   * It NEVER stops the MediaStream tracks! Screen sharing continues in the background.
   */
  const handleToggleMinimize = () => {
    globalStateManager.setScreenPreviewMinimized(!isMinimized);
  };

  const handleTogglePause = () => {
    if (isPaused) {
      globalScreenCaptureManager.resume();
    } else {
      globalScreenCaptureManager.pause();
    }
  };

  const handleStop = () => {
    if (onStop) {
      onStop();
    } else {
      globalScreenCaptureManager.stop();
    }
  };

  /**
   * Captures the current frame on demand and asks N3k to analyze it
   */
  const handleInspectNow = async () => {
    if (!globalScreenCaptureManager.isActive() || isPaused || isAnalyzing) return;
    setIsAnalyzing(true);
    try {
      await globalLiveSession
        .getToolManager()
        .executeTool('analyzeScreen', { prompt: 'What is currently on my screen?' }, 'manual');
      await globalLiveSession.sendTextMessage(
        'I just captured my screen frame. Briefly tell me what is on my screen.',
      );
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="fixed bottom-24 right-4 z-40 w-72 sm:w-80 rounded-2xl bg-[#070b18]/92 border border-cyan-400/40 shadow-[0_0_35px_rgba(0,229,255,0.22)] backdrop-blur-2xl p-3.5 font-mono select-none animate-in slide-in-from-bottom-4 duration-200">
      {/* Header matching required spec: SCREEN / ● ACTIVE */}
      <div className="flex items-center justify-between pb-2.5 border-b border-white/10">
        <div>
          <div className="text-[10px] text-slate-400 tracking-widest uppercase">SCREEN VISION</div>
          {isStreamLive ? (
            <div
              className={`flex items-center gap-1.5 text-xs font-black mt-0.5 ${
                isPaused ? 'text-amber-300' : 'text-emerald-300'
              }`}
            >
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  isPaused ? 'bg-amber-400' : 'bg-emerald-400 animate-ping'
                }`}
              />
              <span>{isPaused ? '● PAUSED' : '● ACTIVE'}</span>
            </div>
          ) : (
            <div className="flex items-center gap-1.5 text-xs font-bold text-rose-300 mt-0.5">
              <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
              <span>○ OFF ({screenShareState.error || 'Stopped'})</span>
            </div>
          )}
        </div>

        {/* Action Buttons: [PAUSE/RESUME] [MINIMIZE] [STOP] */}
        <div className="flex items-center gap-1.5">
          {isStreamLive && (
            <button
              onClick={handleTogglePause}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-amber-500/20 border border-amber-400/30 text-amber-200 transition-all active:scale-95"
              title={isPaused ? 'Resume Screen Vision' : 'Pause Screen Vision'}
            >
              {isPaused ? <Play className="w-3 h-3" /> : <Pause className="w-3 h-3" />}
            </button>
          )}

          {isStreamLive && screenShareState.stream && (
            <button
              onClick={handleToggleMinimize}
              className="px-2 py-1 rounded-lg text-[10px] font-bold bg-white/5 hover:bg-cyan-500/20 border border-cyan-400/30 text-cyan-200 transition-all active:scale-95 flex items-center gap-1"
              title={
                isMinimized
                  ? 'Restore Screen Preview (Stream is still active)'
                  : 'Minimize Preview (Keep Screen Sharing Active)'
              }
            >
              {isMinimized ? (
                <>
                  <Maximize2 className="w-3 h-3" />
                  <span>EXPAND</span>
                </>
              ) : (
                <>
                  <Minimize2 className="w-3 h-3" />
                  <span>MIN</span>
                </>
              )}
            </button>
          )}

          <button
            onClick={handleStop}
            className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-rose-500/15 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 transition-all active:scale-95 flex items-center gap-1"
            title="Stop Screen Sharing and release all tracks"
          >
            <MonitorOff className="w-3 h-3" />
            <span>STOP</span>
          </button>
        </div>
      </div>

      {/* Collapsible Video Preview Area */}
      {isStreamLive && screenShareState.stream && !isMinimized && (
        <div className="mt-2.5 relative aspect-video w-full rounded-xl overflow-hidden border border-cyan-500/25 bg-black/70 flex items-center justify-center group">
          <video
            ref={videoRef}
            muted
            playsInline
            autoPlay
            className={`w-full h-full object-contain ${isPaused ? 'opacity-40 grayscale' : ''}`}
          />
          <div className="absolute inset-0 pointer-events-none opacity-35 bg-[linear-gradient(rgba(0,229,255,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(0,229,255,0.1)_1px,transparent_1px)] bg-[size:16px_16px]" />

          <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-black/80 border border-emerald-500/40 text-[9px] text-emerald-300 flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            <span>{isPaused ? 'CAPTURE PAUSED' : 'ON-DEMAND VISION READY'}</span>
          </div>
        </div>
      )}

      {/* Minimized or Android MediaProjection Notice */}
      {isStreamLive && (isMinimized || !screenShareState.stream) && (
        <div className="mt-2 py-1.5 px-2.5 rounded-xl bg-emerald-950/30 border border-emerald-500/25 text-[10px] text-emerald-200 flex items-center justify-between">
          <span>
            {!screenShareState.stream
              ? 'Android MediaProjection ACTIVE'
              : 'Preview minimized · Stream ACTIVE'}
          </span>
          <Monitor className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
        </div>
      )}

      {/* On-Demand Visual Inspection Trigger */}
      {isStreamLive && (
        <div className="mt-2.5 flex items-center justify-between gap-2 pt-2 border-t border-white/10">
          <span className="text-[10px] text-slate-400">
            Say: <span className="text-cyan-300">"What is on my screen?"</span>
          </span>
          <button
            onClick={handleInspectNow}
            disabled={isAnalyzing || isPaused}
            className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-cyan-500/20 hover:bg-cyan-500/35 border border-cyan-400/40 text-cyan-200 transition-all active:scale-95 flex items-center gap-1 disabled:opacity-50"
          >
            {isAnalyzing ? (
              <>
                <Scan className="w-3 h-3 animate-spin" />
                <span>Analyzing...</span>
              </>
            ) : (
              <>
                <Eye className="w-3 h-3" />
                <span>Analyze Now</span>
              </>
            )}
          </button>
        </div>
      )}
    </div>
  );
};
