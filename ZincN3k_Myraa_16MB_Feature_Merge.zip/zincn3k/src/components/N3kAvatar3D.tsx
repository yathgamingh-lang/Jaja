import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { VRM, VRMLoaderPlugin, VRMUtils } from '@pixiv/three-vrm';
import { AssistantState, AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';
import { AudioPlayer } from '../modules/AudioPlayer.ts';
import {
  ALL_N3K_EXPRESSIONS,
  globalEmotionController,
  N3kExpression,
} from '../avatar3d/EmotionController.ts';
import { globalVisemeController, VisemeCode } from '../avatar3d/VisemeController.ts';
import { globalIdleBehaviorController } from '../avatar3d/IdleBehaviorController.ts';
import { globalGestureController, N3kGestureType } from '../avatar3d/GestureController.ts';
import { globalErrorCenterManager } from '../modules/ErrorCenterManager.ts';

export type CameraPreset3D = 'portrait' | 'close_up' | 'upper_body' | 'cinematic';

interface N3kAvatar3DProps {
  state: AssistantState;
  theme: AssistantTheme;
  userLevel: number;
  assistantLevel: number;
  isMuted: boolean;
  audioPlayer: AudioPlayer;
  onToggleConnect: () => void;
}

export const N3kAvatar3D: React.FC<N3kAvatar3DProps> = ({
  state,
  theme,
  userLevel,
  assistantLevel,
  isMuted,
  audioPlayer,
  onToggleConnect,
}) => {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const [activeExpression, setActiveExpression] = useState<N3kExpression>(
    globalEmotionController.getExpression(),
  );
  const [activeViseme, setActiveViseme] = useState<VisemeCode>('SIL');
  const [cameraPreset, setCameraPreset] = useState<CameraPreset3D>('portrait');

  // Keep latest props in ref for the 60fps Three.js render loop
  const propsRef = useRef({
    state,
    theme,
    userLevel,
    assistantLevel,
    isMuted,
    audioPlayer,
    cameraPreset,
  });
  useEffect(() => {
    propsRef.current = {
      state,
      theme,
      userLevel,
      assistantLevel,
      isMuted,
      audioPlayer,
      cameraPreset,
    };

    // Automatically map AssistantState to default visual expression when not manually overridden
    if (state === 'error') {
      globalEmotionController.setExpression('ERROR');
    } else if (state === 'thinking' || state === 'connecting') {
      globalEmotionController.setExpression('THINKING');
    } else if (state === 'executing') {
      globalEmotionController.setExpression('FOCUSED');
      globalGestureController.triggerGesture('command_gesture', 1.8);
    } else if (state === 'listening') {
      globalEmotionController.setExpression('LISTENING');
    } else if (state === 'speaking') {
      globalEmotionController.setExpression('SPEAKING');
    } else {
      globalEmotionController.setExpression('NEUTRAL');
    }
  }, [state, theme, userLevel, assistantLevel, isMuted, audioPlayer, cameraPreset]);

  useEffect(() => {
    const unsubExp = globalEmotionController.subscribe(setActiveExpression);

    const handleCameraEvent = (e: any) => {
      const preset = e?.detail?.preset as CameraPreset3D;
      if (preset && ['portrait', 'close_up', 'upper_body', 'cinematic'].includes(preset)) {
        setCameraPreset(preset);
      }
    };
    window.addEventListener('n3k:camera3d:preset', handleCameraEvent);

    return () => {
      unsubExp();
      window.removeEventListener('n3k:camera3d:preset', handleCameraEvent);
    };
  }, []);

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer;
    try {
      const isMobile = window.innerWidth < 768;
      renderer = new THREE.WebGLRenderer({
        antialias: !isMobile,
        alpha: true,
        powerPreference: 'high-performance',
      });
      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, isMobile ? 1.5 : 2));
      renderer.setSize(container.clientWidth || 520, container.clientHeight || 560);
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.15;
      container.innerHTML = '';
      container.appendChild(renderer.domElement);
      globalErrorCenterManager.set3DStatus(true, true, true);
    } catch (e) {
      console.error('[N3kAvatar3D] WebGL initialization failed:', e);
      globalErrorCenterManager.set3DStatus(false, false, false);
      return;
    }

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      32,
      (container.clientWidth || 520) / (container.clientHeight || 560),
      0.1,
      50,
    );
    camera.position.set(0, 0.38, 3.35);

    // Lighting matching the user's anime male reference (deep midnight blue + luminous cyan/blue rim & key lights)
    const ambientLight = new THREE.AmbientLight(0x1e2b58, 1.45);
    scene.add(ambientLight);

    const keyLight = new THREE.DirectionalLight(0xdbeafe, 1.85);
    keyLight.position.set(1.4, 2.2, 2.8);
    scene.add(keyLight);

    const cyanRimLightLeft = new THREE.PointLight(0x00e5ff, 3.8, 7);
    cyanRimLightLeft.position.set(-1.6, 0.9, -0.6);
    scene.add(cyanRimLightLeft);

    const blueRimLightRight = new THREE.PointLight(0x3b82f6, 3.6, 7);
    blueRimLightRight.position.set(1.6, 0.8, -0.5);
    scene.add(blueRimLightRight);

    const jacketGlowLight = new THREE.PointLight(0x00d8ff, 2.4, 4.5);
    jacketGlowLight.position.set(0, -0.35, 1.2);
    scene.add(jacketGlowLight);

    // Root Character Group
    const characterRoot = new THREE.Group();
    // Keep the legacy procedural rig in the codebase for compatibility, but do not
    // display it as a substitute for the user's actual N3k VRM. The real VRM must
    // either load successfully or the Error Center must report the failure.
    characterRoot.visible = false;
    scene.add(characterRoot);

    // Maps N3k's 26 internal expressions onto the VRM's standard emotion presets
    // (neutral / happy / angry / sad / relaxed / surprised). Multiple internal
    // expressions can share a preset; the actual N3k identity/personality still
    // comes from EmotionController — this only picks the closest VRM face shape.
    const VRM_EXPRESSION_MAP: Record<N3kExpression, string> = {
      NEUTRAL: 'neutral',
      HAPPY: 'happy',
      SMILE: 'happy',
      LAUGH: 'happy',
      EXCITED: 'happy',
      PROUD: 'happy',
      RELIEVED: 'happy',
      PLAYFUL: 'happy',
      SAD: 'sad',
      CRYING: 'sad',
      WORRIED: 'sad',
      NERVOUS: 'sad',
      BORED: 'relaxed',
      TIRED: 'relaxed',
      THINKING: 'relaxed',
      FOCUSED: 'relaxed',
      LISTENING: 'relaxed',
      SPEAKING: 'neutral',
      CURIOUS: 'surprised',
      SURPRISED: 'surprised',
      SHOCKED: 'surprised',
      CONFUSED: 'surprised',
      ANGRY: 'angry',
      ANNOYED: 'angry',
      SUSPICIOUS: 'angry',
      SERIOUS: 'neutral',
      ERROR: 'angry',
    };
    const vrmExpressionWeights: Record<string, number> = {
      neutral: 1,
      happy: 0,
      sad: 0,
      angry: 0,
      relaxed: 0,
      surprised: 0,
    };

    // Real rigged model loader: tries a VRM first (full humanoid rig + expressions,
    // e.g. exported from VRoid Studio/VRoid Mobile), then a plain GLB, and falls back
    // to the built-in procedural rig if neither file is present.
    let gltfMixer: THREE.AnimationMixer | null = null;
    let currentVrm: VRM | null = null;
    const loader = new GLTFLoader();
    loader.register((parser) => new VRMLoaderPlugin(parser));

    const loadPlainGlb = () => {
      const plainLoader = new GLTFLoader();
      plainLoader.load(
        '/models/n3k/n3k.glb',
        (gltf) => {
          if (gltf && gltf.scene) {
            gltf.scene.position.set(0, -1.1, 0);
            scene.add(gltf.scene);
            characterRoot.visible = false;
            if (gltf.animations && gltf.animations.length > 0) {
              gltfMixer = new THREE.AnimationMixer(gltf.scene);
              gltfMixer.clipAction(gltf.animations[0]).play();
            }
            console.log('[N3kAvatar3D] Loaded plain GLB from /models/n3k/n3k.glb.');
          }
        },
        undefined,
        (err) => {
          // No file at either path is expected/normal — the procedural rig is the
          // intended visual in that case, not a failure of a real model to load.
          console.log(
            '[N3kAvatar3D] No /models/n3k/n3k.vrm or n3k.glb found — using the built-in procedural rig.',
            err,
          );
        },
      );
    };

    loader.load(
      '/models/n3k/n3k.vrm',
      (gltf) => {
        const vrm = gltf.userData.vrm as VRM | undefined;
        if (vrm) {
          VRMUtils.rotateVRM0(vrm); // VRM0 models face +Z; rotate to face the camera like VRM1
          vrm.scene.position.set(0, -1.1, 0);
          scene.add(vrm.scene);
          characterRoot.visible = false;
          currentVrm = vrm;
          globalErrorCenterManager.set3DStatus(true, true, true);
          const boneCount = vrm.humanoid ? Object.keys((vrm.humanoid as any).humanBones || {}).length : 0;
          const expressionNames = vrm.expressionManager
            ? Object.keys((vrm.expressionManager as any).expressionMap || {})
            : [];
          console.log(
            `[N3kAvatar3D] N3k VRM loaded from /models/n3k/n3k.vrm — ${boneCount} humanoid bones, expressions: [${expressionNames.join(', ')}].`,
          );
        } else if (gltf.scene) {
          // A plain (non-VRM) .glb was placed at the .vrm path — still handle it gracefully.
          gltf.scene.position.set(0, -1.1, 0);
          scene.add(gltf.scene);
          characterRoot.visible = false;
          if (gltf.animations && gltf.animations.length > 0) {
            gltfMixer = new THREE.AnimationMixer(gltf.scene);
            gltfMixer.clipAction(gltf.animations[0]).play();
          }
          globalErrorCenterManager.set3DStatus(true, true, true);
          console.log('[N3kAvatar3D] Loaded a non-VRM model from /models/n3k/n3k.vrm.');
        } else {
          console.error('[N3kAvatar3D] n3k.vrm loaded but contained no scene/VRM data — check the file.');
          globalErrorCenterManager.set3DStatus(true, false, false);
          loadPlainGlb();
        }
      },
      undefined,
      (err) => {
        // Distinguish "file not found" (normal — try the GLB path next) from a real
        // parse/runtime failure on an existing file, which we surface loudly rather
        // than silently swapping in the procedural character.
        const message = err instanceof Error ? err.message : String(err);
        const notFound = /404|Failed to fetch|NetworkError/i.test(message);
        if (notFound) {
          loadPlainGlb();
        } else {
          console.error('[N3kAvatar3D] N3k VRM failed to load/parse — this needs fixing, not a swap:', err);
          globalErrorCenterManager.set3DStatus(true, false, false);
          // Still fall back to the procedural rig so the screen isn't blank, but the
          // failure above is now visible in both devtools and the app's Error Center.
        }
      },
    );

    // =========================================================================
    // PROCEDURAL ARTICULATED 3D ANIME MALE MODEL (Matches Reference Image)
    // - Youthful anime facial proportions & sculpted chin/jaw
    // - Messy/wavy dark hair with luminous blue/cyan tips
    // - Glowing sapphire/cyan eyes with iris, pupil, specular highlights & eyelids
    // - Articulated eyebrows, jaw, upper/lower lips & mouth cavity for 17 visemes
    // - Luminous blue/cyan starlight hoodie/jacket over dark inner crew shirt
    // - Articulated neck, shoulders, arms & hands
    // =========================================================================

    const skinMat = new THREE.MeshStandardMaterial({
      color: 0xd8e0f2,
      roughness: 0.48,
      metalness: 0.05,
      emissive: 0x0b1536,
      emissiveIntensity: 0.25,
    });

    const darkInnerShirtMat = new THREE.MeshStandardMaterial({
      color: 0x050711,
      roughness: 0.85,
      metalness: 0.1,
    });

    const luminousJacketMat = new THREE.MeshStandardMaterial({
      color: 0x1d4ed8,
      emissive: 0x00b4ff,
      emissiveIntensity: 0.62,
      roughness: 0.28,
      metalness: 0.35,
    });

    const jacketTrimMat = new THREE.MeshStandardMaterial({
      color: 0x38bdf8,
      emissive: 0x00e5ff,
      emissiveIntensity: 1.15,
      roughness: 0.2,
      metalness: 0.5,
    });

    const darkHairMat = new THREE.MeshStandardMaterial({
      color: 0x090d1a,
      emissive: 0x0a1938,
      emissiveIntensity: 0.35,
      roughness: 0.38,
      metalness: 0.22,
    });

    // 1. Torso & Breathing Spine Group
    const spineGroup = new THREE.Group();
    spineGroup.position.set(0, -0.55, 0);
    characterRoot.add(spineGroup);

    // Dark Inner Crew-Neck Shirt
    const innerChestGeo = new THREE.CylinderGeometry(0.36, 0.32, 0.95, 24);
    innerChestGeo.scale(1.15, 1, 0.68);
    const innerChestMesh = new THREE.Mesh(innerChestGeo, darkInnerShirtMat);
    innerChestMesh.position.set(0, 0.02, 0);
    spineGroup.add(innerChestMesh);

    // Luminous Blue/Cyan Futuristic Open Hoodie Jacket (Left & Right Panels + Back + Glowing Hood)
    const jacketLeftGeo = new THREE.CylinderGeometry(0.41, 0.38, 0.98, 20, 1, false, 0.25, Math.PI * 0.88);
    jacketLeftGeo.scale(1.22, 1, 0.76);
    const jacketLeftMesh = new THREE.Mesh(jacketLeftGeo, luminousJacketMat);
    spineGroup.add(jacketLeftMesh);

    const jacketRightGeo = new THREE.CylinderGeometry(
      0.41,
      0.38,
      0.98,
      20,
      1,
      false,
      Math.PI * 0.87,
      Math.PI * 0.88,
    );
    jacketRightGeo.scale(1.22, 1, 0.76);
    const jacketRightMesh = new THREE.Mesh(jacketRightGeo, luminousJacketMat);
    spineGroup.add(jacketRightMesh);

    // Glowing Hoodie Collar / Hood behind neck
    const hoodGeo = new THREE.TorusGeometry(0.38, 0.13, 16, 32, Math.PI * 1.35);
    const hoodMesh = new THREE.Mesh(hoodGeo, luminousJacketMat);
    hoodMesh.position.set(0, 0.48, -0.05);
    hoodMesh.rotation.set(Math.PI * 0.42, 0, Math.PI * 0.82);
    spineGroup.add(hoodMesh);

    // Glowing Lapel Edges & Dark Hoodie Drawstrings (matching reference image)
    const lapelGeo = new THREE.BoxGeometry(0.035, 0.92, 0.04);
    const leftLapel = new THREE.Mesh(lapelGeo, jacketTrimMat);
    leftLapel.position.set(-0.14, 0.02, 0.27);
    leftLapel.rotation.z = -0.06;
    spineGroup.add(leftLapel);

    const rightLapel = new THREE.Mesh(lapelGeo, jacketTrimMat);
    rightLapel.position.set(0.14, 0.02, 0.27);
    rightLapel.rotation.z = 0.06;
    spineGroup.add(rightLapel);

    const strapGeo = new THREE.BoxGeometry(0.028, 0.52, 0.015);
    const leftStrap = new THREE.Mesh(strapGeo, darkInnerShirtMat);
    leftStrap.position.set(-0.22, 0.12, 0.3);
    spineGroup.add(leftStrap);

    const rightStrap = new THREE.Mesh(strapGeo, darkInnerShirtMat);
    rightStrap.position.set(0.22, 0.12, 0.3);
    spineGroup.add(rightStrap);

    // Starlight Sparkles Embedded on Jacket Surface
    const jacketSparkleCount = 140;
    const jacketSparklePos = new Float32Array(jacketSparkleCount * 3);
    for (let i = 0; i < jacketSparkleCount; i++) {
      const side = i % 2 === 0 ? 1 : -1;
      jacketSparklePos[i * 3] = side * (0.14 + Math.random() * 0.38);
      jacketSparklePos[i * 3 + 1] = -0.42 + Math.random() * 0.95;
      jacketSparklePos[i * 3 + 2] = 0.15 + Math.random() * 0.2;
    }
    const jacketSparkleGeo = new THREE.BufferGeometry();
    jacketSparkleGeo.setAttribute('position', new THREE.BufferAttribute(jacketSparklePos, 3));
    const jacketSparkleMat = new THREE.PointsMaterial({
      color: 0x7dd3fc,
      size: 0.028,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
    });
    const jacketSparkles = new THREE.Points(jacketSparkleGeo, jacketSparkleMat);
    spineGroup.add(jacketSparkles);

    // 2. Articulated Shoulders, Arms & Hands
    const createArmHierarchy = (isRight: boolean) => {
      const sign = isRight ? -1 : 1;
      const shoulderPivot = new THREE.Group();
      shoulderPivot.position.set(sign * 0.5, 0.36, 0);
      spineGroup.add(shoulderPivot);

      const upperArmGeo = new THREE.CylinderGeometry(0.11, 0.095, 0.48, 16);
      const upperArmMesh = new THREE.Mesh(upperArmGeo, luminousJacketMat);
      upperArmMesh.position.set(0, -0.22, 0);
      shoulderPivot.add(upperArmMesh);

      const elbowPivot = new THREE.Group();
      elbowPivot.position.set(0, -0.45, 0);
      shoulderPivot.add(elbowPivot);

      const forearmGeo = new THREE.CylinderGeometry(0.09, 0.075, 0.44, 16);
      const forearmMesh = new THREE.Mesh(forearmGeo, luminousJacketMat);
      forearmMesh.position.set(0, -0.2, 0.04);
      elbowPivot.add(forearmMesh);

      const wristPivot = new THREE.Group();
      wristPivot.position.set(0, -0.42, 0.06);
      elbowPivot.add(wristPivot);

      const handGeo = new THREE.SphereGeometry(0.075, 14, 14);
      handGeo.scale(0.85, 1.25, 0.55);
      const handMesh = new THREE.Mesh(handGeo, skinMat);
      wristPivot.add(handMesh);

      shoulderPivot.rotation.z = sign * -0.12;
      return { shoulderPivot, elbowPivot, wristPivot };
    };

    const rightArm = createArmHierarchy(true);
    const leftArm = createArmHierarchy(false);

    // 3. Neck & Head Hierarchy
    const neckGroup = new THREE.Group();
    neckGroup.position.set(0, 0.52, 0.02);
    spineGroup.add(neckGroup);

    const neckGeo = new THREE.CylinderGeometry(0.125, 0.145, 0.28, 20);
    const neckMesh = new THREE.Mesh(neckGeo, skinMat);
    neckMesh.position.set(0, 0.1, -0.02);
    neckGroup.add(neckMesh);

    const headGroup = new THREE.Group();
    headGroup.position.set(0, 0.26, 0.02);
    neckGroup.add(headGroup);

    // Youthful Anime Male Cranium & Sculpted V-Tapering Jaw/Chin
    const craniumGeo = new THREE.SphereGeometry(0.34, 32, 32);
    craniumGeo.scale(0.92, 1.06, 0.95);
    const craniumMesh = new THREE.Mesh(craniumGeo, skinMat);
    craniumMesh.position.set(0, 0.18, 0);
    headGroup.add(craniumMesh);

    const jawChinGeo = new THREE.ConeGeometry(0.27, 0.34, 4);
    jawChinGeo.rotateY(Math.PI / 4);
    jawChinGeo.scale(1.02, 1, 0.88);
    const jawChinMesh = new THREE.Mesh(jawChinGeo, skinMat);
    jawChinMesh.rotation.x = Math.PI;
    jawChinMesh.position.set(0, -0.02, 0.07);
    headGroup.add(jawChinMesh);

    // Nose Bridge
    const noseGeo = new THREE.ConeGeometry(0.026, 0.11, 4);
    const noseMesh = new THREE.Mesh(noseGeo, skinMat);
    noseMesh.position.set(0, 0.1, 0.33);
    noseMesh.rotation.x = 0.22;
    headGroup.add(noseMesh);

    // Ears
    const earGeo = new THREE.SphereGeometry(0.06, 12, 12);
    earGeo.scale(0.45, 1.3, 0.7);
    const earL = new THREE.Mesh(earGeo, skinMat);
    earL.position.set(-0.31, 0.12, 0.02);
    headGroup.add(earL);
    const earR = new THREE.Mesh(earGeo, skinMat);
    earR.position.set(0.31, 0.12, 0.02);
    headGroup.add(earR);

    // 4. Glowing Sapphire-Cyan Anime Eyes, Eyelids & Eyebrows
    const createAnimeEye = (isLeft: boolean) => {
      const sign = isLeft ? -1 : 1;
      const socketGroup = new THREE.Group();
      socketGroup.position.set(sign * 0.115, 0.155, 0.285);
      socketGroup.rotation.y = sign * -0.14;
      headGroup.add(socketGroup);

      // Sclera
      const scleraGeo = new THREE.SphereGeometry(0.058, 20, 20);
      scleraGeo.scale(1.28, 0.78, 0.45);
      const scleraMat = new THREE.MeshBasicMaterial({ color: 0xf1f5f9 });
      const scleraMesh = new THREE.Mesh(scleraGeo, scleraMat);
      socketGroup.add(scleraMesh);

      // Movable Iris + Pupil + Catchlight Group
      const irisGroup = new THREE.Group();
      irisGroup.position.set(0, 0, 0.022);
      socketGroup.add(irisGroup);

      const irisOuterGeo = new THREE.CircleGeometry(0.035, 24);
      const irisOuterMat = new THREE.MeshBasicMaterial({ color: 0x0284c7 });
      const irisOuter = new THREE.Mesh(irisOuterGeo, irisOuterMat);
      irisGroup.add(irisOuter);

      const irisGlowGeo = new THREE.CircleGeometry(0.026, 24);
      const irisGlowMat = new THREE.MeshBasicMaterial({ color: 0x00e5ff });
      const irisGlow = new THREE.Mesh(irisGlowGeo, irisGlowMat);
      irisGlow.position.z = 0.002;
      irisGroup.add(irisGlow);

      const pupilGeo = new THREE.CircleGeometry(0.013, 20);
      const pupilMat = new THREE.MeshBasicMaterial({ color: 0x020617 });
      const pupil = new THREE.Mesh(pupilGeo, pupilMat);
      pupil.position.z = 0.004;
      irisGroup.add(pupil);

      const highlightGeo = new THREE.CircleGeometry(0.0065, 12);
      const highlightMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const highlight = new THREE.Mesh(highlightGeo, highlightMat);
      highlight.position.set(0.011, 0.011, 0.006);
      irisGroup.add(highlight);

      // Upper Eyelid (for blinking & expression squint/droop)
      const upperLidGeo = new THREE.BoxGeometry(0.15, 0.055, 0.04);
      const upperLidMesh = new THREE.Mesh(upperLidGeo, skinMat);
      upperLidMesh.position.set(0, 0.052, 0.018);
      socketGroup.add(upperLidMesh);

      // Dark Anime Lash Line
      const lashGeo = new THREE.BoxGeometry(0.155, 0.012, 0.045);
      const lashMesh = new THREE.Mesh(lashGeo, darkHairMat);
      lashMesh.position.set(0, -0.025, 0.003);
      upperLidMesh.add(lashMesh);

      // Eyebrow
      const browGeo = new THREE.BoxGeometry(0.15, 0.016, 0.025);
      const browMesh = new THREE.Mesh(browGeo, darkHairMat);
      browMesh.position.set(sign * 0.115, 0.235, 0.305);
      headGroup.add(browMesh);

      return { socketGroup, irisGroup, irisGlowMat, upperLidMesh, browMesh };
    };

    const leftEye = createAnimeEye(true);
    const rightEye = createAnimeEye(false);

    // 5. Articulated 3D Mouth, Lips & Jaw for Real-Time 17-Viseme Lip Sync
    const mouthGroup = new THREE.Group();
    mouthGroup.position.set(0, 0.005, 0.305);
    headGroup.add(mouthGroup);

    const oralCavityGeo = new THREE.SphereGeometry(0.042, 16, 16);
    oralCavityGeo.scale(1.3, 0.7, 0.4);
    const oralCavityMat = new THREE.MeshBasicMaterial({ color: 0x1e1b4b });
    const oralCavityMesh = new THREE.Mesh(oralCavityGeo, oralCavityMat);
    oralCavityMesh.scale.set(1, 0.08, 1);
    mouthGroup.add(oralCavityMesh);

    const lipMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      emissive: 0x00b4ff,
      emissiveIntensity: 0.25,
      roughness: 0.4,
    });
    const upperLipGeo = new THREE.BoxGeometry(0.095, 0.011, 0.02);
    const upperLipMesh = new THREE.Mesh(upperLipGeo, lipMat);
    upperLipMesh.position.set(0, 0.006, 0.015);
    mouthGroup.add(upperLipMesh);

    const lowerLipMesh = new THREE.Mesh(upperLipGeo, lipMat);
    lowerLipMesh.position.set(0, -0.006, 0.015);
    mouthGroup.add(lowerLipMesh);

    // 6. Messy/Wavy Dark Anime Hair with Cyan-Blue Rim Strands (Matching Reference Image)
    const hairGroup = new THREE.Group();
    hairGroup.position.set(0, 0.22, 0);
    headGroup.add(hairGroup);

    const hairCrownGeo = new THREE.SphereGeometry(0.365, 24, 24);
    hairCrownGeo.scale(1.04, 1.05, 1.05);
    const hairCrown = new THREE.Mesh(hairCrownGeo, darkHairMat);
    hairCrown.position.set(0, 0.05, -0.03);
    hairGroup.add(hairCrown);

    // Generate 46 sculpted messy wavy anime hair locks around forehead, temples, crown, and sides
    const hairStrands: THREE.Mesh[] = [];
    for (let i = 0; i < 46; i++) {
      const isFrontBang = i < 16;
      const isCrownSpike = i >= 16 && i < 32;
      const len = isFrontBang ? 0.24 + (i % 4) * 0.04 : 0.28 + (i % 5) * 0.045;
      const radius = isFrontBang ? 0.048 : 0.062;

      const lockGeo = new THREE.ConeGeometry(radius, len, 6);
      const lockMesh = new THREE.Mesh(lockGeo, darkHairMat);

      if (isFrontBang) {
        // Forehead bangs falling down over eyebrows/eyes like the reference image
        const t = (i / 15) * 2 - 1; // -1 to +1 across forehead
        lockMesh.position.set(
          t * 0.26,
          0.06 - Math.abs(t) * 0.04,
          0.27 - Math.abs(t) * 0.08,
        );
        lockMesh.rotation.x = Math.PI * 0.88 + (Math.random() - 0.5) * 0.15;
        lockMesh.rotation.z = t * -0.28 + (Math.random() - 0.5) * 0.18;
      } else if (isCrownSpike) {
        // Messy wavy top & side locks
        const angle = ((i - 16) / 16) * Math.PI * 2;
        const r = 0.29;
        lockMesh.position.set(
          Math.cos(angle) * r,
          0.18 + (i % 3) * 0.05,
          Math.sin(angle) * r - 0.03,
        );
        lockMesh.rotation.z = -Math.cos(angle) * 0.85;
        lockMesh.rotation.x = Math.sin(angle) * 0.75;
      } else {
        // Sideburns / nape locks framing jaw
        const side = i % 2 === 0 ? 1 : -1;
        const idx = Math.floor((i - 32) / 2);
        lockMesh.position.set(
          side * (0.29 + (idx % 2) * 0.03),
          -0.02 - idx * 0.045,
          0.08 - idx * 0.04,
        );
        lockMesh.rotation.z = side * -0.35;
        lockMesh.rotation.x = Math.PI * 0.82;
      }

      hairGroup.add(lockMesh);
      hairStrands.push(lockMesh);
    }

    // 7. Ambient Floating Starlight Particles around N3k
    const ambientParticleCount = 90;
    const ambientPos = new Float32Array(ambientParticleCount * 3);
    for (let i = 0; i < ambientParticleCount; i++) {
      ambientPos[i * 3] = (Math.random() - 0.5) * 2.4;
      ambientPos[i * 3 + 1] = (Math.random() - 0.3) * 2.2;
      ambientPos[i * 3 + 2] = (Math.random() - 0.5) * 1.4;
    }
    const ambientParticlesGeo = new THREE.BufferGeometry();
    ambientParticlesGeo.setAttribute('position', new THREE.BufferAttribute(ambientPos, 3));
    const ambientParticlesMat = new THREE.PointsMaterial({
      color: 0x38bdf8,
      size: 0.032,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
    });
    const ambientParticles = new THREE.Points(ambientParticlesGeo, ambientParticlesMat);
    scene.add(ambientParticles);

    // Pointer Look-At tracking
    let pointerX = 0;
    let pointerY = 0;
    const handlePointerMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      if (!rect.width || !rect.height) return;
      pointerX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      pointerY = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
    };
    window.addEventListener('mousemove', handlePointerMove);

    // Resize Observer
    const handleResize = () => {
      if (!container) return;
      const w = container.clientWidth || 520;
      const h = container.clientHeight || 560;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener('resize', handleResize);

    // =========================================================================
    // LAYERED 60FPS ANIMATION LOOP
    // Layers: Base Idle -> Breathing -> Eye Gaze -> Blink -> Expression -> LipSync -> Gesture
    // =========================================================================
    let clock = new THREE.Clock();
    let animFrameId: number;
    let visemeThrottle = 0;

    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const delta = Math.min(0.1, clock.getDelta());
      const elapsed = clock.getElapsedTime();
      const currentProps = propsRef.current;
      const themeCfg = THEME_CONFIGS[currentProps.theme] || THEME_CONFIGS['cyber-cyan'];

      if (gltfMixer) {
        gltfMixer.update(delta);
      }

      // Camera Preset Smooth Interpolation
      let targetCamZ = 3.25;
      let targetCamY = 0.28;
      let targetCamX = 0;
      if (currentProps.cameraPreset === 'close_up') {
        targetCamZ = 2.35;
        targetCamY = 0.42;
      } else if (currentProps.cameraPreset === 'upper_body') {
        targetCamZ = 3.85;
        targetCamY = 0.15;
      } else if (currentProps.cameraPreset === 'cinematic') {
        targetCamZ = 3.1;
        targetCamY = 0.32;
        targetCamX = Math.sin(elapsed * 0.35) * 0.35;
      }
      camera.position.x += (targetCamX - camera.position.x) * delta * 3.5;
      camera.position.y += (targetCamY - camera.position.y) * delta * 3.5;
      camera.position.z += (targetCamZ - camera.position.z) * delta * 3.5;
      camera.lookAt(0, 0.25, 0);

      // Update Theme Rim Lighting
      cyanRimLightLeft.color.set(themeCfg.primary);
      jacketGlowLight.color.set(themeCfg.primary);

      // Layer 1 & 2 & 3 & 4: Idle Behavior + Breathing + Eye Gaze + Blink
      const idleOut = globalIdleBehaviorController.update(delta);

      // Layer 5: Smooth 27-Expression Morph Controller
      const expOut = globalEmotionController.updateBlendedWeights(delta);

      // Layer 6: Real-time 17-Viseme Lip Sync Controller
      const isSpeakingNow =
        currentProps.state === 'speaking' || currentProps.assistantLevel > 0.02;
      const visemeOut = globalVisemeController.updateFromAudio(
        currentProps.audioPlayer.getAnalyser(),
        isSpeakingNow,
        currentProps.assistantLevel,
        delta,
      );

      visemeThrottle += delta;
      if (visemeThrottle > 0.08) {
        visemeThrottle = 0;
        setActiveViseme(visemeOut.currentViseme);
      }

      // Layer 7: Skeletal Gesture Controller
      const gestureOut = globalGestureController.update(delta);

      if (currentVrm) {
        currentVrm.update(delta);

        const head = currentVrm.humanoid?.getNormalizedBoneNode('head');
        if (head) {
          const vrmYaw = pointerX * 0.16 + idleOut.headYawY + gestureOut.headShakeOffset;
          const vrmPitch =
            -pointerY * 0.1 + idleOut.headPitchX + expOut.headPitchX + gestureOut.headNodOffset;
          const vrmRoll = idleOut.headRollZ + expOut.headTiltZ;
          head.rotation.y += (vrmYaw - head.rotation.y) * Math.min(1, delta * 7);
          head.rotation.x += (vrmPitch - head.rotation.x) * Math.min(1, delta * 7);
          head.rotation.z += (vrmRoll - head.rotation.z) * Math.min(1, delta * 7);
        }
        const chest = currentVrm.humanoid?.getNormalizedBoneNode('chest');
        if (chest) {
          chest.position.y = idleOut.breathPhase * 0.006;
          chest.rotation.x = idleOut.breathPhase * 0.01;
        }

        const em = currentVrm.expressionManager;
        if (em) {
          em.setValue('blink', Math.min(1, Math.max(0, idleOut.blinkAmount)));

          const targetPreset = VRM_EXPRESSION_MAP[globalEmotionController.getExpression()] || 'neutral';
          for (const key of Object.keys(vrmExpressionWeights)) {
            const target = key === targetPreset ? 1 : 0;
            vrmExpressionWeights[key] += (target - vrmExpressionWeights[key]) * Math.min(1, delta * 4);
            em.setValue(key, vrmExpressionWeights[key]);
          }

          // Approximate the 5 standard VRM vowel visemes from the 17-viseme blend state.
          const { jawOpen, mouthWidth, mouthRound, lipPress } = visemeOut;
          const wide = Math.max(0, mouthWidth);
          em.setValue('aa', Math.min(1, jawOpen * (1 - mouthRound) * (1 - lipPress)));
          em.setValue('ih', Math.min(1, wide * (1 - mouthRound) * 0.8));
          em.setValue('ou', Math.min(1, mouthRound * (1 - lipPress)));
          em.setValue('ee', Math.min(1, wide * jawOpen * 0.5));
          em.setValue('oh', Math.min(1, mouthRound * jawOpen * 0.8));
        }
      }

      // Apply Breathing & Posture to Spine
      spineGroup.position.y = -0.55 + idleOut.breathPhase * 0.014;
      spineGroup.rotation.z = idleOut.torsoSwayX * 0.45;
      spineGroup.rotation.y = Math.sin(elapsed * 0.5) * 0.04;

      // Apply Head Look-At + Idle + Expression + Gesture
      const lookYaw = pointerX * 0.16 + idleOut.headYawY + gestureOut.headShakeOffset;
      const lookPitch =
        -pointerY * 0.1 +
        idleOut.headPitchX +
        expOut.headPitchX +
        gestureOut.headNodOffset;
      const lookRoll = idleOut.headRollZ + expOut.headTiltZ;

      headGroup.rotation.y += (lookYaw - headGroup.rotation.y) * Math.min(1, delta * 7);
      headGroup.rotation.x += (lookPitch - headGroup.rotation.x) * Math.min(1, delta * 7);
      headGroup.rotation.z += (lookRoll - headGroup.rotation.z) * Math.min(1, delta * 7);

      // Apply Eye Gaze & Specular Glow
      const eyeTargetX = Math.max(-0.014, Math.min(0.014, (pointerX * 0.35 + idleOut.eyeOffsetX) * 0.022));
      const eyeTargetY = Math.max(-0.01, Math.min(0.01, (pointerY * 0.35 + idleOut.eyeOffsetY) * 0.016));
      leftEye.irisGroup.position.x = eyeTargetX;
      leftEye.irisGroup.position.y = eyeTargetY;
      rightEye.irisGroup.position.x = eyeTargetX;
      rightEye.irisGroup.position.y = eyeTargetY;

      // Apply Eyelid Blink + Expression Droop/Wide
      const lidClose = Math.min(
        1,
        Math.max(0, idleOut.blinkAmount + expOut.eyelidDroop * 0.65 - expOut.eyeWide * 0.35),
      );
      const lidY = 0.052 - lidClose * 0.052;
      leftEye.upperLidMesh.position.y = lidY;
      rightEye.upperLidMesh.position.y = lidY;

      // Apply Eyebrow Expressions
      const browBaseY = 0.235 + expOut.browInnerUp * 0.022;
      leftEye.browMesh.position.y = browBaseY + expOut.browOuterUpL * 0.012;
      rightEye.browMesh.position.y = browBaseY + expOut.browOuterUpR * 0.012;
      leftEye.browMesh.rotation.z = -expOut.browInnerUp * 0.28 + expOut.browOuterUpL * 0.2;
      rightEye.browMesh.rotation.z = expOut.browInnerUp * 0.28 - expOut.browOuterUpR * 0.2;

      // Apply Real-Time Lip Sync + Facial Expression to 3D Mouth & Jaw
      const totalMouthOpen = Math.min(
        1,
        Math.max(expOut.mouthOpenBase, visemeOut.jawOpen * (1 - visemeOut.lipPress * 0.85)),
      );
      const mouthWidthScale =
        1 +
        expOut.mouthSmile * 0.28 +
        visemeOut.mouthWidth * 0.45 -
        visemeOut.mouthRound * 0.35;

      oralCavityMesh.scale.set(
        Math.max(0.45, mouthWidthScale),
        Math.max(0.06, totalMouthOpen * 1.35),
        1,
      );
      upperLipMesh.position.y = 0.006 + totalMouthOpen * 0.024 + expOut.mouthSmile * 0.006;
      lowerLipMesh.position.y = -0.006 - totalMouthOpen * 0.032 + expOut.mouthSmile * 0.004;
      upperLipMesh.scale.x = Math.max(0.5, mouthWidthScale);
      lowerLipMesh.scale.x = Math.max(0.5, mouthWidthScale);
      jawChinMesh.position.y = -0.02 - totalMouthOpen * 0.022;

      // Apply Skeletal Arm & Shoulder Gestures
      rightArm.shoulderPivot.rotation.x =
        gestureOut.rightShoulderPitch - idleOut.rightArmRaise * 0.35;
      rightArm.shoulderPivot.rotation.z = -0.12 + gestureOut.rightShoulderRoll;
      rightArm.elbowPivot.rotation.x = -gestureOut.rightElbowBend - idleOut.rightArmRaise * 0.4;
      rightArm.wristPivot.rotation.z = gestureOut.rightWristWave;

      leftArm.shoulderPivot.rotation.x = gestureOut.leftShoulderPitch;
      leftArm.shoulderPivot.rotation.z = 0.12 + gestureOut.leftShoulderRoll;
      leftArm.elbowPivot.rotation.x = -gestureOut.leftElbowBend;

      // Subtle Hair Wave Sway
      for (let i = 0; i < hairStrands.length; i++) {
        hairStrands[i].rotation.z += Math.sin(elapsed * 2.1 + i * 0.5) * 0.0008;
      }

      // Rotate & Pulse Starlight Particles
      ambientParticles.rotation.y = elapsed * 0.06;
      jacketSparkleMat.opacity =
        0.65 + Math.sin(elapsed * 3.2) * 0.25 + visemeOut.energyLevel * 0.3;

      renderer.render(scene, camera);
    };

    animFrameId = requestAnimationFrame(animate);

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
    };
  }, []);

  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  return (
    <div className="relative flex flex-col items-center justify-center w-full h-full max-h-[620px] select-none">
      {/* Ambient Cyan-Blue Aura Behind 3D Model */}
      <div
        className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full blur-3xl opacity-35 pointer-events-none transition-all duration-500"
        style={{
          background: `radial-gradient(circle, ${themeConfig.primary}55 0%, #1d4ed833 45%, transparent 72%)`,
          transform: `scale(${1 + Math.max(userLevel, assistantLevel) * 0.22})`,
        }}
      />

      {/* Interactive Real Three.js 3D Character Viewport */}
      <div
        ref={mountRef}
        onClick={onToggleConnect}
        title="Click N3k 3D Character to Connect / Toggle Voice"
        className="relative z-10 w-[320px] h-[360px] sm:w-[460px] sm:h-[460px] cursor-pointer"
      />

      {/* Clean Minimal Status & Expression/Viseme Telemetry Pill Under 3D Avatar */}
      <div className="relative z-20 -mt-3 flex flex-wrap items-center justify-center gap-2 px-3.5 py-1.5 rounded-full bg-[#060916]/85 border border-cyan-400/30 backdrop-blur-xl shadow-lg">
        <span
          className={`w-2 h-2 rounded-full ${
            state === 'error'
              ? 'bg-rose-400 animate-ping'
              : state === 'speaking'
                ? 'bg-cyan-300 animate-ping'
                : state === 'listening'
                  ? 'bg-emerald-400 animate-pulse'
                  : 'bg-cyan-400/70'
          }`}
        />
        <span className="font-mono text-[10px] font-bold tracking-widest uppercase text-slate-200">
          {state === 'disconnected' ? 'IDLE / STANDBY' : state.toUpperCase()}
        </span>
        <span className="text-slate-600">•</span>
        <span className="font-mono text-[10px] text-cyan-300">
          EXP: {activeExpression}
        </span>
        {activeViseme !== 'SIL' && (
          <>
            <span className="text-slate-600">•</span>
            <span className="font-mono text-[10px] text-emerald-300">
              VISEME: {activeViseme}
            </span>
          </>
        )}
      </div>

      {/* Quick 3D Expression & Gesture Micro-Selector Bar */}
      <div className="relative z-20 mt-2 flex items-center gap-1.5 overflow-x-auto max-w-[92vw] px-2 py-1 no-scrollbar">
        {(
          ['NEUTRAL', 'HAPPY', 'SMILE', 'THINKING', 'FOCUSED', 'PLAYFUL', 'SURPRISED', 'PROUD'] as N3kExpression[]
        ).map((exp) => (
          <button
            key={exp}
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              globalEmotionController.setExpression(exp, 6000);
            }}
            className={`px-2 py-0.5 rounded-full font-mono text-[9px] uppercase tracking-wider border transition-all shrink-0 ${
              activeExpression === exp
                ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                : 'bg-white/[0.03] border-white/10 text-slate-400 hover:text-slate-200'
            }`}
          >
            {exp}
          </button>
        ))}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            globalGestureController.triggerGesture('small_wave', 2.4);
          }}
          className="px-2 py-0.5 rounded-full font-mono text-[9px] uppercase tracking-wider border bg-blue-500/15 border-blue-400/30 text-blue-200 hover:bg-blue-500/25 shrink-0"
        >
          👋 Wave
        </button>
      </div>
    </div>
  );
};

export { ALL_N3K_EXPRESSIONS };
export type { N3kGestureType };
