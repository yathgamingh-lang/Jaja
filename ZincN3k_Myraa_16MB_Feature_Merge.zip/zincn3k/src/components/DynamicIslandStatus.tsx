import React, { useEffect, useState } from 'react';
import {
  Shield,
  Cpu,
  Mic,
  MicOff,
  Brain,
  Globe,
  Eye,
  Monitor,
  Settings,
  X,
  Power,
  Radio,
  Smartphone,
  Accessibility,
  KeyRound,
  Pause,
  Play,
  Laptop,
  Download,
  Sparkles,
  AlertTriangle,
  Gamepad2,
  Bell,
} from 'lucide-react';
import {
  AndroidPlatformCapabilities,
  AssistantState,
  AssistantTheme,
  ScreenShareState,
  VoicePersona,
} from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';
import { globalAndroidBridge } from '../modules/AndroidBridge.ts';
import { globalScreenCaptureManager } from '../modules/ScreenShareManager.ts';
import { globalWakeWordManager, WakeWordState } from '../modules/WakeWordManager.ts';
import { globalPcBridgeManager, PcBridgeState } from '../modules/PcBridgeManager.ts';
import { ConnectedDeviceInfo, globalDeviceManager } from '../modules/DeviceManager.ts';
import { globalNotificationManager, N3kNotificationItem } from '../modules/NotificationManager.ts';

interface DynamicIslandStatusProps {
  state: AssistantState;
  theme: AssistantTheme;
  userLevel: number;
  assistantLevel: number;
  isMuted: boolean;
  memoryCount: number;
  isBrowserOpen: boolean;
  isCameraVisionOpen: boolean;
  screenShareState: ScreenShareState;
  androidCapabilities: AndroidPlatformCapabilities;
  errorMessage: string | null;
  isCommandCenterOpen: boolean;
  activeVoice: VoicePersona;
  onToggleCommandCenter: () => void;
  onCloseCommandCenter: () => void;
  onToggleConnect: () => void;
  onToggleMute: () => void;
  onOpenBrain: () => void;
  onOpenGameHub?: () => void;
  onToggleBrowser: () => void;
  onToggleVision: () => void;
  onToggleScreenShare: () => void;
  onOpenPermissions: () => void;
  onExecuteQuickCommand: (cmd: string) => void;
}

export const DynamicIslandStatus: React.FC<DynamicIslandStatusProps> = ({
  state,
  theme,
  userLevel,
  assistantLevel,
  isMuted,
  memoryCount,
  isBrowserOpen,
  isCameraVisionOpen,
  screenShareState,
  androidCapabilities,
  errorMessage,
  isCommandCenterOpen,
  activeVoice,
  onToggleCommandCenter,
  onCloseCommandCenter,
  onToggleConnect,
  onToggleMute,
  onOpenBrain,
  onOpenGameHub,
  onToggleBrowser,
  onToggleVision,
  onToggleScreenShare,
  onOpenPermissions,
  onExecuteQuickCommand,
}) => {
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];
  const [wakeState, setWakeState] = useState<WakeWordState>(globalWakeWordManager.getState());
  const [pcState, setPcState] = useState<PcBridgeState>(globalPcBridgeManager.getState());
  const [devices, setDevices] = useState<ConnectedDeviceInfo[]>(globalDeviceManager.getDevices());
  const [notifications, setNotifications] = useState<N3kNotificationItem[]>(
    globalNotificationManager.getNotifications(),
  );

  useEffect(() => {
    const unsubWake = globalWakeWordManager.subscribe(setWakeState);
    const unsubPc = globalPcBridgeManager.subscribe(setPcState);
    const unsubDev = globalDeviceManager.subscribe(setDevices);
    const unsubNotif = globalNotificationManager.subscribe(setNotifications);
    return () => {
      unsubWake();
      unsubPc();
      unsubDev();
      unsubNotif();
    };
  }, []);

  const isScreenActive =
    (screenShareState.status === 'active' || screenShareState.status === 'paused') &&
    screenShareState.isSharing;
  const isScreenPaused = Boolean(screenShareState.isPaused || screenShareState.status === 'paused');

  const hasError = Boolean(errorMessage) || state === 'error';

  // Determine exact Dynamic Island text as required by N3k V4 specification
  let islandLabel = 'N3k — CC';
  if (hasError) {
    islandLabel = 'N3k — Error';
  } else if (state === 'executing') {
    islandLabel = 'N3k — Executing';
  } else if (state === 'speaking') {
    islandLabel = 'N3k — Speaking';
  } else if (state === 'thinking' || state === 'connecting') {
    islandLabel = 'N3k — Thinking';
  } else if (isScreenActive && state === 'disconnected') {
    islandLabel = 'N3k — Screen Active';
  } else if (state === 'listening') {
    islandLabel = 'N3k — Listening';
  } else if (wakeState.isListening) {
    islandLabel = 'N3k — Wake Active';
  }

  const isOnline = state !== 'disconnected';
  const activeAudioLevel = state === 'speaking' ? assistantLevel : userLevel;

  const handleTogglePauseScreen = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isScreenPaused) {
      globalScreenCaptureManager.resume();
    } else {
      globalScreenCaptureManager.pause();
    }
  };

  const handleOpenAccessibility = () => {
    if (androidCapabilities.isAndroidNative) {
      globalAndroidBridge.openAccessibilitySettings();
    } else {
      onCloseCommandCenter();
      onOpenPermissions();
    }
  };

  return (
    <>
      {/* PC Destructive Action Confirmation Guard Modal */}
      {pcState.pendingDangerAction && (
        <div className="fixed inset-0 z-[95] bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl bg-[#090d1e] border border-rose-500/50 p-5 shadow-[0_0_50px_rgba(244,63,94,0.35)] text-slate-100 font-mono">
            <div className="flex items-center gap-3 mb-3">
              <div className="p-2.5 rounded-xl bg-rose-500/20 border border-rose-500/40 text-rose-400">
                <AlertTriangle className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                  Confirm PC {pcState.pendingDangerAction.action.toUpperCase()}
                </h3>
                <p className="text-[11px] text-rose-300">
                  N3k Safety Protocol — Explicit Confirmation Required
                </p>
              </div>
            </div>
            <p className="text-xs text-slate-300 mb-5 leading-relaxed">
              Are you sure you want N3k to{' '}
              <span className="text-white font-bold uppercase">
                {pcState.pendingDangerAction.action}
              </span>{' '}
              your connected PC ({pcState.telemetry?.hostname || 'Workstation'})?
            </p>
            <div className="flex items-center justify-end gap-2.5">
              <button
                onClick={() => globalPcBridgeManager.cancelPendingDangerAction()}
                className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 text-xs text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={() => globalPcBridgeManager.confirmPendingDangerAction()}
                className="px-4 py-2 rounded-xl bg-rose-500/25 hover:bg-rose-500/40 border border-rose-400 text-xs font-bold text-rose-200"
              >
                Confirm {pcState.pendingDangerAction.action.toUpperCase()}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Fixed Top-Center Dynamic Island */}
      <div className="fixed top-3 left-1/2 -translate-x-1/2 z-50 pointer-events-auto select-none flex flex-col items-center">
        <div
          onClick={onToggleCommandCenter}
          role="button"
          tabIndex={0}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') onToggleCommandCenter();
          }}
          aria-expanded={isCommandCenterOpen}
          aria-label="N3k Dynamic Island Command Center"
          className={`group relative flex items-center gap-3 px-5 py-2 rounded-full border backdrop-blur-2xl transition-all duration-300 cursor-pointer ${
            hasError
              ? 'bg-rose-950/90 border-rose-400/70 shadow-[0_0_28px_rgba(244,63,94,0.45)]'
              : isCommandCenterOpen
                ? 'bg-[#081028]/95 border-cyan-300 shadow-[0_0_32px_rgba(0,229,255,0.45)] scale-[1.02]'
                : state === 'speaking'
                  ? 'bg-[#070d22]/90 border-cyan-400/75 shadow-[0_0_25px_rgba(0,229,255,0.4)]'
                  : state === 'thinking' || state === 'connecting'
                    ? 'bg-[#110a26]/90 border-purple-400/70 shadow-[0_0_24px_rgba(168,85,247,0.35)]'
                    : isScreenActive
                      ? 'bg-[#06181c]/90 border-emerald-400/70 shadow-[0_0_24px_rgba(16,185,129,0.35)]'
                      : state === 'listening'
                        ? 'bg-[#070d22]/90 border-cyan-400/60 shadow-[0_0_20px_rgba(0,229,255,0.3)]'
                        : 'bg-[#060814]/90 border-cyan-400/40 hover:border-cyan-300/80 shadow-[0_6px_28px_rgba(0,0,0,0.75),0_0_15px_rgba(0,229,255,0.18)]'
          }`}
        >
          {/* Ambient Holographic Halo */}
          <div
            className="absolute inset-0 rounded-full opacity-35 pointer-events-none blur-md transition-opacity group-hover:opacity-65"
            style={{ background: themeConfig.bgGlow }}
          />

          {/* Status Pulse Dot / Core Icon */}
          <div className="relative flex items-center justify-center">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                hasError
                  ? 'bg-rose-400 animate-ping'
                  : state === 'speaking'
                    ? 'bg-cyan-300 animate-ping'
                    : state === 'thinking' || state === 'connecting'
                      ? 'bg-purple-400 animate-spin'
                      : isScreenActive
                        ? 'bg-emerald-400 animate-pulse'
                        : state === 'listening' || wakeState.isListening
                          ? 'bg-cyan-400 animate-pulse'
                          : 'bg-cyan-400/80'
              }`}
              style={{
                boxShadow: hasError
                  ? '0 0 10px #f43f5e'
                  : `0 0 10px ${themeConfig.primary}`,
              }}
            />
          </div>

          {/* Primary Dynamic Island Text */}
          <span className="font-mono text-xs sm:text-sm font-extrabold tracking-wider text-white whitespace-nowrap drop-shadow-[0_0_8px_rgba(0,229,255,0.4)]">
            {islandLabel}
          </span>

          {/* Secondary Screen Active Pill when simultaneously Listening/Speaking */}
          {isScreenActive && islandLabel !== 'N3k — Screen Active' && (
            <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-[9px] font-mono font-bold text-emerald-300">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              {isScreenPaused ? 'PAUSED' : 'SCREEN'}
            </span>
          )}

          {/* Live Audio Reactive Micro-Bars when active */}
          {isOnline && (
            <div className="flex items-center gap-0.5 h-3.5 pl-1">
              {[0.7, 1.2, 0.9, 1.4, 0.8].map((mult, idx) => (
                <span
                  key={idx}
                  className="w-0.5 rounded-full transition-all duration-75"
                  style={{
                    backgroundColor: themeConfig.primary,
                    height: `${Math.max(3, Math.min(14, activeAudioLevel * 16 * mult + 3))}px`,
                  }}
                />
              ))}
            </div>
          )}

          {/* CC Badge Button */}
          <span
            className="ml-1 px-2 py-0.5 rounded-full text-[10px] font-mono font-black tracking-widest uppercase border transition-all"
            style={{
              backgroundColor: isCommandCenterOpen
                ? themeConfig.primary
                : `${themeConfig.primary}20`,
              color: isCommandCenterOpen ? '#04060e' : themeConfig.primary,
              borderColor: `${themeConfig.primary}60`,
            }}
          >
            CC
          </span>
        </div>
      </div>

      {/* Expanded Holographic Command Center (CC) Overlay */}
      {isCommandCenterOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/65 backdrop-blur-md flex items-start justify-center pt-16 px-4 pb-8 overflow-y-auto animate-in fade-in duration-200 select-none"
          onClick={(e) => {
            if (e.target === e.currentTarget) onCloseCommandCenter();
          }}
        >
          <div className="relative w-full max-w-2xl rounded-3xl bg-[#070b18]/95 border border-cyan-400/40 shadow-[0_0_60px_rgba(0,229,255,0.22)] p-5 sm:p-6 text-slate-100 font-mono animate-in zoom-in-95 duration-200">
            {/* Subtle top cyan line glow */}
            <div
              className="absolute inset-x-10 top-0 h-[2px] rounded-full"
              style={{
                background: `linear-gradient(90deg, transparent, ${themeConfig.primary}, transparent)`,
              }}
            />

            {/* Header */}
            <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20">
              <div className="flex items-center gap-3">
                <div
                  className="w-10 h-10 rounded-2xl flex items-center justify-center border border-cyan-400/40"
                  style={{
                    backgroundColor: `${themeConfig.primary}20`,
                    boxShadow: `0 0 20px ${themeConfig.glow}`,
                  }}
                >
                  <Shield className="w-5 h-5" style={{ color: themeConfig.primary }} />
                </div>
                <div>
                  <h2 className="text-sm sm:text-base font-black tracking-widest text-white uppercase">
                    N3k COMMAND CENTER
                  </h2>
                  <p className="text-[10px] text-cyan-300/80 tracking-wider">
                    MOBILE + PC JARVIS SUBSYSTEM DIAGNOSTICS
                  </p>
                </div>
              </div>
              <button
                onClick={onCloseCommandCenter}
                className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 border border-white/10 hover:border-rose-400/40 text-slate-300 hover:text-rose-300 transition-all"
                title="Close Command Center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Subsystem Status Matrix */}
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* 1. AI CORE */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25">
                <div className="flex items-center gap-2.5">
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  <div>
                    <div className="text-xs font-bold text-white">AI CORE</div>
                    <div className="text-[10px] text-slate-400">Gemini Live Neural Bridge</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span
                    className={`flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                      isOnline
                        ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300'
                        : 'bg-cyan-500/15 border-cyan-400/30 text-cyan-300'
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        isOnline ? 'bg-emerald-400 animate-pulse' : 'bg-cyan-400'
                      }`}
                    />
                    {isOnline ? 'ONLINE' : 'READY'}
                  </span>
                  <button
                    onClick={onToggleConnect}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-cyan-500/20 border border-white/10 text-xs text-cyan-300"
                    title={isOnline ? 'Disconnect AI Core' : 'Connect AI Core'}
                  >
                    <Power className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* 2. VOICE */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25">
                <div className="flex items-center gap-2.5">
                  {isMuted ? (
                    <MicOff className="w-4 h-4 text-rose-400" />
                  ) : (
                    <Mic className="w-4 h-4 text-cyan-400" />
                  )}
                  <div>
                    <div className="text-xs font-bold text-white">VOICE</div>
                    <div className="text-[10px] text-slate-400">
                      Persona: {activeVoice} (24kHz)
                    </div>
                  </div>
                </div>
                <button
                  onClick={onToggleMute}
                  className={`flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full border transition-all ${
                    isMuted
                      ? 'bg-rose-500/20 border-rose-400/40 text-rose-300'
                      : isOnline
                        ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300'
                        : 'bg-cyan-500/15 border-cyan-400/30 text-cyan-300'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isMuted ? 'bg-rose-400' : 'bg-emerald-400'
                    }`}
                  />
                  {isMuted ? 'MUTED' : isOnline ? state.toUpperCase() : 'READY'}
                </button>
              </div>

              {/* 3. WAKE WORD & AUTO-START */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25">
                <div className="flex items-center gap-2.5">
                  <Sparkles className="w-4 h-4 text-cyan-400" />
                  <div>
                    <div className="text-xs font-bold text-white">WAKE WORD (&ldquo;Hey N3k&rdquo;)</div>
                    <div className="text-[10px] text-slate-400 truncate max-w-[145px]">
                      {wakeState.statusMessage}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => globalWakeWordManager.setEnabled(!wakeState.isEnabled)}
                    className={`px-2.5 py-1 rounded-full text-[10px] font-bold border transition-all ${
                      wakeState.isEnabled
                        ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-200'
                        : 'bg-white/5 border-white/15 text-slate-300'
                    }`}
                  >
                    {wakeState.isEnabled ? 'ON' : 'OFF'}
                  </button>
                  <button
                    onClick={() => globalWakeWordManager.setAutoStart(!wakeState.autoStartEnabled)}
                    className={`px-2 py-1 rounded-full text-[9px] font-bold border transition-all ${
                      wakeState.autoStartEnabled
                        ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-200'
                        : 'bg-white/5 border-white/15 text-slate-400'
                    }`}
                    title="Auto-Start Wake Word & Assistant on Boot/Launch"
                  >
                    AUTO
                  </button>
                </div>
              </div>

              {/* 4. MEMORY */}
              <div
                onClick={() => {
                  onCloseCommandCenter();
                  onOpenBrain();
                }}
                className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25 hover:border-cyan-400/60 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2.5">
                  <Brain className="w-4 h-4 text-purple-400" />
                  <div>
                    <div className="text-xs font-bold text-white">MEMORY</div>
                    <div className="text-[10px] text-slate-400">
                      N3k Brain ({memoryCount} records)
                    </div>
                  </div>
                </div>
                <span className="flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full bg-emerald-500/15 border border-emerald-400/40 text-emerald-300">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  READY
                </span>
              </div>

              {/* 5. SCREEN VISION */}
              <div
                onClick={onToggleScreenShare}
                className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25 hover:border-cyan-400/60 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2.5">
                  <Monitor className="w-4 h-4 text-emerald-400" />
                  <div>
                    <div className="text-xs font-bold text-white">SCREEN VISION</div>
                    <div className="text-[10px] text-slate-400">
                      {isScreenActive
                        ? isScreenPaused
                          ? 'Paused (Tap Resume)'
                          : 'On-Demand Capture Active'
                        : 'Tap to Share Screen'}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  {isScreenActive && (
                    <button
                      onClick={handleTogglePauseScreen}
                      className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-amber-300"
                      title={isScreenPaused ? 'Resume Screen Vision' : 'Pause Screen Vision'}
                    >
                      {isScreenPaused ? (
                        <Play className="w-3 h-3" />
                      ) : (
                        <Pause className="w-3 h-3" />
                      )}
                    </button>
                  )}
                  <span
                    className={`flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                      isScreenActive
                        ? isScreenPaused
                          ? 'bg-amber-500/20 border-amber-400/50 text-amber-200'
                          : 'bg-emerald-500/25 border-emerald-400 text-emerald-200 shadow-[0_0_12px_rgba(16,185,129,0.35)]'
                        : 'bg-slate-800/80 border-white/15 text-slate-300'
                    }`}
                  >
                    <span
                      className={`w-2 h-2 rounded-full ${
                        isScreenActive
                          ? isScreenPaused
                            ? 'bg-amber-400'
                            : 'bg-emerald-400 animate-ping'
                          : 'bg-slate-400'
                      }`}
                    />
                    {isScreenActive ? (isScreenPaused ? 'PAUSED' : 'ACTIVE') : 'OFF'}
                  </span>
                </div>
              </div>

              {/* 6. ANDROID CONTROL */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25">
                <div className="flex items-center gap-2.5">
                  <Smartphone className="w-4 h-4 text-cyan-400" />
                  <div>
                    <div className="text-xs font-bold text-white">ANDROID CONTROL</div>
                    <div className="text-[10px] text-slate-400 truncate max-w-[150px]">
                      {androidCapabilities.isAndroidNative
                        ? `APK Bridge (${androidCapabilities.foregroundPackage})`
                        : 'Web HUD + APK Shell Ready'}
                    </div>
                  </div>
                </div>
                <span
                  className={`flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                    androidCapabilities.isAndroidNative
                      ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300'
                      : 'bg-cyan-500/15 border-cyan-400/30 text-cyan-300'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      androidCapabilities.isAndroidNative ? 'bg-emerald-400' : 'bg-cyan-400'
                    }`}
                  />
                  {androidCapabilities.isAndroidNative ? 'NATIVE APK' : 'WEB HUD'}
                </span>
              </div>

              {/* 7. ACCESSIBILITY STATUS */}
              <div
                onClick={handleOpenAccessibility}
                className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25 hover:border-cyan-400/60 cursor-pointer transition-all"
              >
                <div className="flex items-center gap-2.5">
                  <Accessibility className="w-4 h-4 text-amber-400" />
                  <div>
                    <div className="text-xs font-bold text-white">ACCESSIBILITY STATUS</div>
                    <div className="text-[10px] text-slate-400">
                      {androidCapabilities.accessibilityEnabled
                        ? 'UI Tree & Text Entry Active'
                        : 'Tap to Configure Accessibility'}
                    </div>
                  </div>
                </div>
                <span
                  className={`flex items-center gap-1.5 text-[10px] font-bold px-2.5 py-1 rounded-full border ${
                    androidCapabilities.accessibilityEnabled
                      ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300'
                      : 'bg-amber-500/15 border-amber-400/40 text-amber-300'
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${
                      androidCapabilities.accessibilityEnabled ? 'bg-emerald-400' : 'bg-amber-400'
                    }`}
                  />
                  {androidCapabilities.accessibilityEnabled ? 'ENABLED' : 'SETUP'}
                </span>
              </div>

              {/* 8. SETTINGS & HOLOGRAPHIC MODULES */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25">
                <div className="flex items-center gap-2.5">
                  <Settings className="w-4 h-4 text-cyan-300" />
                  <div>
                    <div className="text-xs font-bold text-white">SETTINGS & HUD</div>
                    <div className="text-[10px] text-slate-400">Browser, Camera & Perms</div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      onCloseCommandCenter();
                      onToggleBrowser();
                    }}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-all flex items-center gap-1 ${
                      isBrowserOpen
                        ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                        : 'bg-white/5 border-white/15 text-slate-300 hover:text-white'
                    }`}
                    title="Toggle Holographic Browser"
                  >
                    <Globe className="w-3 h-3" />
                    <span>WEB</span>
                  </button>
                  <button
                    onClick={() => {
                      onCloseCommandCenter();
                      onToggleVision();
                    }}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-all flex items-center gap-1 ${
                      isCameraVisionOpen
                        ? 'bg-emerald-500/25 border-emerald-400 text-emerald-200'
                        : 'bg-white/5 border-white/15 text-slate-300 hover:text-white'
                    }`}
                    title="Toggle Optical Camera Vision"
                  >
                    <Eye className="w-3 h-3" />
                    <span>CAM</span>
                  </button>
                  <button
                    onClick={() => {
                      onCloseCommandCenter();
                      if (onOpenGameHub) onOpenGameHub();
                    }}
                    className="px-2 py-1 rounded-lg text-[10px] font-bold border bg-purple-500/20 border-purple-400/50 text-purple-200 hover:bg-purple-500/30 transition-all flex items-center gap-1"
                    title="Open N3k Game Hub"
                  >
                    <Gamepad2 className="w-3 h-3" />
                    <span>GAMES</span>
                  </button>
                  <button
                    onClick={() => {
                      onCloseCommandCenter();
                      onOpenPermissions();
                    }}
                    className="p-1.5 rounded-lg bg-white/5 hover:bg-cyan-500/20 border border-white/15 text-emerald-300"
                    title="Permissions & Android Setup"
                  >
                    <KeyRound className="w-3 h-3" />
                  </button>
                </div>
              </div>
            </div>

            {/* Connected Devices & Notifications Row */}
            <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {/* Connected Devices Matrix */}
              <div className="p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25">
                <div className="text-[10px] font-bold text-cyan-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>CONNECTED DEVICES ({devices.filter((d) => d.online).length}/{devices.length})</span>
                  <span>CROSS-DEVICE</span>
                </div>
                <div className="space-y-1.5">
                  {devices.map((dev) => (
                    <div
                      key={dev.id}
                      className="flex items-center justify-between text-[10px] px-2.5 py-1.5 rounded-xl bg-white/[0.03] border border-white/5"
                    >
                      <div className="truncate pr-2">
                        <span className="font-bold text-white">{dev.name}</span>
                        {dev.batteryPercent !== null && (
                          <span className="ml-1.5 text-slate-400">({dev.batteryPercent}%)</span>
                        )}
                      </div>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${
                          dev.online
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {dev.online ? 'ONLINE' : 'STANDBY'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* System Notifications Log */}
              <div className="p-3 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25 flex flex-col justify-between">
                <div className="text-[10px] font-bold text-cyan-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span className="flex items-center gap-1">
                    <Bell className="w-3 h-3 text-amber-400" />
                    <span>NOTIFICATIONS ({notifications.length})</span>
                  </span>
                  <button
                    onClick={() => globalNotificationManager.clearAll()}
                    className="text-[9px] text-slate-400 hover:text-white"
                  >
                    Clear
                  </button>
                </div>
                <div className="space-y-1 max-h-24 overflow-y-auto pr-1">
                  {notifications.slice(0, 4).map((n) => (
                    <div
                      key={n.id}
                      className="text-[10px] px-2 py-1 rounded-lg bg-white/[0.03] border border-white/5 truncate"
                    >
                      <span className="font-bold text-cyan-200">{n.title}: </span>
                      <span className="text-slate-400">{n.body}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* PC / Windows Companion Desktop Agent Section */}
            <div className="mt-4 p-3.5 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/30">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-white/10">
                <div className="flex items-center gap-2.5">
                  <Laptop className="w-4 h-4 text-cyan-400" />
                  <div>
                    <div className="text-xs font-bold text-white flex items-center gap-2">
                      <span>PC / WINDOWS COMPANION BRIDGE</span>
                      <span
                        className={`text-[9px] px-2 py-0.5 rounded-full border ${
                          pcState.status === 'connected'
                            ? 'bg-emerald-500/20 border-emerald-400/50 text-emerald-300'
                            : 'bg-amber-500/20 border-amber-400/50 text-amber-300'
                        }`}
                      >
                        {pcState.status === 'connected'
                          ? `CONNECTED (${pcState.latencyMs}ms)`
                          : 'OFFLINE'}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {pcState.telemetry
                        ? `${pcState.telemetry.hostname} · CPU ${pcState.telemetry.cpuUsagePercent}% · RAM ${pcState.telemetry.memoryUsedGb}/${pcState.telemetry.memoryTotalGb}GB · Active: ${pcState.telemetry.activeWindowTitle}`
                        : 'Connect to Windows PC Companion Agent for desktop automation'}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <a
                    href="/api/pc/download-agent"
                    download="n3k-pc-agent.mjs"
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-[10px] font-bold text-cyan-200 transition-all"
                    title="Download standalone Windows/PC Companion Agent script"
                  >
                    <Download className="w-3 h-3" />
                    <span>PC Agent</span>
                  </a>
                  <button
                    onClick={() => globalPcBridgeManager.refreshStatus()}
                    className="px-2.5 py-1 rounded-lg bg-white/5 hover:bg-white/10 border border-white/15 text-[10px] text-slate-300"
                  >
                    Sync
                  </button>
                </div>
              </div>

              {/* PC Quick Actions */}
              <div className="mt-2.5 flex flex-wrap gap-1.5">
                {[
                  {
                    label: 'PC: Open Chrome',
                    run: () => globalPcBridgeManager.executePcCommand('open_app', { appName: 'Chrome' }),
                  },
                  {
                    label: 'PC: Open VS Code',
                    run: () => globalPcBridgeManager.executePcCommand('open_app', { appName: 'VS Code' }),
                  },
                  {
                    label: 'PC: Open Spotify',
                    run: () => globalPcBridgeManager.executePcCommand('open_app', { appName: 'Spotify' }),
                  },
                  {
                    label: 'PC: Vol Up',
                    run: () => globalPcBridgeManager.executePcCommand('volume', { command: 'up' }),
                  },
                  {
                    label: 'PC: Play/Pause',
                    run: () => globalPcBridgeManager.executePcCommand('media', { command: 'play_pause' }),
                  },
                  {
                    label: 'PC: Lock Screen',
                    run: () => globalPcBridgeManager.executePcCommand('lock', {}),
                  },
                  {
                    label: 'PC: Shutdown (Confirm)',
                    run: () => globalPcBridgeManager.executePcCommand('shutdown', { confirmed: false }),
                  },
                ].map((btn, idx) => (
                  <button
                    key={idx}
                    onClick={btn.run}
                    className="px-2.5 py-1 rounded-lg bg-white/[0.04] hover:bg-cyan-500/20 border border-white/10 hover:border-cyan-400/40 text-[10px] text-slate-300 hover:text-cyan-200 transition-all"
                  >
                    {btn.label}
                  </button>
                ))}
              </div>
              {pcState.lastCommandStatus && (
                <div className="mt-2 text-[10px] text-cyan-300/90 truncate">
                  ▸ {pcState.lastCommandStatus}
                </div>
              )}
            </div>

            {/* Instant Voice / Android Tool Action Triggers inside CC */}
            <div className="mt-4 pt-3 border-t border-cyan-500/20">
              <div className="text-[10px] text-slate-400 uppercase tracking-wider mb-2.5 flex items-center justify-between">
                <span>N3k MOBILE & VOICE COMMAND PIPELINE</span>
                <span className="text-cyan-400">REAL TOOL EXECUTION</span>
              </div>
              <div className="flex flex-wrap gap-2">
                {[
                  { label: 'Open YouTube', cmd: 'Open YouTube' },
                  { label: 'Open Notes', cmd: 'Open Notes' },
                  { label: 'Open Chrome', cmd: 'Open Chrome' },
                  { label: 'Go Home', cmd: 'Go home' },
                  { label: 'Go Back', cmd: 'Go back' },
                  { label: 'Open Settings', cmd: 'Open settings' },
                  { label: 'Search YouTube: Minecraft', cmd: 'Search YouTube for Minecraft' },
                  { label: 'Write hello world in Notes', cmd: 'Write hello world in Notes' },
                  { label: 'What is on my screen?', cmd: 'What is on my screen?' },
                  { label: 'System Status', cmd: 'Check system status' },
                ].map((item, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      onExecuteQuickCommand(item.cmd);
                      onCloseCommandCenter();
                    }}
                    className="px-3 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/25 border border-cyan-400/30 text-[11px] text-cyan-200 hover:text-white transition-all active:scale-95 flex items-center gap-1.5"
                  >
                    <Radio className="w-3 h-3 text-cyan-400" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
