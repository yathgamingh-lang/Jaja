import React, { useEffect, useState } from 'react';
import {
  Gamepad2,
  X,
  Star,
  Play,
  Plus,
  Smartphone,
  Laptop,
  Clock,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';
import { GameItem, globalGameManager } from '../modules/GameManager.ts';

interface GameHubModalProps {
  isOpen: boolean;
  theme: AssistantTheme;
  onClose: () => void;
}

export const GameHubModal: React.FC<GameHubModalProps> = ({ isOpen, theme, onClose }) => {
  const [games, setGames] = useState<GameItem[]>(globalGameManager.getGames());
  const [filter, setFilter] = useState<'all' | 'favorites' | 'recent' | 'android' | 'windows'>('all');
  const [statusFeedback, setStatusFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newGameName, setNewGameName] = useState('');
  const [newGamePlatform, setNewGamePlatform] = useState<'android' | 'windows'>('windows');
  const [newGameTarget, setNewGameTarget] = useState('');

  useEffect(() => {
    const unsub = globalGameManager.subscribe(setGames);
    return () => unsub();
  }, []);

  if (!isOpen) return null;

  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  const filteredGames = games.filter((g) => {
    if (filter === 'favorites') return g.isFavorite;
    if (filter === 'recent') return Boolean(g.lastPlayedAt);
    if (filter === 'android') return g.platform === 'android' || g.platform === 'cross_platform';
    if (filter === 'windows') return g.platform === 'windows' || g.platform === 'cross_platform';
    return true;
  });

  const handleLaunch = async (game: GameItem) => {
    setStatusFeedback(null);
    const res = await globalGameManager.launchGame(game.name);
    setStatusFeedback({
      type: res.validationStatus === 'SUCCESS' ? 'success' : 'error',
      text: `[${res.validationStatus}] ${res.message}`,
    });
  };

  const handleAddGame = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGameName.trim() || !newGameTarget.trim()) return;
    globalGameManager.addCustomGame(newGameName, newGamePlatform, newGameTarget);
    setNewGameName('');
    setNewGameTarget('');
    setShowAddForm(false);
  };

  return (
    <div
      className="fixed inset-0 z-[88] bg-black/75 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-3xl max-h-[86vh] flex flex-col rounded-3xl bg-[#070b18]/95 border border-cyan-400/40 shadow-[0_0_60px_rgba(0,229,255,0.25)] p-5 sm:p-6 text-slate-100 font-mono overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20 shrink-0">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center border border-cyan-400/40"
              style={{
                backgroundColor: `${themeConfig.primary}20`,
                boxShadow: `0 0 20px ${themeConfig.glow}`,
              }}
            >
              <Gamepad2 className="w-5 h-5" style={{ color: themeConfig.primary }} />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black tracking-widest text-white uppercase">
                N3k GAME HUB
              </h2>
              <p className="text-[10px] text-cyan-300/80">
                ANDROID PACKAGE LAUNCHER & WINDOWS STEAM / EPIC / XBOX INTEGRATION
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-400/40 text-[10px] font-bold text-cyan-200 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Game</span>
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-rose-500/20 border border-white/10 text-slate-300 hover:text-rose-200 transition-all"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Filter Bar */}
        <div className="flex items-center justify-between gap-2 py-3 border-b border-white/10 overflow-x-auto no-scrollbar shrink-0">
          <div className="flex items-center gap-1.5">
            {(
              [
                { id: 'all', label: 'All Titles' },
                { id: 'favorites', label: '★ Favorites' },
                { id: 'recent', label: 'Recently Played' },
                { id: 'android', label: 'Android Games' },
                { id: 'windows', label: 'Windows / Steam / Epic' },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setFilter(tab.id)}
                className={`px-3 py-1 rounded-xl text-[10px] font-bold uppercase tracking-wider border transition-all whitespace-nowrap ${
                  filter === tab.id
                    ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200'
                    : 'bg-white/5 border-white/10 text-slate-400 hover:text-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
          <span className="hidden sm:inline text-[10px] text-slate-400">
            Voice: <span className="text-cyan-300">&ldquo;Launch Minecraft&rdquo;</span> or{' '}
            <span className="text-cyan-300">&ldquo;Open Steam&rdquo;</span>
          </span>
        </div>

        {/* Add Custom Game Form */}
        {showAddForm && (
          <form
            onSubmit={handleAddGame}
            className="mt-3 p-3.5 rounded-2xl bg-[#0b1229] border border-cyan-400/30 grid grid-cols-1 sm:grid-cols-4 gap-2.5 shrink-0"
          >
            <input
              type="text"
              value={newGameName}
              onChange={(e) => setNewGameName(e.target.value)}
              placeholder="Game Title (e.g. Valorant)"
              className="px-3 py-1.5 rounded-xl bg-black/60 border border-white/15 text-xs text-white focus:outline-none focus:border-cyan-400"
            />
            <select
              value={newGamePlatform}
              onChange={(e) => setNewGamePlatform(e.target.value as 'android' | 'windows')}
              className="px-3 py-1.5 rounded-xl bg-black/60 border border-white/15 text-xs text-white focus:outline-none focus:border-cyan-400"
            >
              <option value="windows">Windows PC</option>
              <option value="android">Android Mobile</option>
            </select>
            <input
              type="text"
              value={newGameTarget}
              onChange={(e) => setNewGameTarget(e.target.value)}
              placeholder="Package / URI (e.g. steam://rungameid/570)"
              className="px-3 py-1.5 rounded-xl bg-black/60 border border-white/15 text-xs text-white focus:outline-none focus:border-cyan-400"
            />
            <button
              type="submit"
              className="px-4 py-1.5 rounded-xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-xs transition-all"
            >
              Save Title
            </button>
          </form>
        )}

        {/* Status Banner */}
        {statusFeedback && (
          <div
            className={`mt-3 p-3 rounded-xl border text-xs flex items-center gap-2 shrink-0 ${
              statusFeedback.type === 'success'
                ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-950/60 border-rose-500/40 text-rose-200'
            }`}
          >
            {statusFeedback.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            )}
            <span>{statusFeedback.text}</span>
          </div>
        )}

        {/* Games Grid */}
        <div className="mt-3 flex-1 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 pr-1">
          {filteredGames.map((game) => (
            <div
              key={game.id}
              className="flex flex-col justify-between p-3.5 rounded-2xl bg-[#0b1024]/90 border border-cyan-500/25 hover:border-cyan-400/60 transition-all"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center text-lg">
                      {game.icon}
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white leading-snug">{game.name}</div>
                      <div className="text-[10px] text-slate-400">{game.genre}</div>
                    </div>
                  </div>
                  <button
                    onClick={() => globalGameManager.toggleFavorite(game.id)}
                    className={`p-1.5 rounded-lg transition-colors ${
                      game.isFavorite
                        ? 'text-amber-400 bg-amber-500/15'
                        : 'text-slate-500 hover:text-slate-300 bg-white/5'
                    }`}
                    title="Toggle Favorite"
                  >
                    <Star className="w-3.5 h-3.5 fill-current" />
                  </button>
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-1.5 text-[9px] text-slate-400">
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/5 border border-white/10 text-cyan-200 uppercase">
                    {game.platform === 'android' ? (
                      <Smartphone className="w-2.5 h-2.5" />
                    ) : (
                      <Laptop className="w-2.5 h-2.5" />
                    )}
                    {game.platform.replace('_', ' ')}
                  </span>
                  <span className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 uppercase">
                    {game.launcher.replace('_', ' ')}
                  </span>
                  {game.lastPlayedAt && (
                    <span className="inline-flex items-center gap-1 text-emerald-300">
                      <Clock className="w-2.5 h-2.5" />
                      Played
                    </span>
                  )}
                </div>
              </div>

              <button
                onClick={() => handleLaunch(game)}
                className="mt-3 w-full py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/35 border border-cyan-400/40 text-cyan-200 hover:text-white font-bold text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all active:scale-95"
              >
                <Play className="w-3.5 h-3.5" />
                <span>Launch Game</span>
              </button>
            </div>
          ))}
        </div>

        {/* Footer anti-cheat & security notice */}
        <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400 shrink-0">
          <span className="flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>N3k Safe Launch Protocol — Official OS PackageManager & Steam/Epic URI Intents only.</span>
          </span>
        </div>
      </div>
    </div>
  );
};
