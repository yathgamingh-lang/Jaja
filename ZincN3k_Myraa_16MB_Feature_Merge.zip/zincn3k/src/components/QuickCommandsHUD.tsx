import React, { useState } from 'react';
import {
  Bookmark,
  ChevronDown,
  Compass,
  Globe,
  Languages,
  MessageSquare,
  Radio,
  Sparkles,
  Terminal,
  Monitor,
  Music,
} from 'lucide-react';
import { AssistantState, AssistantTheme, SupportedLanguage } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface QuickCommandsHUDProps {
  state: AssistantState;
  theme: AssistantTheme;
  activeLanguage: SupportedLanguage;
  isOpen: boolean;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  onPromptSelect?: (prompt: string) => void;
}

const LANGUAGES: { id: SupportedLanguage; label: string; flag: string }[] = [
  { id: 'English', label: 'English', flag: 'EN' },
  { id: 'Hindi', label: 'हिन्दी', flag: 'HI' },
  { id: 'Hinglish', label: 'Hinglish', flag: 'IN' },
  { id: 'Punjabi', label: 'ਪੰਜਾਬੀ', flag: 'PB' },
  { id: 'Portuguese', label: 'Português', flag: 'PT' },
  { id: 'Russian', label: 'Русский', flag: 'RU' },
  { id: 'Chinese', label: '中文', flag: 'ZH' },
];

const QUICK_COMMANDS = [
  {
    title: 'Search AI News',
    prompt: 'Search Google for latest AI news.',
    icon: Globe,
  },
  {
    title: 'Search YouTube',
    prompt: 'Search YouTube for Minecraft videos.',
    icon: Terminal,
  },
  {
    title: 'Play Music',
    prompt: 'Play relaxing synthwave music on YouTube.',
    icon: Music,
  },
  {
    title: 'Share Screen',
    prompt: 'Share my screen with ZinxN3k.',
    icon: Monitor,
  },
  {
    title: 'Inspect Screen',
    prompt: 'What is currently displayed on my screen?',
    icon: Sparkles,
  },
  {
    title: 'Save Identity',
    prompt: 'Remember that my name is Yatharth.',
    icon: Bookmark,
  },
  {
    title: 'Check Memories',
    prompt: 'What do you remember about me so far?',
    icon: Compass,
  },
  {
    title: 'Who are you?',
    prompt: 'Who are you, ZinxN3k?',
    icon: MessageSquare,
  },
];

export const QuickCommandsHUD: React.FC<QuickCommandsHUDProps> = ({
  theme,
  activeLanguage,
  isOpen,
  onSelectLanguage,
  onPromptSelect,
}) => {
  const [showLanguageDropdown, setShowLanguageDropdown] = useState(false);
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  return (
    <aside
      className={`fixed top-18 right-4 z-20 w-72 max-w-[calc(100vw-2rem)] transition-all duration-300 pointer-events-auto ${
        isOpen
          ? 'opacity-100 translate-x-0'
          : 'opacity-0 translate-x-6 pointer-events-none lg:opacity-100 lg:translate-x-0 lg:pointer-events-auto'
      }`}
    >
      <div className="p-4 rounded-2xl bg-[#080b18]/85 border border-white/10 backdrop-blur-xl shadow-2xl space-y-3.5 text-xs font-mono select-none">
        {/* Panel Header */}
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4" style={{ color: themeConfig.primary }} />
            <span className="font-bold text-[11px] tracking-wider text-white uppercase">
              QUICK PROTOCOLS
            </span>
          </div>
          <span className="text-[10px] text-slate-400">VOICE TRIGGER</span>
        </div>

        {/* Language Selector */}
        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-[10px] text-slate-400">
            <span className="flex items-center gap-1">
              <Languages className="w-3 h-3 text-cyan-400" />
              VOICE LANGUAGE MATRIX
            </span>
            <button
              onClick={() => setShowLanguageDropdown(!showLanguageDropdown)}
              className="flex items-center gap-1 text-slate-200 hover:text-white px-2 py-0.5 rounded bg-white/5 border border-white/10 transition-colors"
            >
              <span className="font-bold" style={{ color: themeConfig.primary }}>
                {activeLanguage}
              </span>
              <ChevronDown className="w-3 h-3" />
            </button>
          </div>

          {/* Collapsible Language Grid */}
          {showLanguageDropdown && (
            <div className="grid grid-cols-2 gap-1.5 p-2 rounded-xl bg-slate-900/90 border border-white/10 animate-in fade-in duration-150">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.id}
                  onClick={() => {
                    onSelectLanguage(lang.id);
                    setShowLanguageDropdown(false);
                  }}
                  className={`px-2.5 py-1.5 rounded-lg text-left flex items-center justify-between text-[11px] transition-colors ${
                    activeLanguage === lang.id
                      ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/30'
                      : 'hover:bg-white/5 text-slate-300'
                  }`}
                >
                  <span>{lang.label}</span>
                  <span className="text-[9px] text-slate-500">{lang.flag}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Quick Voice Command Cards */}
        <div className="space-y-1.5">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">
            SPOKEN PROMPTS (SAY OUT LOUD)
          </div>
          <div className="space-y-1.5 max-h-56 overflow-y-auto pr-0.5">
            {QUICK_COMMANDS.map((cmd, idx) => {
              const Icon = cmd.icon;
              return (
                <div
                  key={idx}
                  onClick={() => onPromptSelect && onPromptSelect(cmd.prompt)}
                  className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-white/15 transition-all cursor-pointer group flex items-start gap-2.5"
                  title={`Say: "${cmd.prompt}"`}
                >
                  <Icon
                    className="w-3.5 h-3.5 mt-0.5 shrink-0 transition-transform group-hover:scale-110"
                    style={{ color: themeConfig.primary }}
                  />
                  <div className="space-y-0.5 flex-1 min-w-0">
                    <div className="text-[11px] font-bold text-slate-200 group-hover:text-white flex items-center justify-between">
                      <span>{cmd.title}</span>
                      <Radio className="w-2.5 h-2.5 opacity-0 group-hover:opacity-100 text-cyan-400" />
                    </div>
                    <p className="text-[10px] text-slate-400 truncate">"{cmd.prompt}"</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer tip */}
        <div className="pt-1 border-t border-white/5 text-[9px] text-slate-500 text-center">
          Tap avatar or arc core anytime to start conversation
        </div>
      </div>
    </aside>
  );
};
