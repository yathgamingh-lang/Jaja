import React from 'react';
import { Mic, MicOff, Power, Radio, Sparkles } from 'lucide-react';
import { AssistantState, AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface VoiceOrbProps {
  state: AssistantState;
  theme: AssistantTheme;
  userLevel: number;
  assistantLevel: number;
  isMuted: boolean;
  onToggleConnect: () => void;
}

export const VoiceOrb: React.FC<VoiceOrbProps> = ({
  state,
  theme,
  userLevel,
  assistantLevel,
  isMuted,
  onToggleConnect,
}) => {
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  const dynamicLevel =
    state === 'speaking' ? assistantLevel : state === 'listening' ? userLevel : 0;
  const pulseScale = 1 + dynamicLevel * 0.35;
  const ringScale1 = 1 + dynamicLevel * 0.6;
  const ringScale2 = 1 + dynamicLevel * 0.95;

  return (
    <div className="relative flex flex-col items-center justify-center select-none">
      {/* Outer ambient glow field */}
      <div
        className="absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full transition-all duration-700 pointer-events-none blur-3xl opacity-35"
        style={{
          background: themeConfig.bgGlow,
          transform: `scale(${state === 'speaking' ? 1.4 : state === 'listening' ? 1.2 : 1})`,
        }}
      />

      {/* Ripple Wave 2 (Expansive Sound Wave) */}
      {(state === 'speaking' || state === 'listening') && (
        <div
          className="absolute w-64 h-64 sm:w-80 sm:h-80 rounded-full border border-white/20 transition-transform duration-75 pointer-events-none animate-ping"
          style={{
            borderColor: themeConfig.primary,
            opacity: Math.max(0.1, dynamicLevel * 0.4),
            transform: `scale(${ringScale2})`,
            animationDuration: state === 'speaking' ? '1.8s' : '2.4s',
          }}
        />
      )}

      {/* Ripple Wave 1 (Inner Wave) */}
      {(state === 'speaking' || state === 'listening') && (
        <div
          className="absolute w-56 h-56 sm:w-72 sm:h-72 rounded-full border transition-transform duration-100 pointer-events-none"
          style={{
            borderColor: themeConfig.secondary,
            opacity: Math.max(0.2, dynamicLevel * 0.7),
            transform: `scale(${ringScale1})`,
            boxShadow: `0 0 24px ${themeConfig.glow}`,
          }}
        />
      )}

      {/* Connecting Cyber Orbit Rings */}
      {state === 'connecting' && (
        <>
          <div
            className="absolute w-56 h-56 sm:w-68 sm:h-68 rounded-full border-2 border-dashed animate-spin pointer-events-none"
            style={{
              borderColor: `${themeConfig.primary}88`,
              animationDuration: '6s',
            }}
          />
          <div
            className="absolute w-64 h-64 sm:w-76 sm:h-76 rounded-full border border-dotted animate-spin pointer-events-none"
            style={{
              borderColor: `${themeConfig.accent}55`,
              animationDirection: 'reverse',
              animationDuration: '10s',
            }}
          />
        </>
      )}

      {/* Main Interactive Orb Button */}
      <button
        onClick={onToggleConnect}
        className="group relative z-10 w-40 h-40 sm:w-48 sm:h-48 rounded-full flex flex-col items-center justify-center cursor-pointer transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-white/20 active:scale-95"
        style={{
          transform: `scale(${pulseScale})`,
          boxShadow:
            state === 'speaking'
              ? `0 0 50px ${themeConfig.glow}, inset 0 0 25px ${themeConfig.glow}`
              : state === 'listening'
                ? `0 0 35px ${themeConfig.glow}, inset 0 0 15px ${themeConfig.glow}`
                : state === 'connecting'
                  ? `0 0 30px ${themeConfig.glow}`
                  : '0 0 20px rgba(255,255,255,0.06)',
        }}
        aria-label={state === 'disconnected' ? 'Awaken ZINCN3K' : 'Disconnect'}
      >
        {/* Glassmorphic Core Surface */}
        <div
          className="absolute inset-0 rounded-full border transition-all duration-500 backdrop-blur-xl"
          style={{
            background:
              state === 'speaking'
                ? `radial-gradient(circle at 35% 30%, ${themeConfig.secondary}44, #080a14 75%)`
                : state === 'listening'
                  ? `radial-gradient(circle at 50% 50%, ${themeConfig.primary}25, #080a14 80%)`
                  : state === 'connecting'
                    ? `radial-gradient(circle at 50% 50%, #1e1b4b, #05060b 80%)`
                    : `radial-gradient(circle at 50% 50%, #121420, #06070c 85%)`,
            borderColor:
              state === 'speaking'
                ? themeConfig.primary
                : state === 'listening'
                  ? themeConfig.accent
                  : state === 'connecting'
                    ? '#818cf8'
                    : 'rgba(255, 255, 255, 0.12)',
          }}
        />

        {/* Dynamic Inner Fluid Light Core */}
        <div
          className={`absolute rounded-full transition-all duration-300 pointer-events-none ${
            state === 'speaking'
              ? 'w-24 h-24 sm:w-28 sm:h-28 opacity-80 animate-pulse'
              : state === 'listening'
                ? 'w-20 h-20 sm:w-24 sm:h-24 opacity-60'
                : state === 'connecting'
                  ? 'w-16 h-16 opacity-40 animate-ping'
                  : 'w-12 h-12 opacity-20'
          }`}
          style={{
            background: `radial-gradient(circle, ${themeConfig.primary} 0%, transparent 70%)`,
            filter: 'blur(8px)',
          }}
        />

        {/* Center Icons */}
        <div className="relative z-10 flex flex-col items-center justify-center text-white">
          {state === 'disconnected' && (
            <div className="flex flex-col items-center">
              <Power className="w-10 h-10 sm:w-12 sm:h-12 text-slate-400 group-hover:text-white transition-colors duration-300 drop-shadow-[0_0_12px_rgba(255,255,255,0.4)]" />
              <span className="text-[11px] font-mono tracking-widest text-slate-400 mt-2 uppercase font-medium group-hover:text-slate-200">
                START
              </span>
            </div>
          )}

          {state === 'connecting' && (
            <div className="flex flex-col items-center">
              <Radio
                className="w-10 h-10 sm:w-12 sm:h-12 animate-pulse"
                style={{ color: themeConfig.primary }}
              />
              <span className="text-[10px] font-mono tracking-widest mt-2 uppercase text-slate-300">
                LINKING...
              </span>
            </div>
          )}

          {state === 'listening' && (
            <div className="flex flex-col items-center">
              {isMuted ? (
                <MicOff className="w-10 h-10 sm:w-12 sm:h-12 text-rose-400" />
              ) : (
                <Mic
                  className="w-10 h-10 sm:w-12 sm:h-12 transition-transform"
                  style={{
                    color: themeConfig.primary,
                    transform: `scale(${1 + userLevel * 0.4})`,
                    filter: `drop-shadow(0 0 10px ${themeConfig.primary})`,
                  }}
                />
              )}
              <span className="text-[10px] font-mono tracking-widest mt-2 uppercase text-slate-300 font-semibold">
                {isMuted ? 'MUTED' : 'LISTENING'}
              </span>
            </div>
          )}

          {state === 'speaking' && (
            <div className="flex flex-col items-center">
              <Sparkles
                className="w-10 h-10 sm:w-12 sm:h-12 animate-spin"
                style={{
                  color: themeConfig.primary,
                  animationDuration: '8s',
                  filter: `drop-shadow(0 0 14px ${themeConfig.primary})`,
                  transform: `scale(${1 + assistantLevel * 0.4})`,
                }}
              />
              <span
                className="text-[10px] font-mono tracking-widest mt-2 uppercase font-bold"
                style={{ color: themeConfig.accent }}
              >
                SPEAKING
              </span>
            </div>
          )}
        </div>
      </button>

      {/* Real-time State Label Tag */}
      <div className="mt-8 flex items-center gap-2 px-3.5 py-1 rounded-full bg-slate-900/70 border border-white/10 backdrop-blur-md">
        <span
          className={`w-2 h-2 rounded-full ${
            state === 'speaking'
              ? 'animate-ping'
              : state === 'listening'
                ? 'animate-pulse'
                : state === 'connecting'
                  ? 'animate-bounce'
                  : 'bg-slate-600'
          }`}
          style={{
            backgroundColor:
              state === 'disconnected'
                ? '#64748b'
                : state === 'connecting'
                  ? '#a855f7'
                  : themeConfig.primary,
          }}
        />
        <span className="text-xs font-mono font-medium tracking-wider text-slate-300 uppercase">
          {state === 'disconnected' && 'Offline · Tap orb to activate'}
          {state === 'connecting' && 'Establishing Gemini Live session...'}
          {state === 'listening' && (isMuted ? 'Microphone muted' : 'Listening to you...')}
          {state === 'speaking' && 'ZINCN3K is speaking'}
        </span>
      </div>
    </div>
  );
};
