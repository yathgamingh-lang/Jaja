import React from 'react';
import { Activity, Brain, Cpu, Terminal, Shield, Globe, Monitor, MonitorOff } from 'lucide-react';
import { AssistantState, AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface HeaderHUDProps {
  state: AssistantState;
  theme: AssistantTheme;
  latencyMs: number;
  memoryCount: number;
  isTelemetryOpen?: boolean;
  isCommandsOpen?: boolean;
  isBrowserOpen?: boolean;
  isScreenSharing?: boolean;
  onToggleTelemetry?: () => void;
  onToggleCommands?: () => void;
  onOpenBrain: () => void;
  onToggleBrowser?: () => void;
  onToggleScreenShare?: () => void;
}

export const HeaderHUD: React.FC<HeaderHUDProps> = ({
  state,
  theme,
  latencyMs,
  memoryCount,
  isTelemetryOpen = false,
  isCommandsOpen = false,
  isBrowserOpen = false,
  isScreenSharing = false,
  onToggleTelemetry,
  onToggleCommands,
  onOpenBrain,
  onToggleBrowser,
  onToggleScreenShare,
}) => {
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  return (
    <header className="fixed top-0 left-0 right-0 z-30 px-3 sm:px-6 py-3 flex items-center justify-between pointer-events-none select-none bg-gradient-to-b from-[#05060b]/90 via-[#05060b]/40 to-transparent backdrop-blur-[2px]">
      {/* Brand Identity & Left Controls */}
      <div className="pointer-events-auto flex items-center gap-2.5">
        <div
          className="w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm tracking-wider shadow-lg backdrop-blur-xl border border-white/10 relative overflow-hidden"
          style={{
            backgroundColor: `${themeConfig.primary}20`,
            color: themeConfig.primary,
            boxShadow: `0 0 20px ${themeConfig.glow}`,
          }}
        >
          <Shield className="w-5 h-5 drop-shadow-[0_0_8px_currentColor]" />
          <div
            className="absolute inset-0 opacity-20 pointer-events-none"
            style={{
              background: `radial-gradient(circle, ${themeConfig.primary}, transparent)`,
            }}
          />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-extrabold tracking-widest text-sm sm:text-base text-white font-mono uppercase">
              ZINXN3K
            </h1>
            <span
              className="text-[9px] font-mono px-1.5 py-0.5 rounded font-semibold tracking-wider uppercase border border-cyan-400/20"
              style={{
                backgroundColor: `${themeConfig.primary}25`,
                color: themeConfig.primary,
              }}
            >
              QUANTUM LIVE
            </span>
          </div>
          <p className="text-[10px] font-mono text-slate-400 tracking-wider hidden sm:block">
            MALE AI COMPANION · PERSISTENT BRAIN
          </p>
        </div>

        {/* Telemetry Toggle Button (visible especially on mobile/tablet) */}
        {onToggleTelemetry && (
          <button
            onClick={onToggleTelemetry}
            className={`ml-2 lg:hidden px-2.5 py-1.5 rounded-xl border text-[11px] font-mono flex items-center gap-1.5 transition-all shadow-md ${
              isTelemetryOpen
                ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-900/80 border-white/10 text-slate-300 hover:text-white'
            }`}
            title="Toggle System Telemetry"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">STATS</span>
          </button>
        )}
      </div>

      {/* Right Controls: Quick Commands Toggle + Brain Button + Latency + State */}
      <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2">
        {/* Integrated Browser Pill */}
        {onToggleBrowser && (
          <button
            onClick={onToggleBrowser}
            className={`px-2.5 py-1.5 rounded-full border text-[11px] font-mono flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
              isBrowserOpen
                ? 'bg-cyan-500/25 border-cyan-400 text-cyan-300 shadow-[0_0_12px_rgba(0,229,255,0.4)]'
                : 'bg-slate-900/80 border-white/10 text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title="Integrated Web Browser & YouTube"
          >
            <Globe className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline font-bold">BROWSER</span>
          </button>
        )}

        {/* Real Screen Share Pill */}
        {onToggleScreenShare && (
          <button
            onClick={onToggleScreenShare}
            className={`px-2.5 py-1.5 rounded-full border text-[11px] font-mono flex items-center gap-1.5 transition-all shadow-md active:scale-95 ${
              isScreenSharing
                ? 'bg-emerald-500/25 border-emerald-400 text-emerald-300 shadow-[0_0_12px_rgba(16,185,129,0.4)]'
                : 'bg-slate-900/80 border-white/10 text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
            title={isScreenSharing ? 'Stop Screen Sharing' : 'Share Screen with ZinxN3k'}
          >
            {isScreenSharing ? (
              <>
                <MonitorOff className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span className="hidden sm:inline font-bold text-emerald-300">SHARING</span>
              </>
            ) : (
              <>
                <Monitor className="w-3.5 h-3.5 text-slate-400" />
                <span className="hidden sm:inline font-bold">SCREEN</span>
              </>
            )}
          </button>
        )}

        {/* Quick Commands Toggle (visible especially on mobile/tablet) */}
        {onToggleCommands && (
          <button
            onClick={onToggleCommands}
            className={`lg:hidden px-2.5 py-1.5 rounded-xl border text-[11px] font-mono flex items-center gap-1.5 transition-all shadow-md ${
              isCommandsOpen
                ? 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-900/80 border-white/10 text-slate-300 hover:text-white'
            }`}
            title="Toggle Quick Commands"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">COMMANDS</span>
          </button>
        )}

        {/* ZinxN3k Brain Button */}
        <button
          onClick={onOpenBrain}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-slate-900/80 hover:bg-slate-800/90 border border-white/12 text-xs font-mono text-white transition-all shadow-md active:scale-95 group"
          title="Open ZinxN3k Brain (Persistent Long-Term Memory)"
        >
          <Brain
            className="w-3.5 h-3.5 transition-transform group-hover:scale-110"
            style={{ color: themeConfig.primary }}
          />
          <span className="font-bold text-[11px] hidden sm:inline">BRAIN</span>
          <span
            className="text-[10px] px-1.5 py-0.2 rounded-full font-bold tabular-nums"
            style={{
              backgroundColor: `${themeConfig.primary}30`,
              color: themeConfig.primary,
            }}
          >
            {memoryCount}
          </span>
        </button>

        {state !== 'disconnected' && (
          <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900/60 border border-white/10 text-[10px] font-mono text-slate-300 tabular-nums">
            <Activity className="w-3 h-3 text-emerald-400" />
            <span>{latencyMs || 24}ms</span>
          </div>
        )}

        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/70 border border-white/10 text-[11px] font-mono">
          <span
            className={`w-2 h-2 rounded-full ${
              state === 'speaking'
                ? 'animate-ping'
                : state === 'listening'
                  ? 'animate-pulse'
                  : state === 'connecting'
                    ? 'animate-bounce'
                    : 'bg-slate-600'
            }`}
            style={{
              backgroundColor:
                state === 'disconnected'
                  ? '#64748b'
                  : state === 'connecting'
                    ? '#a855f7'
                    : themeConfig.primary,
            }}
          />
          <span className="text-slate-300 uppercase font-semibold text-[10px] tracking-wider">
            {state}
          </span>
        </div>
      </div>
    </header>
  );
};
