import React, { useEffect, useRef } from 'react';
import { AssistantState, AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';
import { AudioPlayer } from '../modules/AudioPlayer.ts';

interface WaveformVisualizerProps {
  state: AssistantState;
  theme: AssistantTheme;
  userLevel: number;
  assistantLevel: number;
  audioPlayer: AudioPlayer;
}

export const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({
  state,
  theme,
  userLevel,
  assistantLevel,
  audioPlayer,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let phase = 0;
    const freqData = new Uint8Array(128);

    const resize = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * dpr;
      canvas.height = rect.height * dpr;
      ctx.scale(dpr, dpr);
    };

    resize();
    window.addEventListener('resize', resize);

    const render = () => {
      const rect = canvas.getBoundingClientRect();
      const width = rect.width;
      const height = rect.height;
      const centerY = height / 2;

      ctx.clearRect(0, 0, width, height);

      let activeAmp = 0;

      if (state === 'speaking') {
        const analyser = audioPlayer.getAnalyser();
        if (analyser) {
          analyser.getByteFrequencyData(freqData);
          let sum = 0;
          for (let i = 0; i < 32; i++) {
            sum += freqData[i];
          }
          activeAmp = Math.max(0.15, (sum / 32 / 255) * 1.4);
        } else {
          activeAmp = Math.max(0.15, assistantLevel * 1.5);
        }
      } else if (state === 'listening') {
        activeAmp = Math.max(0.06, userLevel * 1.8);
      } else if (state === 'connecting') {
        activeAmp = 0.12 + Math.sin(phase * 4) * 0.08;
      } else {
        activeAmp = 0.03 + Math.sin(phase * 1.5) * 0.015;
      }

      phase += 0.045;

      const waves = [
        {
          freq: 0.015,
          speed: 1.0,
          amp: activeAmp * (height * 0.38),
          alpha: state === 'speaking' ? 0.9 : 0.6,
          color: themeConfig.primary,
          lineWidth: 2.5,
        },
        {
          freq: 0.022,
          speed: -1.3,
          amp: activeAmp * (height * 0.28),
          alpha: 0.5,
          color: themeConfig.secondary,
          lineWidth: 1.8,
        },
        {
          freq: 0.009,
          speed: 0.8,
          amp: activeAmp * (height * 0.2),
          alpha: 0.35,
          color: themeConfig.accent,
          lineWidth: 1.2,
        },
      ];

      waves.forEach((w) => {
        ctx.beginPath();
        ctx.lineWidth = w.lineWidth;
        ctx.strokeStyle = w.color;
        ctx.globalAlpha = w.alpha;

        const grad = ctx.createLinearGradient(0, 0, width, 0);
        grad.addColorStop(0, 'rgba(255, 255, 255, 0)');
        grad.addColorStop(0.2, w.color);
        grad.addColorStop(0.5, '#ffffff');
        grad.addColorStop(0.8, w.color);
        grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.strokeStyle = grad;

        ctx.shadowColor = w.color;
        ctx.shadowBlur = state === 'speaking' ? 14 : 8;

        for (let x = 0; x <= width; x += 3) {
          const edgeDist = Math.min(x, width - x) / (width * 0.5);
          const envelope = Math.sin(Math.PI * 0.5 * Math.min(1, edgeDist));

          const y =
            centerY +
            Math.sin(x * w.freq + phase * w.speed) *
              w.amp *
              envelope *
              Math.cos(x * 0.005 + phase * 0.5);

          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      });

      ctx.shadowBlur = 0;
      ctx.globalAlpha = 1;

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
      window.removeEventListener('resize', resize);
    };
  }, [state, theme, userLevel, assistantLevel, audioPlayer, themeConfig]);

  return (
    <div className="w-full max-w-xl h-24 mx-auto relative pointer-events-none flex items-center justify-center">
      <canvas
        ref={canvasRef}
        className="w-full h-full"
        style={{ filter: 'drop-shadow(0 0 16px rgba(0,0,0,0.5))' }}
      />
    </div>
  );
};
