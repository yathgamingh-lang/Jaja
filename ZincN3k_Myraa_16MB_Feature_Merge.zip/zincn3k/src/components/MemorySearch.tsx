import React from 'react';
import { Search, X } from 'lucide-react';
import { AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface MemorySearchProps {
  value: string;
  theme: AssistantTheme;
  onChange: (val: string) => void;
  placeholder?: string;
}

export const MemorySearch: React.FC<MemorySearchProps> = ({
  value,
  theme,
  onChange,
  placeholder = 'Search stored memories, facts, or topics...',
}) => {
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  return (
    <div className="relative w-full">
      <Search
        className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none"
        style={{ color: value ? themeConfig.primary : undefined }}
      />
      <input
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="w-full pl-10 pr-9 py-2.5 rounded-2xl bg-slate-900/80 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
      />
      {value && (
        <button
          onClick={() => onChange('')}
          className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5 rounded-full"
          title="Clear search"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      )}
    </div>
  );
};
