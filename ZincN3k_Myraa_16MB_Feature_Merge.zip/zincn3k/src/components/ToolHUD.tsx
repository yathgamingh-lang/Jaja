import React from 'react';
import {
  ExternalLink,
  Clock,
  Sparkles,
  X,
  Globe,
  Calculator,
  Palette,
  Smartphone,
} from 'lucide-react';
import { ActiveTimer, AssistantTheme, ToolActionCard } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface ToolHUDProps {
  theme: AssistantTheme;
  cards?: ToolActionCard[];
  timers?: ActiveTimer[];
  actionCards?: ToolActionCard[];
  activeTimers?: ActiveTimer[];
  onDismissCard: (id: string) => void;
  onDismissTimer: (id: string) => void;
}

export const ToolHUD: React.FC<ToolHUDProps> = ({
  theme,
  cards,
  timers,
  actionCards,
  activeTimers,
  onDismissCard,
  onDismissTimer,
}) => {
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];
  const resolvedCards = cards || actionCards || [];
  const resolvedTimers = timers || activeTimers || [];

  if (resolvedCards.length === 0 && resolvedTimers.length === 0) {
    return null;
  }

  const formatTimerSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <aside
      aria-label="Active Tools and Timers"
      className="absolute top-20 left-0 right-0 z-20 pointer-events-none px-4 max-w-lg mx-auto flex flex-col gap-3"
    >
      {/* Active Timers */}
      {resolvedTimers.map((timer) => {
        const percent = Math.max(
          0,
          Math.min(100, (timer.remainingSeconds / timer.totalSeconds) * 100),
        );
        const isComplete = timer.remainingSeconds === 0;

        return (
          <div
            key={timer.id}
            className="pointer-events-auto flex items-center justify-between p-3.5 rounded-2xl bg-[#0b0e1b]/85 border border-white/10 backdrop-blur-xl shadow-2xl transition-all duration-300"
            style={{
              boxShadow: isComplete ? `0 0 20px ${themeConfig.glow}` : undefined,
              borderColor: isComplete ? themeConfig.primary : 'rgba(255,255,255,0.1)',
            }}
          >
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center relative"
                style={{ backgroundColor: `${themeConfig.primary}22` }}
              >
                <Clock className="w-5 h-5" style={{ color: themeConfig.primary }} />
                {/* Micro circular progress border */}
                <svg className="absolute inset-0 w-full h-full -rotate-90">
                  <circle
                    cx="20"
                    cy="20"
                    r="16"
                    className="stroke-white/10 fill-none"
                    strokeWidth="2.5"
                  />
                  <circle
                    cx="20"
                    cy="20"
                    r="16"
                    className="fill-none transition-all duration-1000"
                    strokeWidth="2.5"
                    stroke={themeConfig.primary}
                    strokeDasharray="100"
                    strokeDashoffset={100 - percent}
                    strokeLinecap="round"
                  />
                </svg>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-semibold uppercase tracking-wider text-slate-400">
                    {timer.label}
                  </span>
                  {isComplete && (
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 uppercase">
                      Finished
                    </span>
                  )}
                </div>
                <div className="text-lg font-mono font-bold tracking-tight text-white tabular-nums">
                  {formatTimerSeconds(timer.remainingSeconds)}
                </div>
              </div>
            </div>

            <button
              onClick={() => onDismissTimer(timer.id)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
              title="Dismiss timer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}

      {/* Action Cards */}
      {resolvedCards.map((card) => {
        let IconComponent = Sparkles;
        if (card.type === 'website') IconComponent = Globe;
        if (card.type === 'math') IconComponent = Calculator;
        if (card.type === 'theme') IconComponent = Palette;
        if (card.type === 'android') IconComponent = Smartphone;

        return (
          <div
            key={card.id}
            className="pointer-events-auto relative p-4 rounded-2xl bg-[#090c18]/90 border border-white/12 backdrop-blur-xl shadow-2xl transition-all duration-300 animate-in fade-in slide-in-from-top-3"
            style={{
              borderLeft: `4px solid ${themeConfig.primary}`,
            }}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div
                  className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${themeConfig.primary}20` }}
                >
                  <IconComponent className="w-4 h-4" style={{ color: themeConfig.primary }} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-200">
                      {card.title}
                    </span>
                    {card.tag && (
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-white/10 text-slate-300">
                        {card.tag}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    {card.content}
                  </p>
                </div>
              </div>

              <button
                onClick={() => onDismissCard(card.id)}
                className="text-slate-400 hover:text-white p-1 rounded-md hover:bg-white/10 shrink-0"
                title="Dismiss"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {card.type === 'website' && card.url && (
              <div className="mt-3 pt-2.5 border-t border-white/10 flex items-center justify-between">
                <span className="text-[11px] font-mono text-slate-400 truncate max-w-[200px]">
                  {card.url}
                </span>
                <a
                  href={card.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-white transition-all duration-200 shadow-md hover:brightness-110 active:scale-95"
                  style={{
                    backgroundColor: themeConfig.primary,
                    color: '#05060b',
                  }}
                >
                  <span>Open Page</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            )}
          </div>
        );
      })}
    </aside>
  );
};
