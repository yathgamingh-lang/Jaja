import React from 'react';
import { ShieldCheck, Wifi, Lock } from 'lucide-react';
import { AssistantState, AssistantTheme, ScreenShareState } from '../types/assistant.ts';

interface TacticalOperatorHUDProps {
  state: AssistantState;
  theme: AssistantTheme;
  latencyMs: number;
  memoryCount: number;
  isBrowserOpen?: boolean;
  isCameraVisionOpen?: boolean;
  screenShareState?: ScreenShareState;
}

export const TacticalOperatorHUD: React.FC<TacticalOperatorHUDProps> = ({
  state,
  latencyMs,
  memoryCount,
  isBrowserOpen = false,
  isCameraVisionOpen = false,
  screenShareState,
}) => {
  const isOnline = state !== 'disconnected';
  const isScreenActive = Boolean(
    screenShareState &&
      screenShareState.status === 'active' &&
      screenShareState.isSharing &&
      screenShareState.stream !== null,
  );

  return (
    <div className="relative group w-60 sm:w-64 p-3.5 rounded-2xl bg-[#060916]/85 border border-cyan-400/30 backdrop-blur-2xl shadow-[0_0_28px_rgba(0,229,255,0.12)] select-none font-mono">
      {/* Header: SYSTEM STATUS */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20 text-[10px]">
        <div className="flex items-center gap-1.5 text-cyan-300">
          <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
          <span className="font-extrabold tracking-wider uppercase">SYSTEM STATUS</span>
        </div>
        <span className="flex items-center gap-1 text-[9px] text-emerald-400 font-bold">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          NOMINAL
        </span>
      </div>

      {/* Real-time Subsystem Status Rows matching exact specification */}
      <div className="space-y-2 pt-2.5 text-[10px]">
        {/* AI CORE */}
        <div className="flex items-center justify-between">
          <span className="text-slate-400">AI CORE</span>
          <span
            className={`flex items-center gap-1.5 font-bold ${
              isOnline ? 'text-emerald-400' : 'text-cyan-300'
            }`}
          >
            <span>●</span>
            <span>{isOnline ? 'ONLINE' : 'READY'}</span>
          </span>
        </div>

        {/* VOICE */}
        <div className="flex items-center justify-between">
          <span className="text-slate-400">VOICE</span>
          <span className="flex items-center gap-1.5 font-bold text-emerald-400">
            <span>●</span>
            <span>{isOnline ? state.toUpperCase() : 'READY'}</span>
          </span>
        </div>

        {/* MEMORY */}
        <div className="flex items-center justify-between">
          <span className="text-slate-400">MEMORY</span>
          <span className="flex items-center gap-1.5 font-bold text-emerald-400 tabular-nums">
            <span>●</span>
            <span>READY ({memoryCount})</span>
          </span>
        </div>

        {/* BROWSER */}
        <div className="flex items-center justify-between">
          <span className="text-slate-400">BROWSER</span>
          <span
            className={`flex items-center gap-1.5 font-bold ${
              isBrowserOpen ? 'text-cyan-300' : 'text-emerald-400'
            }`}
          >
            <span>●</span>
            <span>{isBrowserOpen ? 'ACTIVE' : 'READY'}</span>
          </span>
        </div>

        {/* VISION */}
        <div className="flex items-center justify-between">
          <span className="text-slate-400">VISION</span>
          <span
            className={`flex items-center gap-1.5 font-bold ${
              isCameraVisionOpen ? 'text-cyan-300' : 'text-emerald-400'
            }`}
          >
            <span>●</span>
            <span>{isCameraVisionOpen ? 'ACTIVE' : 'READY'}</span>
          </span>
        </div>

        {/* SCREEN (Real Screen Share State!) */}
        <div className="flex items-center justify-between">
          <span className="text-slate-400">SCREEN</span>
          {isScreenActive ? (
            <span className="flex items-center gap-1.5 font-bold text-emerald-400">
              <span className="animate-pulse">●</span>
              <span>ACTIVE</span>
            </span>
          ) : (
            <span className="flex items-center gap-1.5 font-bold text-slate-400">
              <span>○</span>
              <span>OFF</span>
            </span>
          )}
        </div>
      </div>

      {/* Footer Link Telemetry */}
      <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between text-[9px] text-slate-400 tabular-nums">
        <span className="flex items-center gap-1">
          <Wifi className="w-3 h-3 text-cyan-400" />
          {latencyMs || 24}ms RTT
        </span>
        <span className="flex items-center gap-1 text-slate-300">
          <Lock className="w-2.5 h-2.5 text-cyan-400" />
          PCM 24kHz
        </span>
      </div>
    </div>
  );
};
