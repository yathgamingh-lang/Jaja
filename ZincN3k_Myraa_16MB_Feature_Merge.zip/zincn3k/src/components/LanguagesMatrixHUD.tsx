import React, { useState } from 'react';
import { Languages, Globe2, ChevronDown, Check } from 'lucide-react';
import { SupportedLanguage, AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface LanguagesMatrixHUDProps {
  theme: AssistantTheme;
  activeLanguage: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
}

const LANGUAGES_MATRIX: {
  id: SupportedLanguage;
  label: string;
  code: string;
  dialect: string;
}[] = [
  { id: 'English', label: 'English', code: 'EN', dialect: 'Global (US/UK)' },
  { id: 'Hindi', label: 'हिन्दी', code: 'HI', dialect: 'Devanagari Standard' },
  { id: 'Hinglish', label: 'Hinglish', code: 'IN', dialect: 'Colloquial Urban' },
  { id: 'Punjabi', label: 'ਪੰਜਾਬੀ', code: 'PB', dialect: 'Gurmukhi' },
  { id: 'Portuguese', label: 'Português', code: 'PT', dialect: 'Brasil / Lusofonia' },
  { id: 'Russian', label: 'Русский', code: 'RU', dialect: 'Cyrillic Standard' },
  { id: 'Chinese', label: '中文', code: 'ZH', dialect: 'Mandarin (Simplified)' },
];

export const LanguagesMatrixHUD: React.FC<LanguagesMatrixHUDProps> = ({
  theme,
  activeLanguage,
  onSelectLanguage,
}) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  return (
    <div className="relative pointer-events-auto select-none">
      <div className="flex items-center gap-2">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border backdrop-blur-xl transition-all shadow-lg text-left ${
            isExpanded
              ? 'bg-[#080d24]/90 border-cyan-400/50 shadow-[0_0_15px_rgba(0,229,255,0.25)]'
              : 'bg-[#060814]/85 border-white/10 hover:border-cyan-400/30'
          }`}
          title="Switch Neural Voice Language Matrix"
        >
          <Languages className="w-3.5 h-3.5 text-cyan-400" />
          <div className="flex flex-col">
            <span className="text-[9px] font-mono text-slate-400 tracking-wider">
              VOICE MATRIX
            </span>
            <span className="text-xs font-mono font-bold text-white flex items-center gap-1">
              {activeLanguage}
              <ChevronDown
                className={`w-3 h-3 text-cyan-400 transition-transform duration-200 ${
                  isExpanded ? 'rotate-180' : ''
                }`}
              />
            </span>
          </div>
        </button>
      </div>

      {isExpanded && (
        <div className="absolute bottom-12 left-0 w-64 p-2.5 rounded-2xl bg-[#070a1a]/95 border border-cyan-500/30 backdrop-blur-2xl shadow-[0_10px_35px_rgba(0,0,0,0.8)] z-50 animate-in fade-in zoom-in-95 duration-150">
          <div className="flex items-center justify-between px-1.5 py-1 mb-1.5 border-b border-white/10 text-[9px] font-mono text-slate-400">
            <span className="flex items-center gap-1 font-bold text-cyan-300">
              <Globe2 className="w-3 h-3 text-cyan-400" />
              GLOBAL LANGUAGE MATRIX
            </span>
            <span>7 PROTOCOLS</span>
          </div>

          <div className="grid grid-cols-1 gap-1 max-h-56 overflow-y-auto pr-0.5">
            {LANGUAGES_MATRIX.map((lang) => {
              const isSelected = activeLanguage === lang.id;
              return (
                <button
                  key={lang.id}
                  onClick={() => {
                    onSelectLanguage(lang.id);
                    setIsExpanded(false);
                  }}
                  className={`px-2.5 py-1.5 rounded-xl text-left flex items-center justify-between text-xs font-mono transition-all ${
                    isSelected
                      ? 'bg-cyan-500/25 border border-cyan-400 text-cyan-200 font-bold shadow-[0_0_10px_rgba(0,229,255,0.2)]'
                      : 'hover:bg-white/5 border border-transparent text-slate-300 hover:text-white'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="px-1.5 py-0.5 rounded text-[9px] font-extrabold"
                      style={{
                        backgroundColor: isSelected
                          ? `${themeConfig.primary}40`
                          : 'rgba(255,255,255,0.06)',
                        color: isSelected ? '#ffffff' : '#94a3b8',
                      }}
                    >
                      {lang.code}
                    </span>
                    <div>
                      <p className="font-semibold">{lang.label}</p>
                      <p className="text-[8px] text-slate-400">{lang.dialect}</p>
                    </div>
                  </div>
                  {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
