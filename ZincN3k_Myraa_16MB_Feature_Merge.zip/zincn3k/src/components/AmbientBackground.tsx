import React from 'react';
import { AssistantState, AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface AmbientBackgroundProps {
  state: AssistantState;
  theme: AssistantTheme;
}

export const AmbientBackground: React.FC<AmbientBackgroundProps> = ({ state, theme }) => {
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0 bg-[#05060b]">
      {/* Dynamic gradient orbs */}
      <div
        className="absolute -top-[25%] -left-[20%] w-[70vw] h-[70vw] rounded-full blur-[140px] opacity-25 transition-all duration-1000"
        style={{
          background: themeConfig.secondary,
          transform: state === 'speaking' ? 'scale(1.2)' : 'scale(1)',
        }}
      />
      <div
        className="absolute -bottom-[25%] -right-[20%] w-[75vw] h-[75vw] rounded-full blur-[160px] opacity-20 transition-all duration-1000"
        style={{
          background: themeConfig.primary,
          transform: state === 'speaking' ? 'scale(1.25)' : 'scale(1)',
        }}
      />

      {/* Cybernetic grid overlay */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(255, 255, 255, 0.2) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255, 255, 255, 0.2) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      />

      {/* Concentric subtle radar circles */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full border border-white/[0.03] pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[900px] h-[900px] rounded-full border border-white/[0.02] pointer-events-none" />

      {/* Vignette edge darkening */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_20%,#05060b_85%)]" />
    </div>
  );
};
