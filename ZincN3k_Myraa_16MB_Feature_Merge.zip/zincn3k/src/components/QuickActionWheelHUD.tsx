import React from 'react';
import {
  Youtube,
  Search,
  Brain,
  Globe,
  Monitor,
  Shield,
} from 'lucide-react';
import { AssistantState, AssistantTheme } from '../types/assistant.ts';

interface QuickActionWheelHUDProps {
  state: AssistantState;
  theme: AssistantTheme;
  isScreenSharing?: boolean;
  onOpenYouTube: () => void;
  onSearchWeb: () => void;
  onOpenBrain: () => void;
  onOpenBrowser: () => void;
  onToggleScreenShare: () => void;
  onOpenCommandCenter: () => void;
}

export const QuickActionWheelHUD: React.FC<QuickActionWheelHUDProps> = ({
  isScreenSharing = false,
  onOpenYouTube,
  onSearchWeb,
  onOpenBrain,
  onOpenBrowser,
  onToggleScreenShare,
  onOpenCommandCenter,
}) => {
  // Exact 6 Quick Commands requested in FEATURE 10
  const QUICK_ITEMS = [
    {
      label: 'Open YouTube',
      icon: Youtube,
      color: 'text-red-400',
      onClick: onOpenYouTube,
    },
    {
      label: 'Search Web',
      icon: Search,
      color: 'text-cyan-400',
      onClick: onSearchWeb,
    },
    {
      label: 'Memory',
      icon: Brain,
      color: 'text-purple-400',
      onClick: onOpenBrain,
    },
    {
      label: 'Browser',
      icon: Globe,
      color: 'text-sky-400',
      onClick: onOpenBrowser,
    },
    {
      label: isScreenSharing ? 'Screen Active' : 'Screen Share',
      icon: Monitor,
      color: isScreenSharing ? 'text-emerald-400' : 'text-emerald-300',
      onClick: onToggleScreenShare,
    },
    {
      label: 'Command Center',
      icon: Shield,
      color: 'text-amber-400',
      onClick: onOpenCommandCenter,
    },
  ];

  return (
    <div className="w-full max-w-2xl mx-auto px-2 pointer-events-auto select-none">
      <div className="flex items-center justify-center gap-1.5 sm:gap-2 flex-wrap">
        {QUICK_ITEMS.map((item, idx) => {
          const Icon = item.icon;
          return (
            <button
              key={idx}
              onClick={item.onClick}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[#070b18]/85 hover:bg-cyan-500/20 border border-cyan-400/30 hover:border-cyan-300/70 text-[10px] sm:text-[11px] font-mono font-bold text-slate-200 hover:text-white backdrop-blur-xl shadow-md transition-all active:scale-95 whitespace-nowrap"
            >
              <Icon className={`w-3.5 h-3.5 shrink-0 ${item.color}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
