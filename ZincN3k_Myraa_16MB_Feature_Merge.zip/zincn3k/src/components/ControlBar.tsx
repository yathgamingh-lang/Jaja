import React, { useState, useEffect } from 'react';
import {
  Mic,
  MicOff,
  Power,
  Settings2,
  Palette,
  Sparkles,
  Volume2,
  ChevronDown,
  Info,
  X,
  Radio,
  Brain,
  Globe,
  Monitor,
  MonitorOff,
} from 'lucide-react';
import {
  AssistantState,
  AssistantTheme,
  SessionInfo,
  VoicePersona,
} from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface ControlBarProps {
  state: AssistantState;
  theme: AssistantTheme;
  isMuted: boolean;
  sessionInfo: SessionInfo;
  selectedAudioInputId: string;
  memoryCount: number;
  isBrowserOpen?: boolean;
  isScreenSharing?: boolean;
  onToggleConnect: () => void;
  onToggleMute: () => void;
  onSelectTheme: (theme: AssistantTheme) => void;
  onSelectVoice: (voice: VoicePersona) => void;
  onSelectAudioInput: (deviceId: string) => void;
  onOpenBrain: () => void;
  onToggleBrowser?: () => void;
  onToggleScreenShare?: () => void;
}

const VOICE_OPTIONS: { id: VoicePersona; name: string; tag: string; desc: string }[] = [
  {
    id: 'Fenrir',
    name: 'Fenrir (ZinxN3k Armored Core)',
    tag: 'Deep Adult Male · Primary',
    desc: 'Deep, commanding, authoritative, Jarvis-like adult mech AI voice.',
  },
  {
    id: 'Charon',
    name: 'Charon (Titan Core)',
    tag: 'Tactical Resonant Male',
    desc: 'Grave, mature, deep tactical resonance for complex operations.',
  },
  {
    id: 'Orus',
    name: 'Orus (Heavy Mech)',
    tag: 'Robust & Steadfast Male',
    desc: 'Powerful, steady, and disciplined adult male voice.',
  },
  {
    id: 'Puck',
    name: 'Puck (ZinxN3k Tactical)',
    tag: 'Charismatic & Witty Male',
    desc: 'Youthful, sharp, witty, and energetic male companion tone.',
  },
  {
    id: 'Kore',
    name: 'Kore (Neural Secondary)',
    tag: 'Female AI Voice',
    desc: 'Alternative serene female AI vocal synthesis.',
  },
  {
    id: 'Zephyr',
    name: 'Zephyr (Support AI)',
    tag: 'Female AI Voice',
    desc: 'Alternative warm and poised female vocal tone.',
  },
];

const THEME_LIST: { id: AssistantTheme; name: string; color: string }[] = [
  { id: 'cyber-cyan', name: 'Cyber Cyan', color: '#00f0ff' },
  { id: 'electric-violet', name: 'Electric Violet', color: '#a855f7' },
  { id: 'midnight-emerald', name: 'Emerald Wave', color: '#10b981' },
  { id: 'solar-amber', name: 'Solar Amber', color: '#f59e0b' },
  { id: 'crimson-pulse', name: 'Crimson Pulse', color: '#f43f5e' },
];

const SUGGESTED_PROMPTS = [
  'Who are you, ZinxN3k?',
  'Search Google for latest breakthrough AI news.',
  'Search YouTube for Minecraft videos.',
  'Play relaxing synthwave music on YouTube.',
  'Share my screen so you can inspect it.',
  'What is currently displayed on my screen?',
  'Remember that my favorite game is Minecraft.',
  'What do you remember about me?',
  'Set a timer for 10 minutes.',
  'Change the visual theme to Electric Violet.',
];

export const ControlBar: React.FC<ControlBarProps> = ({
  state,
  theme,
  isMuted,
  sessionInfo,
  selectedAudioInputId,
  memoryCount,
  isBrowserOpen = false,
  isScreenSharing = false,
  onToggleConnect,
  onToggleMute,
  onSelectTheme,
  onSelectVoice,
  onSelectAudioInput,
  onOpenBrain,
  onToggleBrowser,
  onToggleScreenShare,
}) => {
  const [showSettings, setShowSettings] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [audioDevices, setAudioDevices] = useState<MediaDeviceInfo[]>([]);

  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];
  const isConnected = state !== 'disconnected';

  useEffect(() => {
    const fetchDevices = async () => {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioInputs = devices.filter((d) => d.kind === 'audioinput');
        setAudioDevices(audioInputs);
      } catch {}
    };
    fetchDevices();
  }, []);

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins < 10 ? '0' : ''}${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <>
      {/* Floating Bottom Control Bar */}
      <footer
        aria-label="Audio Controls"
        className="fixed bottom-6 left-0 right-0 z-30 px-4 flex flex-col items-center pointer-events-none select-none"
      >
        <div className="pointer-events-auto flex items-center gap-2 sm:gap-3 px-4 py-2.5 rounded-full bg-[#0a0d18]/85 border border-white/12 backdrop-blur-2xl shadow-[0_12px_40px_rgba(0,0,0,0.6)]">
          {/* Mute Button */}
          <button
            onClick={onToggleMute}
            disabled={!isConnected}
            className={`p-3 rounded-full transition-all duration-200 ${
              !isConnected
                ? 'opacity-40 cursor-not-allowed text-slate-500'
                : isMuted
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                  : 'bg-white/5 text-slate-200 hover:bg-white/10 active:scale-95'
            }`}
            title={isMuted ? 'Unmute microphone' : 'Mute microphone'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* Main Quick Connect / Disconnect */}
          <button
            onClick={onToggleConnect}
            className="flex items-center gap-2 px-5 py-3 rounded-full font-semibold text-sm transition-all duration-300 active:scale-95 shadow-lg"
            style={{
              backgroundColor: isConnected ? '#ef4444' : themeConfig.primary,
              color: isConnected ? '#ffffff' : '#05060b',
              boxShadow: `0 0 20px ${isConnected ? 'rgba(239,68,68,0.4)' : themeConfig.glow}`,
            }}
          >
            <Power className="w-4 h-4" />
            <span className="font-mono tracking-wider font-bold uppercase text-xs">
              {state === 'disconnected'
                ? 'Awaken'
                : state === 'connecting'
                  ? 'Linking...'
                  : 'Disconnect'}
            </span>
          </button>

          {/* ZinxN3k Brain Button */}
          <button
            onClick={onOpenBrain}
            className="relative p-3 rounded-full bg-white/5 hover:bg-white/10 text-slate-300 transition-all active:scale-95"
            title="ZinxN3k Brain (Persistent Memory)"
          >
            <Brain className="w-5 h-5" style={{ color: themeConfig.primary }} />
            {memoryCount > 0 && (
              <span
                className="absolute -top-1 -right-1 text-[9px] font-bold px-1.5 py-0.2 rounded-full font-mono shadow-md tabular-nums"
                style={{
                  backgroundColor: themeConfig.primary,
                  color: '#05060b',
                }}
              >
                {memoryCount}
              </span>
            )}
          </button>

          {/* Integrated Browser Toggle */}
          {onToggleBrowser && (
            <button
              onClick={onToggleBrowser}
              className={`p-3 rounded-full transition-all duration-200 active:scale-95 ${
                isBrowserOpen
                  ? 'bg-cyan-500/25 border border-cyan-400 text-cyan-300 shadow-[0_0_15px_rgba(0,229,255,0.4)]'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10'
              }`}
              title="Integrated Browser & YouTube"
            >
              <Globe
                className="w-5 h-5"
                style={{ color: isBrowserOpen ? themeConfig.primary : undefined }}
              />
            </button>
          )}

          {/* Real Screen Share Toggle */}
          {onToggleScreenShare && (
            <button
              onClick={onToggleScreenShare}
              className={`p-3 rounded-full transition-all duration-200 active:scale-95 ${
                isScreenSharing
                  ? 'bg-emerald-500/25 border border-emerald-400 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.4)]'
                  : 'bg-white/5 text-slate-300 hover:bg-white/10'
              }`}
              title={isScreenSharing ? 'Stop Screen Sharing' : 'Share Screen with ZinxN3k'}
            >
              {isScreenSharing ? (
                <MonitorOff className="w-5 h-5 text-emerald-400 animate-pulse" />
              ) : (
                <Monitor className="w-5 h-5" />
              )}
            </button>
          )}

          {/* Settings / Voice Persona Button */}
          <button
            onClick={() => setShowSettings(!showSettings)}
            className={`p-3 rounded-full transition-all duration-200 ${
              showSettings
                ? 'bg-white/20 text-white'
                : 'bg-white/5 text-slate-300 hover:bg-white/10 active:scale-95'
            }`}
            title="Session settings & voices"
          >
            <Settings2 className="w-5 h-5" />
          </button>

          {/* Prompt Guide / Personality Button */}
          <button
            onClick={() => setShowGuide(!showGuide)}
            className={`p-3 rounded-full transition-all duration-200 ${
              showGuide
                ? 'bg-white/20 text-white'
                : 'bg-white/5 text-slate-300 hover:bg-white/10 active:scale-95'
            }`}
            title="Voice Commands & Prompts Guide"
          >
            <Sparkles className="w-5 h-5" style={{ color: themeConfig.accent }} />
          </button>
        </div>

        {/* Live Status Micro Tag */}
        {isConnected && (
          <div className="mt-2.5 flex items-center gap-3 text-[11px] font-mono text-slate-400 bg-black/40 px-3 py-1 rounded-full border border-white/5 backdrop-blur-md tabular-nums">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span>{formatDuration(sessionInfo.durationSeconds)}</span>
            </span>
            <span>·</span>
            <span>{sessionInfo.latencyMs}ms RTT</span>
            <span>·</span>
            <span>Voice: {sessionInfo.voice}</span>
            <span>·</span>
            <span>Brain: {memoryCount} facts</span>
          </div>
        )}
      </footer>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 z-40 bg-black/70 backdrop-blur-md flex items-end sm:items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-[#0c0f1e] border border-white/12 rounded-3xl p-6 shadow-2xl space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Settings2 className="w-5 h-5" style={{ color: themeConfig.primary }} />
                <h3 className="text-base font-bold text-white tracking-wide">
                  ZinxN3k Controls
                </h3>
              </div>
              <button
                onClick={() => setShowSettings(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Voice Persona Selector */}
            <div className="space-y-3">
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Volume2 className="w-3.5 h-3.5" />
                <span>Voice Persona</span>
              </label>
              <div className="grid grid-cols-1 gap-2 max-h-60 overflow-y-auto pr-1">
                {VOICE_OPTIONS.map((opt) => (
                  <button
                    key={opt.id}
                    onClick={() => onSelectVoice(opt.id)}
                    className={`flex items-start justify-between p-3 rounded-2xl border text-left transition-all ${
                      sessionInfo.voice === opt.id
                        ? 'bg-white/10 border-white/30 shadow-lg'
                        : 'bg-white/5 border-white/5 hover:bg-white/8 text-slate-400'
                    }`}
                    style={{
                      borderColor: sessionInfo.voice === opt.id ? themeConfig.primary : undefined,
                    }}
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-white">{opt.name}</span>
                        <span
                          className="text-[10px] font-mono px-2 py-0.5 rounded-full"
                          style={{
                            backgroundColor: `${themeConfig.primary}25`,
                            color: themeConfig.primary,
                          }}
                        >
                          {opt.tag}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1">{opt.desc}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Theme Ambiance Selector */}
            <div className="space-y-3">
              <label className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Palette className="w-3.5 h-3.5" />
                <span>Visual Ambiance Theme</span>
              </label>
              <div className="flex items-center gap-2.5 flex-wrap">
                {THEME_LIST.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => onSelectTheme(t.id)}
                    className={`flex items-center gap-2 px-3 py-2 rounded-xl border text-xs font-medium transition-all ${
                      theme === t.id
                        ? 'bg-white/15 border-white/40 text-white'
                        : 'bg-white/5 border-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    <span
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: t.color, boxShadow: `0 0 8px ${t.color}` }}
                    />
                    <span>{t.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Audio Input Device Selector */}
            {audioDevices.length > 0 && (
              <div className="space-y-2">
                <label className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5" />
                  <span>Microphone Source</span>
                </label>
                <div className="relative">
                  <select
                    value={selectedAudioInputId}
                    onChange={(e) => onSelectAudioInput(e.target.value)}
                    className="w-full bg-slate-900/90 border border-white/15 text-slate-200 text-xs rounded-xl px-3 py-2.5 appearance-none focus:outline-none focus:border-cyan-400"
                  >
                    <option value="default">Default System Microphone</option>
                    {audioDevices.map((dev, idx) => (
                      <option key={dev.deviceId || idx} value={dev.deviceId}>
                        {dev.label || `Microphone ${idx + 1}`}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Suggested Voice Prompts Guide */}
      {showGuide && (
        <div className="fixed inset-0 z-40 bg-black/70 backdrop-blur-md flex items-end sm:items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-md bg-[#0c0f1e] border border-white/12 rounded-3xl p-6 shadow-2xl space-y-5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5" style={{ color: themeConfig.primary }} />
                <h3 className="text-base font-bold text-white tracking-wide">
                  Meet ZinxN3k & His Brain
                </h3>
              </div>
              <button
                onClick={() => setShowGuide(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Persona bio */}
            <div className="p-4 rounded-2xl bg-white/5 border border-white/5 space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">Who is ZinxN3k?</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300">
                  Male AI Assistant
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                ZinxN3k is a confident, witty, and powerful MALE futuristic AI assistant with a
                persistent long-term memory system called <strong>ZinxN3k Brain</strong>. He
                naturally remembers your name, likes, dislikes, favorite games, and preferences
                across sessions!
              </p>
            </div>

            {/* Suggested Spoken Phrases */}
            <div className="space-y-3">
              <h4 className="text-xs font-mono uppercase tracking-wider text-slate-400">
                Try Saying These Out Loud:
              </h4>
              <div className="space-y-2">
                {SUGGESTED_PROMPTS.map((prompt, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-900/60 border border-white/5 flex items-start gap-2.5 text-xs text-slate-200 hover:border-white/20 transition-colors"
                  >
                    <Radio
                      className="w-3.5 h-3.5 shrink-0 mt-0.5"
                      style={{ color: themeConfig.primary }}
                    />
                    <span>"{prompt}"</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick tips */}
            <div className="text-[11px] font-mono text-slate-500 pt-2 border-t border-white/5 flex items-center justify-between">
              <span>IndexedDB Persistent Storage</span>
              <span>Ultra-low Latency Live Audio</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
