import React, { useState } from 'react';
import {
  Shield,
  Mic,
  Camera,
  Monitor,
  Bell,
  CheckCircle2,
  AlertCircle,
  X,
  ArrowRight,
  Accessibility,
  Smartphone,
} from 'lucide-react';
import {
  AndroidPlatformCapabilities,
  AssistantTheme,
  SystemPermissions,
} from '../types/assistant.ts';
import { THEME_CONFIGS, globalStateManager } from '../modules/StateManager.ts';
import { globalAndroidBridge } from '../modules/AndroidBridge.ts';
import { globalScreenCaptureManager } from '../modules/ScreenShareManager.ts';

interface PermissionOnboardingModalProps {
  isOpen: boolean;
  theme: AssistantTheme;
  permissions: SystemPermissions;
  androidCapabilities: AndroidPlatformCapabilities;
  onClose: () => void;
}

export const PermissionOnboardingModal: React.FC<PermissionOnboardingModalProps> = ({
  isOpen,
  theme,
  permissions,
  androidCapabilities,
  onClose,
}) => {
  const [requestingMic, setRequestingMic] = useState(false);
  const [requestingCam, setRequestingCam] = useState(false);
  const [errorNote, setErrorNote] = useState<string | null>(null);
  const [infoNote, setInfoNote] = useState<string | null>(null);

  if (!isOpen) return null;

  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  const handleRequestMicrophone = async () => {
    setRequestingMic(true);
    setErrorNote(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => t.stop());
      globalStateManager.updatePermission('microphone', 'granted');
    } catch (err: any) {
      globalStateManager.updatePermission('microphone', 'denied');
      setErrorNote(err?.message || 'Microphone permission was declined.');
    } finally {
      setRequestingMic(false);
    }
  };

  const handleOpenAccessibilitySettings = () => {
    setErrorNote(null);
    if (androidCapabilities.isAndroidNative) {
      const res = globalAndroidBridge.openAccessibilitySettings();
      setInfoNote(res.message);
    } else {
      setInfoNote(
        'Currently running in Web HUD mode. Build & install the native Android project in /android (ai.n3k.assistant) to enable Android AccessibilityService & PackageManager control.',
      );
    }
  };

  const handleStartScreenCapture = async () => {
    setErrorNote(null);
    const res = await globalScreenCaptureManager.start();
    if (res.status === 'error') {
      setErrorNote(res.message);
    } else {
      setInfoNote(res.message);
    }
  };

  const handleRequestCamera = async () => {
    setRequestingCam(true);
    setErrorNote(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      stream.getTracks().forEach((t) => t.stop());
      globalStateManager.updatePermission('camera', 'granted');
    } catch (err: any) {
      globalStateManager.updatePermission('camera', 'denied');
      setErrorNote(err?.message || 'Camera permission was declined.');
    } finally {
      setRequestingCam(false);
    }
  };

  const handleRequestNotifications = async () => {
    if (!('Notification' in window)) return;
    try {
      const res = await Notification.requestPermission();
      globalStateManager.updatePermission(
        'notifications',
        res === 'default' ? 'prompt' : (res as any),
      );
    } catch {}
  };

  const handleCompleteInitialization = () => {
    try {
      localStorage.setItem('zinxn3k_permissions_onboarded', 'true');
    } catch {}
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4 select-none animate-in fade-in duration-200 overflow-y-auto">
      <div className="w-full max-w-lg rounded-3xl bg-[#070b18]/95 border border-cyan-400/40 shadow-[0_0_55px_rgba(0,229,255,0.22)] p-6 text-slate-100 font-mono space-y-4 my-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
          <div className="flex items-center gap-3">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center border border-cyan-400/40"
              style={{
                backgroundColor: `${themeConfig.primary}20`,
                boxShadow: `0 0 18px ${themeConfig.glow}`,
              }}
            >
              <Shield className="w-5 h-5" style={{ color: themeConfig.primary }} />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-black tracking-wider text-white uppercase">
                N3k System & Android Permissions
              </h2>
              <p className="text-[10px] text-cyan-300/80">
                VOICE · ACCESSIBILITY SERVICE · SCREEN VISION · PRIVACY
              </p>
            </div>
          </div>
          <button
            onClick={handleCompleteInitialization}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10"
            title="Dismiss"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Platform Runtime Banner */}
        <div className="flex items-center justify-between p-3 rounded-2xl bg-cyan-950/30 border border-cyan-400/30 text-xs">
          <div className="flex items-center gap-2.5">
            <Smartphone className="w-4 h-4 text-cyan-400 shrink-0" />
            <div>
              <div className="font-bold text-white text-[11px]">
                Runtime: {androidCapabilities.isAndroidNative ? 'Android Native APK' : 'Web HUD + Android Native Source (/android)'}
              </div>
              <div className="text-[10px] text-slate-400">
                {androidCapabilities.isAndroidNative
                  ? `Connected to N3kNativeBridge (${androidCapabilities.foregroundPackage})`
                  : 'Voice, Memory, Screen Vision & Browser work now; native APK in /android enables OS-wide control.'}
              </div>
            </div>
          </div>
        </div>

        {errorNote && (
          <div className="p-3 rounded-xl bg-rose-950/70 border border-rose-500/40 text-xs text-rose-200 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorNote}</span>
          </div>
        )}

        {infoNote && (
          <div className="p-3 rounded-xl bg-cyan-950/70 border border-cyan-500/40 text-xs text-cyan-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
            <span>{infoNote}</span>
          </div>
        )}

        {/* Permission Rows */}
        <div className="space-y-2.5">
          {/* 1. Microphone Permission */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#0b1024] border border-cyan-500/25">
            <div className="flex items-center gap-3">
              <Mic className="w-4 h-4 text-cyan-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-white">1. Microphone (Required for Voice)</div>
                <div className="text-[10px] text-slate-400">
                  Streams 16kHz PCM voice commands to Gemini Live
                </div>
              </div>
            </div>
            {permissions.microphone === 'granted' ? (
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-300 bg-emerald-500/15 border border-emerald-400/40 px-2.5 py-1 rounded-full">
                <CheckCircle2 className="w-3 h-3" />
                GRANTED
              </span>
            ) : (
              <button
                onClick={handleRequestMicrophone}
                disabled={requestingMic}
                className="px-3 py-1.5 rounded-xl text-[10px] font-bold bg-cyan-400 hover:bg-cyan-300 text-slate-950 transition-all active:scale-95 disabled:opacity-50"
              >
                {requestingMic ? 'Requesting...' : 'Allow Mic'}
              </button>
            )}
          </div>

          {/* 2. Accessibility Service Permission */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#0b1024] border border-amber-500/25">
            <div className="flex items-center gap-3">
              <Accessibility className="w-4 h-4 text-amber-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-white">2. Android Accessibility Service</div>
                <div className="text-[10px] text-slate-400">
                  Enables Back/Home/Recents, UI inspection, clicking & typing in apps. Voice & app launching still work without it.
                </div>
              </div>
            </div>
            {androidCapabilities.accessibilityEnabled ? (
              <span className="flex items-center gap-1 text-[10px] font-bold text-emerald-300 bg-emerald-500/15 border border-emerald-400/40 px-2.5 py-1 rounded-full shrink-0">
                <CheckCircle2 className="w-3 h-3" />
                ENABLED
              </span>
            ) : (
              <button
                onClick={handleOpenAccessibilitySettings}
                className="px-3 py-1.5 rounded-xl text-[10px] font-bold bg-amber-400/20 hover:bg-amber-400/30 border border-amber-400/40 text-amber-200 transition-all active:scale-95 shrink-0"
              >
                Open Settings
              </button>
            )}
          </div>

          {/* 3. Screen Capture Permission (MediaProjection / getDisplayMedia) */}
          <div className="flex items-center justify-between p-3.5 rounded-2xl bg-[#0b1024] border border-white/10">
            <div className="flex items-center gap-3">
              <Monitor className="w-4 h-4 text-emerald-400 shrink-0" />
              <div>
                <div className="text-xs font-bold text-white">3. Screen Vision (On-Demand)</div>
                <div className="text-[10px] text-slate-400">
                  Uses Android MediaProjection or getDisplayMedia() only when you enable Screen Share
                </div>
              </div>
            </div>
            <button
              onClick={handleStartScreenCapture}
              className="px-3 py-1.5 rounded-xl text-[10px] font-bold bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-200 transition-all active:scale-95 shrink-0"
            >
              {globalScreenCaptureManager.isActive() ? 'ACTIVE' : 'Test Share'}
            </button>
          </div>

          {/* 4. Camera & Notifications (Optional) */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024] border border-white/10">
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-sky-400 shrink-0" />
                <div className="text-[11px] font-bold text-white">Camera</div>
              </div>
              {permissions.camera === 'granted' ? (
                <span className="text-[10px] font-bold text-emerald-300">OK</span>
              ) : (
                <button
                  onClick={handleRequestCamera}
                  disabled={requestingCam}
                  className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-white/10 hover:bg-white/20 text-slate-200"
                >
                  Allow
                </button>
              )}
            </div>

            <div className="flex items-center justify-between p-3 rounded-2xl bg-[#0b1024] border border-white/10">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-amber-400 shrink-0" />
                <div className="text-[11px] font-bold text-white">Alerts</div>
              </div>
              {permissions.notifications === 'granted' ? (
                <span className="text-[10px] font-bold text-emerald-300">OK</span>
              ) : (
                <button
                  onClick={handleRequestNotifications}
                  className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-white/10 hover:bg-white/20 text-slate-200"
                >
                  Allow
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Footer Button */}
        <div className="pt-2 flex items-center justify-end">
          <button
            onClick={handleCompleteInitialization}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg"
            style={{
              backgroundColor: themeConfig.primary,
              color: '#04060e',
              boxShadow: `0 0 20px ${themeConfig.glow}`,
            }}
          >
            <span>Enter N3k Command Center</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
