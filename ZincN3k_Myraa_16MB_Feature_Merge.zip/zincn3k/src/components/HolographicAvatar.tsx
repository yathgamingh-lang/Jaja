import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Mic, MicOff, Power, Radio, Sparkles, Zap, Shield, Cpu, Box, Camera, VolumeX } from 'lucide-react';
import { AssistantState, AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';
import { AudioPlayer } from '../modules/AudioPlayer.ts';
import { N3kAvatar3D, CameraPreset3D } from './N3kAvatar3D.tsx';
import hologramCoreImg from '../assets/images/zinxn3k_hologram_core_1790438207631.jpg';
import fallbackArmoredSvg from '../assets/images/zinxn3k_armored_avatar.svg';

interface HolographicAvatarProps {
  state: AssistantState;
  theme: AssistantTheme;
  userLevel: number;
  assistantLevel: number;
  isMuted: boolean;
  audioPlayer?: AudioPlayer;
  onToggleConnect: () => void;
}

export const HolographicAvatar: React.FC<HolographicAvatarProps> = ({
  state,
  theme,
  userLevel,
  assistantLevel,
  isMuted,
  audioPlayer,
  onToggleConnect,
}) => {
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];
  const particleCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const [imgSrc, setImgSrc] = useState<string>(hologramCoreImg);
  const [motionOffset, setMotionOffset] = useState({ x: 0, y: 0, rot: 0, eyeGlow: 0.4 });
  // Default to the real articulated 3D rig (N3kAvatar3D) rather than the 2D canvas/image
  // "armored_core" hologram, so N3k is a genuine 3D character out of the box. The toggle
  // below still lets the user switch back to the 2D hologram look if they prefer it.
  // N3k's real VRM is the primary avatar. Keep the legacy 2D implementation in
  // the source for backwards compatibility, but never switch the main avatar to it.
  const avatarMode: '3d_rig' = '3d_rig';
  const [camPreset, setCamPreset] = useState<CameraPreset3D>('portrait');

  // Real-time audio dynamic intensity
  const dynamicLevel =
    state === 'speaking' ? assistantLevel : state === 'listening' ? userLevel : 0;
  const corePulseScale = 1 + dynamicLevel * 0.45;
  const shockwaveScale1 = 1 + dynamicLevel * 0.85;
  const shockwaveScale2 = 1 + dynamicLevel * 1.35;

  // Real-time Holographic Particle, Scanline, & Audio-Reactive Motion Engine
  useEffect(() => {
    const canvas = particleCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let t = 0;
    const freqData = new Uint8Array(64);

    const particles = Array.from({ length: 42 }, () => ({
      x: Math.random() * 360,
      y: Math.random() * 440,
      r: 0.8 + Math.random() * 2.2,
      vy: 0.35 + Math.random() * 0.9,
      vx: (Math.random() - 0.5) * 0.4,
      alpha: 0.25 + Math.random() * 0.65,
    }));

    const render = () => {
      t += 0.035;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Compute real AudioContext frequency energy if speaking
      let bassEnergy = 0;
      let trebleEnergy = 0;
      if (state === 'speaking' && audioPlayer) {
        const analyser = audioPlayer.getAnalyser();
        if (analyser) {
          analyser.getByteFrequencyData(freqData);
          let bSum = 0;
          let tSum = 0;
          for (let i = 0; i < 12; i++) bSum += freqData[i];
          for (let i = 12; i < 40; i++) tSum += freqData[i];
          bassEnergy = bSum / (12 * 255);
          trebleEnergy = tSum / (28 * 255);
        } else {
          bassEnergy = assistantLevel;
          trebleEnergy = assistantLevel * 0.8;
        }
      } else if (state === 'listening') {
        bassEnergy = userLevel * 0.9;
        trebleEnergy = userLevel * 0.6;
      }

      // Update subtle head/body breathing & speaking motion at ~20fps equivalent
      const breathY =
        Math.sin(t * (state === 'speaking' ? 2.4 : 1.1)) *
        (state === 'speaking' ? 4 + bassEnergy * 8 : 3);
      const swayX =
        Math.cos(t * (state === 'speaking' ? 1.8 : 0.7)) *
        (state === 'speaking' ? 3 + trebleEnergy * 5 : 1.5);
      const tilt =
        Math.sin(t * (state === 'speaking' ? 2.1 : 0.6)) *
        (state === 'speaking' ? 1.2 + bassEnergy * 2.5 : 0.4);
      const eyeGlow =
        state === 'speaking'
          ? 0.7 + bassEnergy * 0.3
          : state === 'listening'
            ? 0.65 + userLevel * 0.35
            : state === 'thinking' || state === 'connecting'
              ? 0.5 + Math.abs(Math.sin(t * 3)) * 0.5
              : 0.35 + Math.sin(t) * 0.1;

      setMotionOffset({ x: swayX, y: breathY, rot: tilt, eyeGlow });

      // Draw rising holographic cyan energy particles
      const speedMult =
        state === 'speaking'
          ? 2.6 + bassEnergy * 3
          : state === 'thinking' || state === 'connecting'
            ? 2.2
            : state === 'listening'
              ? 1.5 + userLevel * 2
              : 0.8;

      particles.forEach((p) => {
        p.y -= p.vy * speedMult;
        p.x += p.vx + Math.sin(t + p.y * 0.02) * 0.25;
        if (p.y < -10) {
          p.y = canvas.height + 10;
          p.x = Math.random() * canvas.width;
        }
        if (p.x < 0) p.x = canvas.width;
        if (p.x > canvas.width) p.x = 0;

        ctx.save();
        ctx.globalAlpha = p.alpha * (0.6 + Math.sin(t * 2 + p.x) * 0.4);
        ctx.fillStyle = themeConfig.primary;
        ctx.shadowColor = themeConfig.primary;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r * (1 + bassEnergy * 0.7), 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw thinking / scanning laser beam
      if (state === 'thinking' || state === 'connecting' || state === 'speaking') {
        const beamY = ((Math.sin(t * 1.6) + 1) * 0.5) * canvas.height;
        const grad = ctx.createLinearGradient(0, beamY - 18, 0, beamY + 18);
        grad.addColorStop(0, 'rgba(0, 229, 255, 0)');
        grad.addColorStop(0.5, `${themeConfig.primary}55`);
        grad.addColorStop(1, 'rgba(0, 229, 255, 0)');
        ctx.fillStyle = grad;
        ctx.fillRect(0, beamY - 18, canvas.width, 36);
      }

      // Draw circular audio frequency visualizer around chest core when speaking/listening
      if (state === 'speaking' || state === 'listening') {
        const cx = canvas.width / 2;
        const cy = canvas.height * 0.58;
        const baseRadius = 46;
        const bars = 32;
        ctx.save();
        ctx.strokeStyle = themeConfig.primary;
        ctx.lineWidth = 2;
        for (let i = 0; i < bars; i++) {
          const angle = (i / bars) * Math.PI * 2 + t * 0.5;
          const val =
            state === 'speaking'
              ? (freqData[i % 24] || 40) / 255
              : userLevel * (0.5 + Math.abs(Math.sin(i + t * 4)) * 0.7);
          const barLen = 4 + val * 26;
          const x1 = cx + Math.cos(angle) * baseRadius;
          const y1 = cy + Math.sin(angle) * baseRadius;
          const x2 = cx + Math.cos(angle) * (baseRadius + barLen);
          const y2 = cy + Math.sin(angle) * (baseRadius + barLen);
          ctx.globalAlpha = 0.45 + val * 0.55;
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }
        ctx.restore();
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [state, themeConfig.primary, userLevel, assistantLevel, audioPlayer]);

  const statusLabel = useMemo(() => {
    switch (state) {
      case 'disconnected':
        return 'HOLOGRAM IDLE · TAP CORE TO AWAKEN';
      case 'connecting':
        return 'INITIALIZING GEMINI LIVE NEURAL BRIDGE...';
      case 'thinking':
        return 'PROCESSING COGNITIVE MATRIX...';
      case 'listening':
        return isMuted ? 'MICROPHONE MUTED' : 'LISTENING · VOICE COMMANDS ACTIVE';
      case 'speaking':
        return 'ZINXN3K SPEAKING · AUDIO REACTIVE';
      case 'error':
        return 'SYSTEM ALERT · TAP TO RECONNECT';
      default:
        return 'ONLINE';
    }
  }, [state, isMuted]);

  return (
    <div className="relative flex flex-col items-center justify-center select-none w-full max-w-[360px] sm:max-w-[420px] mx-auto">
      {/* Top Mode & 3D Camera Controls Bar (Preserves Armored Core + Integrates 3D Rig & Stop Speaking) */}
      <div className="relative z-30 mb-2 flex flex-wrap items-center justify-center gap-1.5 px-2.5 py-1 rounded-full bg-[#060916]/85 border border-cyan-400/30 backdrop-blur-xl shadow-lg font-mono text-[9px]">
        <div
          className="flex items-center gap-1 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider border bg-cyan-500/25 border-cyan-400 text-cyan-200"
          title="N3k is rendered from the real VRM 3D model"
        >
          <Box className="w-3 h-3 text-cyan-400" />
          <span>3D HOLO-RIG · PRIMARY</span>
        </div>

        {avatarMode === '3d_rig' && (
          <div className="flex items-center gap-1">
            <Camera className="w-2.5 h-2.5 text-cyan-400 ml-1" />
            {(['portrait', 'close_up', 'upper_body', 'cinematic'] as CameraPreset3D[]).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => {
                  setCamPreset(p);
                  window.dispatchEvent(new CustomEvent('n3k:camera3d:preset', { detail: { preset: p } }));
                }}
                className={`px-1.5 py-0.5 rounded-md uppercase transition-all ${
                  camPreset === p
                    ? 'bg-cyan-500/25 text-cyan-200 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {p.replace('_', ' ')}
              </button>
            ))}
          </div>
        )}

        {state === 'speaking' && (
          <button
            type="button"
            onClick={() => {
              if (audioPlayer) audioPlayer.stop();
              window.dispatchEvent(new CustomEvent('n3k:speech:stop'));
            }}
            className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-rose-500/20 hover:bg-rose-500/35 border border-rose-400/50 text-rose-200 font-bold uppercase tracking-wider transition-all"
            title="Stop Speaking Immediately"
          >
            <VolumeX className="w-3 h-3 text-rose-400" />
            <span>STOP</span>
          </button>
        )}
      </div>

      {avatarMode === '3d_rig' && audioPlayer ? (
        <N3kAvatar3D
          state={state}
          theme={theme}
          userLevel={userLevel}
          assistantLevel={assistantLevel}
          isMuted={isMuted}
          audioPlayer={audioPlayer}
          onToggleConnect={onToggleConnect}
        />
      ) : (
        <>
      {/* Outer Holographic Projection Glow */}
      <div
        className="absolute -inset-8 rounded-full transition-all duration-700 pointer-events-none blur-3xl opacity-45"
        style={{
          background: themeConfig.bgGlow,
          transform: `scale(${state === 'speaking' ? 1.35 : state === 'listening' ? 1.2 : 1})`,
        }}
      />

      {/* Holographic Containment Chamber */}
      <div className="relative w-full aspect-[4/5] max-h-[390px] sm:max-h-[440px] flex items-center justify-center">
        {/* Rotating Holographic Rings SVG */}
        <svg
          className="absolute inset-0 w-full h-full pointer-events-none"
          viewBox="0 0 400 500"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {/* Outer Rotating Ring */}
          <circle
            cx="200"
            cy="240"
            r="185"
            stroke={themeConfig.primary}
            strokeWidth="1.2"
            strokeDasharray="6 10"
            opacity={state === 'disconnected' ? '0.25' : '0.6'}
            className="animate-[spin_36s_linear_infinite]"
            style={{ transformOrigin: '200px 240px' }}
          />
          {/* Counter-Rotating Tactical Ring */}
          <circle
            cx="200"
            cy="240"
            r="164"
            stroke={themeConfig.secondary}
            strokeWidth="1.5"
            strokeDasharray="22 14 8 14"
            opacity={state === 'disconnected' ? '0.2' : '0.65'}
            className="animate-[spin_22s_linear_infinite_reverse]"
            style={{ transformOrigin: '200px 240px' }}
          />
          {/* Inner Fast Ring during Thinking/Speaking */}
          <circle
            cx="200"
            cy="240"
            r="142"
            stroke={themeConfig.accent}
            strokeWidth="1"
            strokeDasharray="4 8"
            opacity={state === 'thinking' || state === 'speaking' ? '0.75' : '0.25'}
            className="animate-[spin_12s_linear_infinite]"
            style={{ transformOrigin: '200px 240px' }}
          />

          {/* Holographic Corner Brackets */}
          <path d="M 35 75 L 35 35 L 75 35" stroke={themeConfig.primary} strokeWidth="2" opacity="0.7" />
          <path d="M 365 75 L 365 35 L 325 35" stroke={themeConfig.primary} strokeWidth="2" opacity="0.7" />
          <path d="M 35 425 L 35 465 L 75 465" stroke={themeConfig.primary} strokeWidth="2" opacity="0.7" />
          <path d="M 365 425 L 365 465 L 325 465" stroke={themeConfig.primary} strokeWidth="2" opacity="0.7" />
        </svg>

        {/* Audio Shockwave Ripples from Chest Core */}
        {(state === 'speaking' || state === 'listening') && (
          <>
            <div
              className="absolute w-40 h-40 rounded-full border transition-transform duration-75 pointer-events-none animate-ping"
              style={{
                top: '58%',
                left: '50%',
                marginTop: '-5rem',
                marginLeft: '-5rem',
                borderColor: themeConfig.primary,
                opacity: Math.max(0.15, dynamicLevel * 0.55),
                transform: `scale(${shockwaveScale2})`,
                animationDuration: state === 'speaking' ? '1.4s' : '2.1s',
              }}
            />
            <div
              className="absolute w-32 h-32 rounded-full border transition-transform duration-100 pointer-events-none"
              style={{
                top: '58%',
                left: '50%',
                marginTop: '-4rem',
                marginLeft: '-4rem',
                borderColor: themeConfig.secondary,
                opacity: Math.max(0.25, dynamicLevel * 0.8),
                transform: `scale(${shockwaveScale1})`,
                boxShadow: `0 0 24px ${themeConfig.glow}`,
              }}
            />
          </>
        )}

        {/* Main Holographic Armored AI Viewport */}
        <div
          onClick={onToggleConnect}
          className="group relative w-[86%] h-[88%] rounded-3xl overflow-hidden cursor-pointer transition-all duration-300 flex items-center justify-center border border-cyan-400/30 hover:border-cyan-300/70 shadow-2xl bg-[#040711]/80 backdrop-blur-md"
          style={{
            boxShadow:
              state === 'speaking'
                ? `0 0 50px ${themeConfig.glow}, inset 0 0 35px ${themeConfig.glow}`
                : state === 'listening'
                  ? `0 0 35px ${themeConfig.glow}, inset 0 0 20px ${themeConfig.glow}`
                  : state === 'thinking' || state === 'connecting'
                    ? `0 0 40px rgba(168,85,247,0.45), inset 0 0 25px ${themeConfig.glow}`
                    : `0 12px 45px rgba(0,0,0,0.85), inset 0 0 20px ${themeConfig.glow}`,
          }}
          title={state === 'disconnected' ? 'Tap to awaken ZinxN3k Voice AI' : 'Tap to disconnect'}
        >
          {/* Animated Character Layer (Breathing, Head/Body sway, Audio-reactive pulse) */}
          <div
            className="relative w-full h-full transition-transform duration-100 ease-out"
            style={{
              transform: `translate3d(${motionOffset.x}px, ${motionOffset.y}px, 0) rotate(${motionOffset.rot}deg) scale(${
                1.03 + dynamicLevel * 0.05
              })`,
            }}
          >
            <img
              src={imgSrc}
              onError={() => setImgSrc(fallbackArmoredSvg)}
              alt="ZinxN3k Futuristic Armored AI Hologram"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-top transition-all duration-300"
              style={{
                filter:
                  state === 'speaking'
                    ? `brightness(1.22) contrast(1.18) saturate(1.25) drop-shadow(0 0 22px ${themeConfig.primary})`
                    : state === 'listening'
                      ? `brightness(1.12) contrast(1.12) saturate(1.15) drop-shadow(0 0 14px ${themeConfig.primary})`
                      : state === 'thinking' || state === 'connecting'
                        ? `brightness(1.15) contrast(1.2) hue-rotate(15deg)`
                        : `brightness(0.95) contrast(1.1)`,
              }}
            />

            {/* Animated Glowing Eyes / Optical Visor Overlay */}
            <div
              className="absolute inset-x-0 top-[26%] h-10 pointer-events-none flex items-center justify-center transition-opacity duration-150"
              style={{
                opacity: motionOffset.eyeGlow,
                background: `radial-gradient(ellipse 32% 45% at 50% 50%, ${themeConfig.primary}66, transparent 75%)`,
                mixBlendMode: 'screen',
              }}
            />
          </div>

          {/* Live Canvas for Hologram Particles, Scan Beams & Radial Audio Visualizer */}
          <canvas
            ref={particleCanvasRef}
            width={360}
            height={440}
            className="absolute inset-0 w-full h-full pointer-events-none z-10"
          />

          {/* Holographic Scanlines Overlay */}
          <div
            className="absolute inset-0 pointer-events-none mix-blend-screen opacity-40 z-10"
            style={{
              backgroundImage: `repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(0, 229, 255, 0.09) 3px, rgba(0, 229, 255, 0.09) 4px)`,
            }}
          />

          {/* Vignette & Edge Glow */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#04060d] via-transparent to-[#04060d]/50 pointer-events-none z-10" />

          {/* Top HUD Stamp inside Hologram Chamber */}
          <div className="absolute top-3 left-3 right-3 flex items-center justify-between text-[9px] font-mono pointer-events-none z-20">
            <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-black/65 border border-cyan-400/30 backdrop-blur-md text-cyan-300">
              <Cpu className="w-2.5 h-2.5 text-cyan-400" />
              <span>ZINXN3K · CORE PRIME</span>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-black/65 border border-cyan-400/30 backdrop-blur-md text-slate-200">
              <span
                className={`w-1.5 h-1.5 rounded-full ${
                  state !== 'disconnected' ? 'animate-ping' : ''
                }`}
                style={{ backgroundColor: themeConfig.primary }}
              />
              <span className="uppercase font-bold">{state}</span>
            </div>
          </div>

          {/* Interactive Chest Energy Core */}
          <div
            className="absolute z-20 flex flex-col items-center justify-center transition-transform duration-150 group-hover:scale-105"
            style={{
              top: '58%',
              left: '50%',
              transform: `translate(-50%, -50%) scale(${corePulseScale})`,
            }}
          >
            <div
              className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-full flex items-center justify-center border-2 backdrop-blur-xl transition-all duration-300"
              style={{
                borderColor:
                  state === 'speaking'
                    ? themeConfig.primary
                    : state === 'listening'
                      ? themeConfig.accent
                      : state === 'thinking' || state === 'connecting'
                        ? '#c084fc'
                        : 'rgba(0, 229, 255, 0.45)',
                backgroundColor: 'rgba(4, 8, 20, 0.72)',
                boxShadow:
                  state === 'speaking'
                    ? `0 0 35px ${themeConfig.primary}, inset 0 0 18px ${themeConfig.primary}`
                    : state === 'listening'
                      ? `0 0 26px ${themeConfig.accent}, inset 0 0 12px ${themeConfig.accent}`
                      : `0 0 18px ${themeConfig.glow}`,
              }}
            >
              <div
                className="absolute inset-1 rounded-full border border-dashed animate-spin pointer-events-none"
                style={{
                  borderColor: `${themeConfig.primary}aa`,
                  animationDuration: state === 'speaking' ? '3.5s' : '8s',
                }}
              />

              <div
                className={`w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center transition-all duration-200 ${
                  state === 'speaking'
                    ? 'animate-pulse'
                    : state === 'thinking' || state === 'connecting'
                      ? 'animate-spin'
                      : ''
                }`}
                style={{
                  background: `radial-gradient(circle, #ffffff 0%, ${themeConfig.primary} 65%, transparent 100%)`,
                }}
              >
                {state === 'disconnected' && (
                  <Power className="w-5 h-5 text-slate-950 drop-shadow-[0_0_6px_white]" />
                )}
                {(state === 'connecting' || state === 'thinking') && (
                  <Radio className="w-5 h-5 text-slate-950 animate-pulse" />
                )}
                {state === 'listening' &&
                  (isMuted ? (
                    <MicOff className="w-5 h-5 text-rose-900" />
                  ) : (
                    <Mic className="w-5 h-5 text-slate-950" />
                  ))}
                {state === 'speaking' && <Sparkles className="w-5 h-5 text-slate-950" />}
              </div>
            </div>

            <span
              className="mt-1.5 text-[8px] font-mono tracking-widest uppercase font-bold px-2 py-0.5 rounded-full bg-black/75 border border-cyan-400/30 backdrop-blur-sm"
              style={{
                color: state !== 'disconnected' ? themeConfig.primary : '#cbd5e1',
              }}
            >
              {state === 'disconnected' ? 'ACTIVATE CORE' : state}
            </span>
          </div>

          {/* Bottom HUD Readout inside Chamber */}
          <div className="absolute bottom-3 inset-x-3 flex items-center justify-between text-[9px] font-mono z-20 pointer-events-none">
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-black/65 border border-white/10 text-slate-300 backdrop-blur-sm">
              <Shield className="w-2.5 h-2.5 text-cyan-400" />
              <span>HOLO-PROJECTION: ACTIVE</span>
            </div>
            <div className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-black/65 border border-white/10 text-cyan-300 backdrop-blur-sm">
              <Zap className="w-2.5 h-2.5 text-cyan-400" />
              <span>VOICE: FENRIR</span>
            </div>
          </div>
        </div>
      </div>

      {/* State Caption Pill under Hologram */}
      <div className="mt-2.5 flex items-center gap-2 px-3.5 py-1 rounded-full bg-[#070b18]/85 border border-cyan-400/25 backdrop-blur-xl shadow-lg">
        <span
          className={`w-2 h-2 rounded-full ${
            state === 'speaking'
              ? 'animate-ping'
              : state === 'listening'
                ? 'animate-pulse'
                : state === 'connecting' || state === 'thinking'
                  ? 'animate-bounce'
                  : ''
          }`}
          style={{
            backgroundColor:
              state === 'disconnected'
                ? '#64748b'
                : state === 'connecting' || state === 'thinking'
                  ? '#a855f7'
                  : themeConfig.primary,
          }}
        />
        <span className="text-[10px] font-mono font-semibold tracking-wider text-slate-200 uppercase">
          {statusLabel}
        </span>
      </div>
        </>
      )}
    </div>
  );
};
