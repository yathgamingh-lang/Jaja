import React, { useState, useEffect } from 'react';
import {
  Brain,
  X,
  Plus,
  Download,
  Upload,
  Trash2,
  Sparkles,
  Info,
  Check,
  AlertTriangle,
} from 'lucide-react';
import { Memory, MemoryCategory, MEMORY_CATEGORIES } from '../memory/MemoryTypes.ts';
import { globalMemoryManager } from '../memory/MemoryManager.ts';
import { AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';
import { MemoryCard } from './MemoryCard.tsx';
import { MemorySearch } from './MemorySearch.tsx';

interface BrainPanelProps {
  isOpen: boolean;
  theme: AssistantTheme;
  onClose: () => void;
}

export const BrainPanel: React.FC<BrainPanelProps> = ({ isOpen, theme, onClose }) => {
  const [memories, setMemories] = useState<Memory[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<MemoryCategory | 'all'>('all');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [copiedExport, setCopiedExport] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importText, setImportText] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);

  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newCategory, setNewCategory] = useState<MemoryCategory>('identity');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];

  useEffect(() => {
    const unsubscribe = globalMemoryManager.subscribe((list) => {
      setMemories([...list]);
    });
    return () => unsubscribe();
  }, []);

  if (!isOpen) return null;

  const filteredMemories = memories.filter((m) => {
    const matchesCat = selectedCategory === 'all' || m.category === selectedCategory;
    if (!matchesCat) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      m.key.toLowerCase().includes(q) ||
      m.value.toLowerCase().includes(q) ||
      m.category.toLowerCase().includes(q)
    );
  });

  const handleUpdate = async (id: string, key: string, value: string) => {
    await globalMemoryManager.updateMemory(id, { key, value });
  };

  const handleDelete = async (id: string) => {
    await globalMemoryManager.deleteMemory(id);
  };

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey.trim() || !newValue.trim()) return;
    setIsSubmitting(true);
    try {
      await globalMemoryManager.saveMemory({
        category: newCategory,
        key: newKey.trim(),
        value: newValue.trim(),
        confidence: 1.0,
      });
      setNewKey('');
      setNewValue('');
      setShowAddForm(false);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleExport = async () => {
    const json = await globalMemoryManager.exportMemories();
    try {
      await navigator.clipboard.writeText(json);
      setCopiedExport(true);
      setTimeout(() => setCopiedExport(false), 2000);
    } catch {
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `zinxn3k_brain_memories_${Date.now()}.json`;
      a.click();
    }
  };

  const handleImport = async () => {
    if (!importText.trim()) return;
    try {
      const count = await globalMemoryManager.importMemories(importText.trim());
      setImportStatus(`Imported ${count} memories successfully!`);
      setTimeout(() => {
        setImportStatus(null);
        setShowImportModal(false);
        setImportText('');
      }, 1500);
    } catch (err: any) {
      setImportStatus(`Error: ${err.message}`);
    }
  };

  const handleClearAll = async () => {
    await globalMemoryManager.clearAllMemories();
    setShowClearConfirm(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-end sm:items-center justify-center sm:p-4 animate-in fade-in duration-200 select-none">
      <div className="w-full max-w-2xl bg-[#090c18] border border-white/12 sm:rounded-3xl rounded-t-3xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Header with Synaptic Brain Banner */}
        <div className="relative p-5 border-b border-white/10 flex items-center justify-between shrink-0 overflow-hidden">
          <div
            className="absolute -top-12 left-1/4 w-60 h-32 blur-3xl opacity-20 pointer-events-none rounded-full"
            style={{ backgroundColor: themeConfig.primary }}
          />

          <div className="flex items-center gap-3 relative z-10">
            <div
              className="w-10 h-10 rounded-2xl flex items-center justify-center border shadow-lg"
              style={{
                backgroundColor: `${themeConfig.primary}18`,
                borderColor: `${themeConfig.primary}44`,
                boxShadow: `0 0 16px ${themeConfig.glow}`,
              }}
            >
              <Brain className="w-5 h-5" style={{ color: themeConfig.primary }} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide font-mono uppercase">
                  ZINXN3K BRAIN
                </h2>
                <span
                  className="text-[10px] font-mono px-2 py-0.5 rounded-full font-bold tracking-wider uppercase tabular-nums"
                  style={{
                    backgroundColor: `${themeConfig.primary}25`,
                    color: themeConfig.primary,
                  }}
                >
                  {memories.length} {memories.length === 1 ? 'MEMORY' : 'MEMORIES'}
                </span>
              </div>
              <p className="text-[11px] font-mono text-slate-400">
                Persistent Long-Term Memory (IndexedDB)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 relative z-10">
            <button
              onClick={() => setShowAddForm(!showAddForm)}
              className="p-2 rounded-xl text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
              title="Add memory manually"
            >
              <Plus className="w-4 h-4" />
            </button>
            <button
              onClick={handleExport}
              className="p-2 rounded-xl text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
              title="Export memories"
            >
              {copiedExport ? (
                <Check className="w-4 h-4 text-emerald-400" />
              ) : (
                <Download className="w-4 h-4" />
              )}
            </button>
            <button
              onClick={() => setShowImportModal(true)}
              className="p-2 rounded-xl text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
              title="Import memories"
            >
              <Upload className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 ml-1 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Manual Add Memory Form */}
        {showAddForm && (
          <form
            onSubmit={handleAddSubmit}
            className="p-4 bg-slate-900/90 border-b border-white/10 space-y-3 shrink-0 animate-in slide-in-from-top-2 duration-200"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Store New Memory</span>
              </span>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
                  Key
                </label>
                <input
                  type="text"
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  placeholder="e.g. favorite_game, name"
                  className="w-full bg-slate-950 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                  required
                />
              </div>
              <div>
                <label className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
                  Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as MemoryCategory)}
                  className="w-full bg-slate-950 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400"
                >
                  {MEMORY_CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="text-[10px] font-mono uppercase text-slate-400 block mb-1">
                Value / Fact
              </label>
              <textarea
                rows={2}
                value={newValue}
                onChange={(e) => setNewValue(e.target.value)}
                placeholder="e.g. Minecraft, Yatharth, Enjoys playing tactical games"
                className="w-full bg-slate-950 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400 resize-none"
                required
              />
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={isSubmitting || !newKey.trim() || !newValue.trim()}
                className="px-4 py-1.5 rounded-xl text-xs font-bold text-black shadow-md transition-all active:scale-95 disabled:opacity-50"
                style={{ backgroundColor: themeConfig.primary }}
              >
                {isSubmitting ? 'Saving...' : 'Remember Fact'}
              </button>
            </div>
          </form>
        )}

        {/* Search & Category Filter */}
        <div className="p-4 border-b border-white/5 space-y-3 shrink-0">
          <MemorySearch value={searchQuery} theme={theme} onChange={setSearchQuery} />

          {/* Horizontal Category Scroll */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar text-xs">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1 rounded-full whitespace-nowrap font-mono text-[11px] transition-all ${
                selectedCategory === 'all'
                  ? 'bg-white/20 text-white font-bold border border-white/30'
                  : 'bg-white/5 text-slate-400 hover:text-white border border-white/5'
              }`}
            >
              All ({memories.length})
            </button>
            {MEMORY_CATEGORIES.map((cat) => {
              const count = memories.filter((m) => m.category === cat.id).length;
              if (count === 0 && selectedCategory !== cat.id) return null;
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCategory(cat.id)}
                  className={`px-3 py-1 rounded-full whitespace-nowrap font-mono text-[11px] transition-all flex items-center gap-1.5 ${
                    selectedCategory === cat.id
                      ? 'bg-white/20 text-white font-bold border border-white/30'
                      : 'bg-white/5 text-slate-400 hover:text-white border border-white/5'
                  }`}
                  style={{
                    borderColor: selectedCategory === cat.id ? themeConfig.primary : undefined,
                  }}
                >
                  <span>{cat.label}</span>
                  <span className="opacity-70 text-[10px]">({count})</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Memories List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filteredMemories.length === 0 ? (
            <div className="py-12 px-4 flex flex-col items-center justify-center text-center">
              <div
                className="w-12 h-12 rounded-2xl flex items-center justify-center mb-3"
                style={{ backgroundColor: `${themeConfig.primary}15` }}
              >
                <Brain className="w-6 h-6" style={{ color: themeConfig.primary }} />
              </div>
              <h3 className="text-sm font-bold text-white mb-1">
                {memories.length === 0 ? 'No Memories Stored Yet' : 'No Matching Memories'}
              </h3>
              <p className="text-xs text-slate-400 max-w-sm leading-relaxed mb-4">
                {memories.length === 0
                  ? 'Say "Remember my name is Yatharth" or "I love gaming" to ZinxN3k, and he will automatically save it in his persistent brain!'
                  : 'Try searching for another keyword or selecting a different category filter.'}
              </p>
              {memories.length === 0 && (
                <button
                  onClick={() => setShowAddForm(true)}
                  className="px-4 py-2 rounded-xl text-xs font-semibold text-black shadow-md flex items-center gap-1.5"
                  style={{ backgroundColor: themeConfig.primary }}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add First Memory</span>
                </button>
              )}
            </div>
          ) : (
            filteredMemories.map((mem) => (
              <MemoryCard
                key={mem.id}
                memory={mem}
                theme={theme}
                onUpdate={handleUpdate}
                onDelete={handleDelete}
              />
            ))
          )}
        </div>

        {/* Footer controls */}
        <div className="p-3.5 border-t border-white/10 bg-slate-950/60 shrink-0 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 text-slate-400 text-[11px] font-mono">
            <Info className="w-3.5 h-3.5 text-cyan-400" />
            <span>Spoken voice commands save memories automatically</span>
          </div>
          {memories.length > 0 && (
            <button
              onClick={() => setShowClearConfirm(true)}
              className="text-xs text-rose-400 hover:text-rose-300 flex items-center gap-1 px-2.5 py-1 rounded-lg hover:bg-rose-500/10 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear All</span>
            </button>
          )}
        </div>
      </div>

      {/* Clear All Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="w-full max-w-sm bg-[#0e1224] border border-rose-500/40 rounded-3xl p-6 text-center space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-rose-500/20 text-rose-400 mx-auto flex items-center justify-center">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Wipe ZinxN3k Brain?</h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                This will delete all {memories.length} stored memories about you. ZinxN3k will no
                longer remember your name, favorites, or preferences.
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 rounded-xl border border-white/10 text-xs text-slate-300 hover:bg-white/10"
              >
                Keep Memories
              </button>
              <button
                onClick={handleClearAll}
                className="px-4 py-2 rounded-xl bg-rose-600 text-xs font-bold text-white hover:bg-rose-500 shadow-lg"
              >
                Wipe Everything
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Import Modal */}
      {showImportModal && (
        <div className="fixed inset-0 z-60 bg-black/80 flex items-center justify-center p-4">
          <div className="w-full max-w-md bg-[#0e1224] border border-white/15 rounded-3xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white font-mono uppercase">
                Import Memories JSON
              </h3>
              <button
                onClick={() => setShowImportModal(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-400">
              Paste exported JSON array of memories below:
            </p>
            <textarea
              rows={6}
              value={importText}
              onChange={(e) => setImportText(e.target.value)}
              placeholder='[ { "category": "identity", "key": "name", "value": "Yatharth" } ]'
              className="w-full bg-slate-950 border border-white/15 rounded-xl p-3 text-xs text-white font-mono focus:outline-none focus:border-cyan-400"
            />
            {importStatus && <p className="text-xs text-cyan-300 font-mono">{importStatus}</p>}
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowImportModal(false)}
                className="px-3 py-1.5 rounded-xl border border-white/10 text-xs text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleImport}
                className="px-3 py-1.5 rounded-xl bg-cyan-400 text-xs font-bold text-black"
              >
                Import
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
