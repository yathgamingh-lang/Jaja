import React, { useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  RotateCw,
  X,
  Globe,
  ExternalLink,
  Search,
  Lock,
  Sparkles,
  Maximize2,
  Minimize2,
  Play,
  Pause,
  Square,
  Volume2,
  Youtube,
  ShieldAlert,
  Compass,
} from 'lucide-react';
import { AssistantTheme, BrowserTabState, YouTubeSearchResultItem } from '../types/assistant.ts';
import { THEME_CONFIGS, globalStateManager } from '../modules/StateManager.ts';
import { globalBrowserProvider } from '../modules/BrowserProvider.ts';

interface IntegratedBrowserProps {
  browserState: BrowserTabState;
  theme: AssistantTheme;
  onClose: () => void;
}

const QUICK_SITES = [
  { name: 'Google Search', url: 'https://www.google.com/webhp?igu=1', icon: '🔍' },
  { name: 'YouTube Hub', url: 'https://www.youtube.com', icon: '▶️' },
  { name: 'Wikipedia', url: 'https://en.wikipedia.org', icon: '🌐' },
  { name: 'DuckDuckGo', url: 'https://duckduckgo.com', icon: '🦆' },
  { name: 'Hacker News', url: 'https://news.ycombinator.com', icon: '⚡' },
];

export const IntegratedBrowser: React.FC<IntegratedBrowserProps> = ({
  browserState,
  theme,
  onClose,
}) => {
  const config = THEME_CONFIGS[theme];
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [historyStack, setHistoryStack] = useState<
    Array<{
      url: string;
      title: string;
      mode: 'web' | 'youtube';
      youtubeQuery?: string;
      youtubeVideoId?: string;
      displayUrl?: string;
      isIframeBlocked?: boolean;
      blockReason?: string | null;
    }>
  >([
    {
      url: browserState.url,
      title: browserState.title,
      mode: browserState.mode,
      youtubeQuery: browserState.youtubeQuery,
      youtubeVideoId: browserState.youtubeVideoId,
      displayUrl: browserState.inputUrl,
      isIframeBlocked: browserState.isIframeBlocked,
      blockReason: browserState.blockReason,
    },
  ]);
  const [historyIndex, setHistoryIndex] = useState(0);

  // Sync external navigation into history stack only when browser is open
  useEffect(() => {
    if (!browserState.isOpen) return;
    const currentEntry = historyStack[historyIndex];
    if (
      !currentEntry ||
      currentEntry.url !== browserState.url ||
      currentEntry.youtubeVideoId !== browserState.youtubeVideoId
    ) {
      const nextStack = historyStack.slice(0, historyIndex + 1);
      nextStack.push({
        url: browserState.url,
        title: browserState.title,
        mode: browserState.mode,
        youtubeQuery: browserState.youtubeQuery,
        youtubeVideoId: browserState.youtubeVideoId,
        displayUrl: browserState.inputUrl,
        isIframeBlocked: browserState.isIframeBlocked,
        blockReason: browserState.blockReason,
      });
      const nextIndex = nextStack.length - 1;
      setHistoryStack(nextStack);
      setHistoryIndex(nextIndex);
      globalStateManager.setBrowserNavState(nextIndex > 0, false);
    }
  }, [browserState.isOpen, browserState.url, browserState.youtubeVideoId]);

  const sendYouTubePostMessage = (func: string, args: any[] = []) => {
    if (iframeRef.current && iframeRef.current.contentWindow) {
      try {
        iframeRef.current.contentWindow.postMessage(
          JSON.stringify({
            event: 'command',
            func,
            args,
          }),
          '*',
        );
      } catch (e) {
        console.warn('[IntegratedBrowser] postMessage error:', e);
      }
    }
  };

  useEffect(() => {
    const handleMediaCommand = (e: Event) => {
      const customEvent = e as CustomEvent<{ command: string; volume?: number }>;
      const { command, volume } = customEvent.detail || {};
      if (command === 'pause') {
        sendYouTubePostMessage('pauseVideo');
      } else if (command === 'play') {
        sendYouTubePostMessage('playVideo');
      } else if (command === 'stop') {
        sendYouTubePostMessage('stopVideo');
      } else if (command === 'volume' && typeof volume === 'number') {
        sendYouTubePostMessage('setVolume', [volume]);
      }
    };

    const handleReload = () => {
      if (iframeRef.current) {
        globalStateManager.setBrowserLoading(true);
        const currentSrc = iframeRef.current.src;
        iframeRef.current.src = currentSrc;
      }
    };

    const handleBack = () => {
      if (historyIndex > 0) {
        const prevIndex = historyIndex - 1;
        const target = historyStack[prevIndex];
        setHistoryIndex(prevIndex);
        globalStateManager.setBrowserUrl(
          target.url,
          target.title,
          target.mode,
          target.youtubeQuery,
          target.youtubeVideoId,
          target.displayUrl,
          Boolean(target.isIframeBlocked),
          target.blockReason || null,
        );
        globalStateManager.setBrowserNavState(prevIndex > 0, true);
      }
    };

    const handleForward = () => {
      if (historyIndex < historyStack.length - 1) {
        const nextIndex = historyIndex + 1;
        const target = historyStack[nextIndex];
        setHistoryIndex(nextIndex);
        globalStateManager.setBrowserUrl(
          target.url,
          target.title,
          target.mode,
          target.youtubeQuery,
          target.youtubeVideoId,
          target.displayUrl,
          Boolean(target.isIframeBlocked),
          target.blockReason || null,
        );
        globalStateManager.setBrowserNavState(true, nextIndex < historyStack.length - 1);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && browserState.isOpen) {
        setIsFullScreen(false);
        onClose();
      }
    };

    window.addEventListener('zinxn3k:media:command', handleMediaCommand);
    window.addEventListener('zinxn3k:browser:reload', handleReload);
    window.addEventListener('zinxn3k:browser:back', handleBack);
    window.addEventListener('zinxn3k:browser:forward', handleForward);
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('zinxn3k:media:command', handleMediaCommand);
      window.removeEventListener('zinxn3k:browser:reload', handleReload);
      window.removeEventListener('zinxn3k:browser:back', handleBack);
      window.removeEventListener('zinxn3k:browser:forward', handleForward);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [historyIndex, historyStack, browserState.isOpen, onClose]);

  // CRITICAL FIX: Do NOT render the browser overlay when browserState.isOpen is false!
  if (!browserState.isOpen) {
    return null;
  }

  const navigateToResolved = async (rawInput: string, customTitle?: string) => {
    const resolved = globalBrowserProvider.resolveTarget(rawInput, customTitle);
    globalStateManager.setBrowserUrl(
      resolved.url,
      resolved.title,
      resolved.mode,
      resolved.youtubeQuery,
      resolved.youtubeVideoId,
      resolved.displayUrl,
      resolved.isFrameRestricted,
      resolved.blockReason || null,
    );

    if (resolved.mode === 'youtube' && resolved.youtubeQuery) {
      const results = await globalBrowserProvider.searchYouTube(resolved.youtubeQuery);
      globalStateManager.setYouTubeResults(results);
      if (results.length > 0 && !resolved.youtubeVideoId) {
        const first = results[0];
        globalStateManager.setBrowserUrl(
          `https://www.youtube.com/embed/${first.videoId}?enablejsapi=1`,
          first.title,
          'youtube',
          resolved.youtubeQuery,
          first.videoId,
          `https://www.youtube.com/watch?v=${first.videoId}`,
          false,
          null,
        );
        globalStateManager.setYouTubeResults(results);
      }
    }
  };

  const handleNavigateSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const raw = browserState.inputUrl.trim();
    if (!raw) return;
    await navigateToResolved(raw);
  };

  const handleSelectYouTubeVideo = (item: YouTubeSearchResultItem) => {
    const embedUrl = `https://www.youtube.com/embed/${item.videoId}?autoplay=1&enablejsapi=1`;
    const watchUrl = `https://www.youtube.com/watch?v=${item.videoId}`;
    globalStateManager.setBrowserUrl(
      embedUrl,
      item.title,
      'youtube',
      browserState.youtubeQuery,
      item.videoId,
      watchUrl,
      false,
      null,
    );
    globalStateManager.setBrowserMediaPlaying(true);
  };

  const handleTogglePlayPause = () => {
    if (browserState.isPlaying) {
      sendYouTubePostMessage('pauseVideo');
      globalStateManager.setBrowserMediaPlaying(false);
    } else {
      sendYouTubePostMessage('playVideo');
      globalStateManager.setBrowserMediaPlaying(true);
    }
  };

  const handleStopMedia = () => {
    sendYouTubePostMessage('stopVideo');
    globalStateManager.setBrowserMediaPlaying(false);
  };

  const handleCloseBrowser = (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setIsFullScreen(false);
    globalStateManager.setBrowserOpen(false);
    onClose();
  };

  return (
    <div
      className={`fixed z-[85] transition-all duration-300 flex flex-col rounded-2xl overflow-hidden backdrop-blur-2xl border shadow-[0_20px_80px_rgba(0,0,0,0.85)] ${
        isFullScreen
          ? 'inset-3 sm:inset-5'
          : 'inset-x-3 top-16 bottom-24 sm:inset-x-12 md:inset-x-20 lg:inset-x-28 sm:top-16 sm:bottom-24'
      }`}
      style={{
        backgroundColor: 'rgba(6, 9, 20, 0.96)',
        borderColor: `${config.primary}66`,
        boxShadow: `0 25px 70px rgba(0,0,0,0.9), 0 0 35px ${config.glow}`,
      }}
    >
      {/* Top Holographic Browser Navigation Bar */}
      <div className="flex flex-col border-b border-white/10 bg-[#050814]/95">
        <div className="flex items-center justify-between px-3 sm:px-4 py-2.5 gap-2">
          {/* Left Navigation Controls */}
          <div className="flex items-center gap-1.5">
            <div className="hidden sm:flex items-center gap-1.5 mr-2 px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/30">
              <Globe className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-mono text-[10px] font-bold tracking-widest uppercase text-cyan-200">
                N3k Browser
              </span>
            </div>

            <button
              type="button"
              onClick={() => window.dispatchEvent(new CustomEvent('zinxn3k:browser:back'))}
              disabled={!browserState.canGoBack}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 text-slate-300 transition-colors"
              title="Back"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => window.dispatchEvent(new CustomEvent('zinxn3k:browser:forward'))}
              disabled={!browserState.canGoForward}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 disabled:opacity-30 text-slate-300 transition-colors"
              title="Forward"
            >
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={() => window.dispatchEvent(new CustomEvent('zinxn3k:browser:reload'))}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
              title="Reload"
            >
              <RotateCw className={`w-4 h-4 ${browserState.isLoading ? 'animate-spin text-cyan-400' : ''}`} />
            </button>
          </div>

          {/* Center URL / Search Input Bar */}
          <form onSubmit={handleNavigateSubmit} className="flex-1 max-w-2xl">
            <div className="relative flex items-center">
              <div className="absolute left-3 flex items-center gap-1.5 pointer-events-none">
                {browserState.mode === 'youtube' ? (
                  <Youtube className="w-3.5 h-3.5 text-rose-400" />
                ) : (
                  <Lock className="w-3 h-3 text-emerald-400" />
                )}
              </div>
              <input
                type="text"
                value={browserState.inputUrl}
                onChange={(e) => globalStateManager.setBrowserInputUrl(e.target.value)}
                placeholder="Enter URL, search Google, or say 'Play ... on YouTube'..."
                className="w-full pl-8 pr-20 py-1.5 rounded-xl bg-black/60 border border-white/15 focus:border-cyan-400/60 text-xs sm:text-sm text-slate-100 font-mono focus:outline-none transition-colors"
              />
              <button
                type="submit"
                className="absolute right-1.5 px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/30 text-[10px] font-mono font-bold uppercase tracking-wider text-cyan-200 transition-colors flex items-center gap-1"
              >
                <Search className="w-3 h-3" />
                <span>GO</span>
              </button>
            </div>
          </form>

          {/* Right Window Controls — Including prominent Close (X) button */}
          <div className="flex items-center gap-1.5">
            <a
              href={browserState.inputUrl.startsWith('http') ? browserState.inputUrl : browserState.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-cyan-300 transition-colors"
              title="Open in External Browser Tab"
            >
              <ExternalLink className="w-4 h-4" />
            </a>

            <button
              type="button"
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 transition-colors"
              title={isFullScreen ? 'Restore Window Size' : 'Maximize Browser'}
            >
              {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={handleCloseBrowser}
              aria-label="Close Browser"
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/35 border border-rose-500/40 text-rose-200 transition-all cursor-pointer"
              title="Close Browser (Esc)"
            >
              <X className="w-4 h-4" />
              <span className="hidden sm:inline font-mono text-[10px] font-bold uppercase tracking-wider">
                Close
              </span>
            </button>
          </div>
        </div>

        {/* Quick Bookmarks & YouTube Media Control Sub-Bar */}
        <div className="flex items-center justify-between px-3 sm:px-4 py-1.5 border-t border-white/5 bg-black/40 overflow-x-auto no-scrollbar gap-3">
          <div className="flex items-center gap-1.5 shrink-0">
            <Compass className="w-3 h-3 text-slate-500 mr-1" />
            {QUICK_SITES.map((site) => (
              <button
                key={site.name}
                type="button"
                onClick={() => navigateToResolved(site.url, site.name)}
                className="px-2 py-0.5 rounded-md bg-white/[0.04] hover:bg-cyan-500/15 border border-white/10 hover:border-cyan-400/30 text-[10px] font-mono text-slate-300 hover:text-cyan-200 transition-colors flex items-center gap-1 shrink-0"
              >
                <span>{site.icon}</span>
                <span>{site.name}</span>
              </button>
            ))}
          </div>

          {browserState.mode === 'youtube' && (
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={handleTogglePlayPause}
                className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-200 text-[10px] font-mono uppercase"
              >
                {browserState.isPlaying ? (
                  <>
                    <Pause className="w-3 h-3" />
                    <span>Pause</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3 h-3" />
                    <span>Play</span>
                  </>
                )}
              </button>
              <button
                type="button"
                onClick={handleStopMedia}
                className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-white/10 hover:bg-white/15 text-slate-300 text-[10px] font-mono uppercase"
              >
                <Square className="w-3 h-3" />
                <span>Stop</span>
              </button>
              <div className="flex items-center gap-1 text-[10px] font-mono text-slate-400">
                <Volume2 className="w-3 h-3 text-cyan-400" />
                <span>{browserState.volume ?? 80}%</span>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main Browser Viewport */}
      <div className="relative flex-1 flex flex-col lg:flex-row overflow-hidden bg-[#060913]">
        {/* Primary Iframe or Blocked Fallback */}
        <div className="relative flex-1 h-full flex flex-col overflow-hidden">
          {browserState.isIframeBlocked ? (
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center mb-4">
                <ShieldAlert className="w-8 h-8 text-amber-400" />
              </div>
              <h3 className="text-base sm:text-lg font-bold text-slate-100 mb-2">
                {browserState.title || 'External Website Security Policy'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mb-5 leading-relaxed">
                {browserState.blockReason ||
                  'This website restricts embedded iframe viewing via X-Frame-Options or Content-Security-Policy.'}
              </p>
              <div className="flex flex-wrap items-center justify-center gap-3">
                <a
                  href={browserState.inputUrl.startsWith('http') ? browserState.inputUrl : browserState.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-cyan-200 font-mono text-xs font-bold uppercase tracking-wider transition-all"
                >
                  <ExternalLink className="w-4 h-4" />
                  <span>Open {browserState.title} in External Tab</span>
                </a>
                <button
                  type="button"
                  onClick={() => navigateToResolved('https://www.google.com/webhp?igu=1', 'Google')}
                  className="px-4 py-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 text-slate-300 font-mono text-xs uppercase tracking-wider transition-all"
                >
                  Return to Google Search
                </button>
              </div>
            </div>
          ) : (
            <iframe
              ref={iframeRef}
              src={browserState.url}
              title={browserState.title || 'N3k Holographic Browser'}
              className="w-full h-full border-0 bg-white"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
              allowFullScreen
              onLoad={() => globalStateManager.setBrowserLoading(false)}
            />
          )}
        </div>

        {/* YouTube Search Results Sidebar when in YouTube Mode */}
        {browserState.mode === 'youtube' &&
          browserState.youtubeResults &&
          browserState.youtubeResults.length > 0 && (
            <div className="w-full lg:w-80 h-48 lg:h-full border-t lg:border-t-0 lg:border-l border-white/10 bg-[#050814]/95 flex flex-col overflow-hidden shrink-0">
              <div className="px-3 py-2 border-b border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-rose-400" />
                  <span className="font-mono text-[10px] font-bold uppercase tracking-wider text-slate-200">
                    YouTube Queue ({browserState.youtubeResults.length})
                  </span>
                </div>
                {browserState.youtubeQuery && (
                  <span className="font-mono text-[9px] text-slate-400 truncate max-w-[120px]">
                    &ldquo;{browserState.youtubeQuery}&rdquo;
                  </span>
                )}
              </div>
              <div className="flex-1 overflow-y-auto p-2 space-y-1.5">
                {browserState.youtubeResults.map((item) => {
                  const isCurrent = browserState.youtubeVideoId === item.videoId;
                  return (
                    <button
                      key={item.videoId}
                      type="button"
                      onClick={() => handleSelectYouTubeVideo(item)}
                      className={`w-full flex items-start gap-2.5 p-2 rounded-xl border text-left transition-all ${
                        isCurrent
                          ? 'bg-rose-500/15 border-rose-500/40 text-white'
                          : 'bg-white/[0.02] hover:bg-white/[0.06] border-white/5 text-slate-300'
                      }`}
                    >
                      <img
                        src={item.thumbnail}
                        alt={item.title}
                        className="w-20 h-12 object-cover rounded-lg shrink-0 bg-black"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="text-[11px] font-medium line-clamp-2 leading-snug">
                          {item.title}
                        </div>
                        <div className="flex items-center gap-2 mt-1 text-[9px] font-mono text-slate-400">
                          {item.author && <span className="truncate">{item.author}</span>}
                          {item.duration && <span>• {item.duration}</span>}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
      </div>
    </div>
  );
};
