import React from 'react';
import {
  Cpu,
  Mic,
  Brain,
  Globe,
  Eye,
  Wrench,
  Gauge,
  Radio,
} from 'lucide-react';
import { AssistantState, AssistantTheme } from '../types/assistant.ts';
import { THEME_CONFIGS } from '../modules/StateManager.ts';

interface SystemHUDPanelProps {
  state: AssistantState;
  theme: AssistantTheme;
  latencyMs: number;
  memoryCount: number;
  turnsCount: number;
  userLevel: number;
  assistantLevel: number;
  isBrowserOpen?: boolean;
  isCameraVisionOpen?: boolean;
  isOpen: boolean;
  onClose?: () => void;
  onOpenBrain: () => void;
  onToggleConnect?: () => void;
  onToggleMute?: () => void;
  onToggleBrowser?: () => void;
  onToggleVision?: () => void;
  onOpenCommandCenter?: () => void;
}

export const SystemHUDPanel: React.FC<SystemHUDPanelProps> = ({
  state,
  theme,
  memoryCount,
  userLevel,
  assistantLevel,
  isBrowserOpen = false,
  isCameraVisionOpen = false,
  isOpen,
  onOpenBrain,
  onToggleConnect,
  onToggleMute,
  onToggleBrowser,
  onToggleVision,
  onOpenCommandCenter,
}) => {
  const themeConfig = THEME_CONFIGS[theme] || THEME_CONFIGS['cyber-cyan'];
  const isOnline = state !== 'disconnected';

  const MODULES = [
    {
      id: 'ai_core',
      label: 'AI CORE',
      sub: isOnline ? 'Gemini Live Connected' : 'Tap to Awaken Core',
      status: isOnline ? 'ONLINE' : 'STANDBY',
      active: isOnline,
      icon: Cpu,
      onClick: onToggleConnect,
    },
    {
      id: 'voice',
      label: 'VOICE',
      sub: '24kHz Adult Male Synth',
      status: isOnline ? state.toUpperCase() : 'READY',
      active: state === 'speaking' || state === 'listening',
      icon: Mic,
      onClick: onToggleMute,
    },
    {
      id: 'memory',
      label: 'MEMORY',
      sub: `ZinxN3k Brain (${memoryCount})`,
      status: 'READY',
      active: memoryCount > 0,
      icon: Brain,
      onClick: onOpenBrain,
    },
    {
      id: 'browser',
      label: 'BROWSER',
      sub: 'Holographic Web & YT',
      status: isBrowserOpen ? 'ACTIVE' : 'READY',
      active: isBrowserOpen,
      icon: Globe,
      onClick: onToggleBrowser,
    },
    {
      id: 'vision',
      label: 'VISION',
      sub: 'Optical & Screen Cortex',
      status: isCameraVisionOpen ? 'ACTIVE' : 'READY',
      active: isCameraVisionOpen,
      icon: Eye,
      onClick: onToggleVision,
    },
    {
      id: 'tools',
      label: 'TOOLS',
      sub: 'Live Function Pipeline',
      status: 'READY',
      active: true,
      icon: Wrench,
      onClick: onOpenCommandCenter,
    },
  ];

  return (
    <aside
      aria-label="Holographic Subsystems"
      className={`fixed top-16 left-3 sm:left-5 z-20 w-64 max-w-[calc(100vw-1.5rem)] transition-all duration-300 pointer-events-auto ${
        isOpen
          ? 'opacity-100 translate-x-0'
          : 'opacity-0 -translate-x-8 pointer-events-none lg:opacity-100 lg:translate-x-0 lg:pointer-events-auto'
      }`}
    >
      <div className="p-3.5 rounded-2xl bg-[#060916]/85 border border-cyan-400/30 backdrop-blur-2xl shadow-[0_0_30px_rgba(0,229,255,0.12)] space-y-2.5 text-xs font-mono select-none">
        {/* Header */}
        <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
          <div className="flex items-center gap-2">
            <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span className="font-extrabold text-[10px] tracking-widest text-cyan-300 uppercase">
              HOLOGRAPHIC MODULES
            </span>
          </div>
          <span className="text-[9px] text-slate-400">LEFT ARRAY</span>
        </div>

        {/* Interactive Module Cards: AI CORE, VOICE, MEMORY, BROWSER, VISION, TOOLS */}
        <div className="space-y-1.5">
          {MODULES.map((mod) => {
            const Icon = mod.icon;
            return (
              <button
                key={mod.id}
                onClick={mod.onClick}
                className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-left transition-all active:scale-98 group ${
                  mod.active
                    ? 'bg-cyan-500/10 border-cyan-400/35 hover:border-cyan-300/70'
                    : 'bg-white/[0.03] border-white/10 hover:border-cyan-400/35'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border border-cyan-400/30"
                    style={{ backgroundColor: `${themeConfig.primary}18` }}
                  >
                    <Icon className="w-3.5 h-3.5" style={{ color: themeConfig.primary }} />
                  </div>
                  <div className="min-w-0">
                    <div className="text-[11px] font-bold text-white group-hover:text-cyan-200 transition-colors">
                      {mod.label}
                    </div>
                    <div className="text-[9px] text-slate-400 truncate">{mod.sub}</div>
                  </div>
                </div>
                <span
                  className={`text-[9px] font-bold px-2 py-0.5 rounded-full border shrink-0 ${
                    mod.active
                      ? 'bg-emerald-500/15 border-emerald-400/40 text-emerald-300'
                      : 'bg-slate-800/80 border-white/10 text-slate-300'
                  }`}
                >
                  {mod.status}
                </span>
              </button>
            );
          })}
        </div>

        {/* Neural Synapse Load Bar */}
        <div className="pt-2 border-t border-white/10 space-y-1">
          <div className="flex justify-between text-[9px] text-slate-400 tabular-nums">
            <span className="flex items-center gap-1">
              <Gauge className="w-3 h-3 text-cyan-400" />
              SYNAPSE ACTIVITY
            </span>
            <span className="font-bold text-cyan-300">
              {state === 'speaking'
                ? `${Math.round(80 + assistantLevel * 20)}%`
                : state === 'listening'
                  ? `${Math.round(60 + userLevel * 30)}%`
                  : isOnline
                    ? '48%'
                    : '12%'}
            </span>
          </div>
          <div className="h-1.5 w-full bg-slate-900 rounded-full overflow-hidden border border-white/5">
            <div
              className="h-full rounded-full transition-all duration-200"
              style={{
                width:
                  state === 'speaking'
                    ? `${Math.round(80 + assistantLevel * 20)}%`
                    : state === 'listening'
                      ? `${Math.round(60 + userLevel * 30)}%`
                      : isOnline
                        ? '48%'
                        : '12%',
                backgroundColor: themeConfig.primary,
                boxShadow: `0 0 8px ${themeConfig.glow}`,
              }}
            />
          </div>
        </div>
      </div>
    </aside>
  );
};
