import React, { useEffect, useRef, useState } from 'react';
import { Camera, X, Scan, Eye, AlertCircle } from 'lucide-react';
import { AssistantTheme } from '../types/assistant.ts';
import { globalStateManager } from '../modules/StateManager.ts';
import { globalLiveSession } from '../modules/LiveSession.ts';

interface CameraVisionHUDProps {
  isOpen: boolean;
  theme: AssistantTheme;
  onClose: () => void;
}

export const CameraVisionHUD: React.FC<CameraVisionHUDProps> = ({ isOpen, onClose }) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [camError, setCamError] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);

  useEffect(() => {
    if (!isOpen) {
      if (stream) {
        stream.getTracks().forEach((t) => t.stop());
        setStream(null);
      }
      return;
    }

    let activeStream: MediaStream | null = null;
    setCamError(null);

    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: 'environment' } })
      .then((mediaStream) => {
        activeStream = mediaStream;
        setStream(mediaStream);
        globalStateManager.updatePermission('camera', 'granted');
        if (videoRef.current) {
          videoRef.current.srcObject = mediaStream;
          videoRef.current.play().catch(() => {});
        }
      })
      .catch((err) => {
        globalStateManager.updatePermission('camera', 'denied');
        setCamError(err?.message || 'Camera permission denied or no camera available.');
      });

    return () => {
      if (activeStream) {
        activeStream.getTracks().forEach((t) => t.stop());
      }
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const handleAnalyzeCameraFrame = async () => {
    if (!videoRef.current || isScanning) return;
    const video = videoRef.current;
    if (video.videoWidth === 0 || video.videoHeight === 0) return;

    setIsScanning(true);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = Math.min(1024, video.videoWidth);
      canvas.height = Math.round((video.videoHeight * canvas.width) / video.videoWidth);
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
      const base64 = dataUrl.split(',')[1];
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (base64) {
        globalLiveSession.sendVideoFrame(base64);
        const res = await fetch('/api/analyze-screen', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            imageBase64: base64,
            mimeType: 'image/jpeg',
            prompt: 'Describe what is visible in this camera feed.',
          }),
        });
        const data = await res.json();
        if (data?.analysis) {
          setAnalysisResult(data.analysis);
        }
      }
    } catch (err: any) {
      setAnalysisResult(err?.message || 'Could not analyze camera frame.');
    } finally {
      setIsScanning(false);
    }
  };

  return (
    <div className="fixed bottom-24 left-4 z-40 w-72 sm:w-80 rounded-2xl bg-[#070b18]/92 border border-cyan-400/40 shadow-[0_0_35px_rgba(0,229,255,0.22)] backdrop-blur-2xl p-3.5 font-mono select-none animate-in slide-in-from-bottom-4 duration-200">
      <div className="flex items-center justify-between pb-2 border-b border-white/10">
        <div className="flex items-center gap-2">
          <Camera className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold text-white uppercase">VISION MODULE</span>
        </div>
        <button
          onClick={onClose}
          className="p-1 rounded-lg text-slate-400 hover:text-rose-300 hover:bg-rose-500/15"
          title="Close Camera Vision"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {camError ? (
        <div className="mt-2.5 p-3 rounded-xl bg-rose-950/60 border border-rose-500/30 text-[11px] text-rose-200 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
          <span>{camError}</span>
        </div>
      ) : (
        <div className="mt-2.5 relative aspect-video w-full rounded-xl overflow-hidden border border-cyan-500/25 bg-black">
          <video ref={videoRef} muted playsInline autoPlay className="w-full h-full object-cover" />
          <div className="absolute inset-0 pointer-events-none border border-cyan-400/20" />
        </div>
      )}

      {analysisResult && (
        <p className="mt-2 text-[10px] text-cyan-200 bg-cyan-950/40 border border-cyan-500/25 rounded-lg p-2 max-h-24 overflow-y-auto leading-relaxed">
          {analysisResult}
        </p>
      )}

      {!camError && (
        <div className="mt-2.5 flex items-center justify-between">
          <span className="text-[10px] text-emerald-300 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
            OPTICAL FEED LIVE
          </span>
          <button
            onClick={handleAnalyzeCameraFrame}
            disabled={isScanning}
            className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-cyan-500/20 hover:bg-cyan-500/35 border border-cyan-400/40 text-cyan-200 flex items-center gap-1"
          >
            {isScanning ? <Scan className="w-3 h-3 animate-spin" /> : <Eye className="w-3 h-3" />}
            <span>{isScanning ? 'Scanning...' : 'Scan Frame'}</span>
          </button>
        </div>
      )}
    </div>
  );
};
