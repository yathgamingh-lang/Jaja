# Drop your model here

Place your rigged 3D model file in this folder as either:

- `n3k.vrm`  (preferred — full VRM humanoid rig + expressions, e.g. from VRoid Studio/VRoid Mobile)
- `n3k.glb`  (plain rigged GLB, used only if no .vrm is found)

The app in `src/components/N3kAvatar3D.tsx` automatically detects and loads
whichever file is present, wiring the model's head bone, blink, VRM emotion
presets (neutral/happy/sad/angry/relaxed/surprised) and the 5 standard VRM
vowel visemes (aa/ih/ou/ee/oh) into N3k's existing EmotionController,
IdleBehaviorController and VisemeController.

If neither file is present, the app falls back to the built-in procedural
3D rig automatically — nothing breaks either way.

IMPORTANT — licensing: only place a model here that you made yourself or
have explicit rights to embed in this app. Many VRoid Hub models carry a
"Redistribution Prohibited" / "Only Author may use" license embedded in
their VRM metadata (`extensions.VRM.meta`) — check that before shipping
or distributing a build that includes one.
